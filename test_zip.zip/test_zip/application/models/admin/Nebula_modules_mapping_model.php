<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Nebula_modules_mapping_model extends MY_Model {
    
    public $_table = 'nebula_modules_mapping';
    public $_fields = "*";
    public $_where = array();
    public $_whereField = "";
    public $_whereFieldVal = "";

    public $_except_fields = array();
    private $ist_created_date;

    public function __construct() {
        parent::__construct();

        $create_date = date('Y-m-d H:i:s');
        
        $this->ist_created_date = getISTTime($create_date);
    }

    public function getNebulaModulesMappingList($filters = array(),$search_field) {

        $result = array();

        extract($filters);

        $likeArr = array();

        if (!empty($search)) {
            $likeArr['mapping.department'] = $search;
            $likeArr['mapping.modulecode'] = $search;
        }

        $this->db->select('mapping.id, mapping.department, mapping.modulecode as module, sw_tl.name as software_tl_name, trainer.name as trainer_name')
        ->from('nebula_modules_mapping mapping')
        ->join("tbl_users as sw_tl","sw_tl.id = mapping.sw_tl_id and sw_tl.type = 'software' ","left")
        ->join("tbl_users as trainer","trainer.id = mapping.trainer_id and trainer.type = 'software' ","left")
        ->where('is_deleted','0');
       
        if (!empty($likeArr)) {

            $this->db->group_start()

                ->like('department', $search)

                ->or_like('modulecode', $search)

                ->or_like($likeArr)

                ->group_end();

        }

        $get_result = $this->db->limit($limit, $offset)->get()->result_array();

        $totalRec=count($get_result);

        $params = array('url' => base_url($this->ADM_URL . strtolower($this->data['class'])));

        $result['data'] = array();


        foreach ($get_result as $i => $value) {

            $params['id'] = $value['id'];

            $extra = array();

            $is_edit = is_access_module()["edit"]();

            // $is_view = is_access_module()["view"]();

            $is_delete = is_access_module()["delete"]();
           
            if ($is_edit == FALSE && $is_delete == FALSE && empty($extra))
            {
                $action = '-';
            }
            
            $action = $this->generate_actions($params, $is_edit, false, $is_delete, $extra); //$is_view

            $result['data'][] = array(

                'id' => ($offset + $i + 1),

                'department' => ($value['department'] != '' ? $value['department'] : '-'),

                'module' => ($value['module'] != '' ? $value['module'] : '-'),

                'software_tl_name' => ($value['software_tl_name'] != '' ? $value['software_tl_name']  : '-'),
                
                'trainer_name' => ($value['trainer_name'] != '' ? $value['trainer_name']  : '-'),

                'action' => $action

            );
        }

        $result["recordsTotal"] = (int) $totalRec;

        $result["recordsFiltered"] = (int) $totalRec;

        return $result;

    }


    public function submit_nebula_modules_mapping($post = array()){
       
        $this->load->model('admin/Common_admin_model', 'common_admin');

        $content = array();

        $content['status'] = 404;

        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $id = isset($post['id']) ? (int) $post['id'] : 0;

        $dataArray = array(
            'department' => $post['department'],
            'modulecode' => $post['modules'],
            'sw_tl_id' => $post['software_tl'],     
            'trainer_id' => ($post['trainer'] ? $post['trainer'] : 0 ),
        );
        
        if ($id > 0) {

            $dataArray['updated'] = $this->ist_created_date;
            $dataArray['updated_by'] = getUpdatedBy();
           
            $this->db->update($this->_table, $dataArray, array('id' => $id));

            $content['status'] = 200;
            $content['message'] = sprintf($this->data['language']['succ_rec_updated'], $this->lang->line('lbl_nebula_modules_mapping'));

        } else {

            $dataArray = merge_common_insert_array($dataArray);
            
            $this->db->insert($this->_table, $dataArray);
            
            $content['status'] = 200;
            $content['message'] = sprintf($this->data['language']['succ_rec_added'], $this->lang->line('lbl_nebula_modules_mapping'));
        }
    
      
        return $content;
    }

    public function get_sub_modules_by_department_type($department){
        
     $sub_module = $this->db->select('mst_role_rights.rr_modulecode')
        ->from('mst_role_rights')
        ->where('mst_role_rights.rr_rolecode', $department)
        ->get()->result_array();
        
        if(!empty($sub_module)){
            $sub_module = multidimensional_to_single_array($sub_module);
        }
        
        return $sub_module;
    }

}