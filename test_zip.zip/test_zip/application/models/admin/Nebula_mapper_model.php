<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Nebula_mapper_model extends MY_Model {
    
    public $_table = 'nebula_modules_mapper';
    public $_fields = "*";
    public $_where = array();
    public $_whereField = "";
    public $_whereFieldVal = "";

    public $_except_fields = array();

    private $ist_created_date;

    public function __construct() {
        parent::__construct();

        $this->load->database('default');
        $this->second_db = $this->load->database('second_default', TRUE);

        $create_date = date('Y-m-d H:i:s');
        
        $this->ist_created_date = getISTTime($create_date);
    }

    public function submit_nebula_mapper_user_rights($param=[]){

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $data = [
            "user_id" =>  $param['nebula_selected_user'],
            "tab_option" => json_encode(explode(",",$param['tab_option'])),
            "ticket_show_hide" => json_encode(explode(",",$param['ticket_option'])),
            "filter_options" => json_encode(explode(",",$param['filter_option'])),
            "export_option" => json_encode(explode(",",$param['export_option'])),
            "post_option" => json_encode(explode(",",$param['post_option'])),
            "ticket_conversions_option" => json_encode(explode(",",$param['ticket_conversions_option'])),
            "updated_by" => getUpdatedBy(),
            "updated" => $this->ist_created_date,
        ];

        $this->second_db->where("user_id",$param['nebula_selected_user']); 
        $this->second_db->update('nebula_user_rights', $data);

        if ($this->second_db->affected_rows() > 0) {        
            $content['status'] = 200;
            $content['message'] = 'User Permission Updated Successfully';
        }

        return $content;
    }

    public function get_nebula_user_rights($user_id){
        $result = $this->second_db->select('nebula_user_rights.*')
                            ->from('nebula_user_rights')
                            ->where('nebula_user_rights.user_id' ,$user_id)
                            ->get()->row_array();

        // pre($result);

        $result['tab_option'] = implode(',', json_decode($result['tab_option']));
        $result['ticket_show_hide'] = implode(',', json_decode($result['ticket_show_hide']));
        $result['filter_options'] = implode(',', json_decode($result['filter_options']));
        $result['export_option'] = implode(',', json_decode($result['export_option']));
        $result['ticket_conversions_option'] = implode(',', json_decode($result['ticket_conversions_option']));
        $result['post_option'] = implode(',', json_decode($result['post_option']));

        return $result;
    }
    
    public function getTimezoneDateTime(){
        $result = $this->second_db->select('timezone_date_time.*')
                                    ->from('nebula_mapper_timezone_date_time AS timezone_date_time')  // Table alias should be defined correctly
                                    ->get()
                                    ->row_array();

        return $result;
    }

    public function submit_nebula_mapper($param){
        // pre($param);

        $result = $this->second_db->select('timezone_date_time.*')
                                    ->from('nebula_mapper_timezone_date_time AS timezone_date_time')  // Table alias should be defined correctly
                                    ->get()
                                    ->result_array();  // Retrieve the result as an array
                                
        $timezone_date_time_array = array(
            'timezone' => $param['nebula_time_zone'],
            'date_format' => $param['nebula_date_formatter'],
            'time_format' => $param['nebula_time_formatter'],
            'created' => $this->ist_created_date,
        );

        $last_insert_id = '';
        $update_success = false;
        
        if(empty($result)){
            $timezone_date_time_array = merge_common_insert_array($timezone_date_time_array);

            $this->second_db->insert('nebula_mapper_timezone_date_time', $timezone_date_time_array);
            $last_insert_id = $this->second_db->insert_id();
        }else{

            $timezone_date_time_array['updated'] = $this->ist_created_date;
            $timezone_date_time_array['updated_by'] = getUpdatedBy();

            // pre($timezone_date_time_array);

            $this->second_db->update('nebula_mapper_timezone_date_time', $timezone_date_time_array);

            if ($this->second_db->affected_rows() > 0) {
                $update_success = true;
            } else {
                $update_success = false;
            }
        }

        if ($last_insert_id > 0)
        {
            $content['status'] = 200;
            $content['message'] = 'Timezone, Date, Time Saved Successfully';

        }
        elseif($update_success){
            $content['status'] = 200;
            $content['message'] = 'Timezone, Date, Time Update Successfully';
        }

        return $content;

    }

    public function getTimezones(){
        $timezones = array(
            'Asia/Kolkata' => 'IST - Indian Standard Time UTC +05:30',
            // 'America/New_York' => 'EST - Eastern Standard Time UTC -05:00',
        );
        
        return $timezones;
    }

    public function getDateFormat(){

        $dateFormate = array(  
            'd-M-Y' => '20-Jan-2025 (dd-MM-yyyy)',
            'd-m-Y' => '20-01-2025 (mm-dd-yyyy)',
            'm-d-Y' => '01-20-2025 (mm-dd-yyyy)',
            'Y-m-d' => '2025-01-20 (yyyy-mm-dd)',
            'D, F j Y' => 'Mon, January 20 2025 (w, MM dd yyyy)',
            'D, d F Y' => 'Mon, 20 January 2025 (w, dd MM yyyy)',
        );

        return $dateFormate;
    }

    public function getTimeFormat(){
        $timeFormat = array(
            'h:i A' => '07:50 PM (H:M - 12Hrs)',
            'h:i:s A' => '07:50:10 PM (H:M:S - 12Hrs)',
            'H:i' => '19:50 (H:M - 24Hrs)',
            'H:i:s' => '19:50:10 (H:M:S - 24Hrs)',
        );

        return $timeFormat;
    }

    public function getDateTimeFormat($created){
        
        $result = $this->second_db->select('timezone_date_time.*')
                                    ->from('nebula_mapper_timezone_date_time AS timezone_date_time')  // Table alias should be defined correctly
                                    ->get()
                                    ->row_array();  
                                    // pre($result);



        /* START - Remove this code when timezone functionality added */
            $formattedDateTime = date('Y-m-d H:i', strtotime($created));
            // $formattedDateTime = $created;   
        /* END - Remove this code when timezone functionality added */
        
        if(!empty($result)){

            $createdDate = new DateTime($created); // Convert string to DateTime object
            // pre($createdDate);

            // Set Timezone (IST/EST)
            $createdDate = $createdDate->setTimezone(new DateTimeZone($result['timezone']));
            
            $formattedDate = $createdDate->format($result['date_format']);  // Format the date
            $formattedTime = $createdDate->format($result['time_format']);  // Format the time

            $formattedDateTime = $formattedDate. ' ' .$formattedTime;

        }

        return $formattedDateTime;

    }

    public function getWorkingHrsHtml(){
        $week_days_array = array(
            'monday' => 'Monday',
            'tuesday' => 'Tuesday',
            'wednesday' => 'Wednesday',
            'thursday' => 'Thursday',
            'friday' => 'Friday',
        );

        $working_days = '';

        $working_days .= '<div class="form-group row align-items-center"><label class="col-1 col-form-label">Sunday</label><div class="col-1"><label class="switch"><input type="checkbox"><span class="slider"></span></label></div><div class="col-1 text-muted">Closed</div></div>';

        foreach ($week_days_array as $key => $value) {
            $working_days .= '<div class="form-group row align-items-center"><label class="col-1 col-form-label">' . ucfirst($key) . '</label><div class="col-1"><label class="switch"><input type="checkbox" checked><span class="slider"></span></label></div><div class="col-1 status-text text-primary">Open</div><div class="col-1 time-fields"><input type="text" class="form-control time-input" id="start_'.$key.'" placeholder="11:00 AM"></div><div class="col-1 text-center time-fields">-</div><div class="col-1 time-fields"><input type="text" class="form-control time-input" id="end_'.$key.'" placeholder="12:00 AM"></div></div>
            ';
        }

        $working_days .= '<div class="form-group row align-items-center"><label class="col-1 col-form-label">Saturday</label><div class="col-1"><label class="switch"><input type="checkbox"><span class="slider"></span></label></div><div class="col-1 text-muted">Closed</div></div>';

        // pre($working_days);
        return $working_days;

    }

    public function getWorkingHoursData(){
        $result = $this->second_db->select('working_hrs.*')
                                    ->from('nebula_mapper_working_hrs AS working_hrs')  // Table alias should be defined correctly
                                    ->get()
                                    ->result_array();

        return $result;
    }

    public function getWeekdays(){
        $week_days_array = array(
            "sunday" => "Sunday",
            "monday" => "Monday",
            "tuesday" => "Tuesday",
            "wednesday" => "Wednesday",
            "thursday" => "Thursday",
            "friday" => "Friday",
            "saturday" => "Saturday"
        );

        return $week_days_array;
    }

    public function submit_nebula_mapper_working_hrs($param){
        // pre($param);

        $param['weekdays_data'] = json_decode($param['weekdays_data'],true);
        // pre($param['weekdays_data']);

        $result = $this->second_db->select('working_hrs.*')
                                    ->from('nebula_mapper_working_hrs AS working_hrs')  // Table alias should be defined correctly
                                    ->get()
                                    ->result_array();
                                    // pre($result);

            $expected_array = [];
            if(!empty($result)){
                foreach ($result as $value) {
                    $weekday = $value['weekday']; // Use weekday as the key
                    $expected_array[$weekday] = $value; // Assign the whole item to that key
                }
            }
            // pre($expected_array);
            $result = $expected_array;

        $working_hrs_array = [];

        $week_days_array = $this->getWeekdays();
        // pre($week_days_array);
        
        $last_insert_id = '';
        $update_success = false;

        foreach ($week_days_array as $key => $value) {
            // Check if the current weekday is in the weekdays_data parameter
            if (isset($param['weekdays_data'][$key])) {

                $day_data = $param['weekdays_data'][$key];
        
                // Store relevant data in the working_hrs_array
                $working_hrs_array['weekday'] = $key;  // Save the actual weekday name (e.g., 'Monday')
                $working_hrs_array['weekday_status'] = $day_data['status'];
                $working_hrs_array['start_time'] = $day_data['start_time'];
                $working_hrs_array['end_time'] = $day_data['end_time'];
                $working_hrs_array['created'] = $this->ist_created_date;

                // pre($result['weekday']);
                if(!empty($result)){
                    // pre(234);
                    // $this->second_db->update('nebula_mapper_working_hrs', $working_hrs_array);
                    // ->where('nebula_mapper_working_hrs.weekday', $key)

                    $working_hrs_array['updated'] = $this->ist_created_date;
                    $working_hrs_array['updated_by'] = getUpdatedBy();

                    $this->second_db->where('weekday', $key);  // Add the WHERE condition
                    $this->second_db->update('nebula_mapper_working_hrs', $working_hrs_array);

                    if ($this->second_db->affected_rows() > 0) {
                        $update_success = true;
                    } else {
                        $update_success = false;
                    }

                }elseif(empty($result) && $result['weekday'] != $key){
                    // pre(3456);
                    $this->second_db->insert('nebula_mapper_working_hrs', $working_hrs_array);
                    $last_insert_id = $this->second_db->insert_id();
                }
                // pre(345);
            }
        }

        if ($last_insert_id > 0)
        {
            $content['status'] = 200;
            $content['message'] = 'Working Hours Saved Successfully';

        }
        elseif($update_success){
            $content['status'] = 200;
            $content['message'] = 'Working Hours Update Successfully';
        }

        return $content;

    }

    public function holiday_configuration_submit($parm=[]){

        $holiday_markup  = $parm["holiday_markup"];
        $date  = $parm["date"];
        $day  = $parm["day"];
        $country = $parm["country"];


        

        $this->second_db->select('COUNT(*) as total')
        ->from('nebula_holiday_mapping');
        $this->second_db->where("date",format_date($date, get_db_date_format()));
        $exist_record = $this->second_db->get()->row_array();
        if( $exist_record["total"]>0){

            $status = ["status"=>false,"message"=>"Duplicate Record found Please select other date"];
            return $status;
           
        }


        $data = ["holiday_markup"=>$holiday_markup,
                "date"=>format_date($date, get_db_date_format()),
                "day"=>$day,
                "country"=>$country];
       
       
        if(empty($data["date"])){
            $status = ["status"=>false,"message"=>"Please select date"];
            return $status;
        }else if(empty($data["holiday_markup"])){
            $status = ["status"=>false,"message"=>"Holiday markup can't be empty"];
            return $status;
        }else if(empty($data["country"])){
            $status = ["status"=>false,"message"=>"Please select country for holiday"];
            return $status;
        }
       
        $insert_data = merge_common_insert_array($data);

        $this->second_db->insert('nebula_holiday_mapping', $insert_data);
        $insert_id = $this->second_db->insert_id();
        $insert_id = ($insert_id>0)?true:false;


        $status = ["status"=>$insert_id];
        return $status;

    }

  
    public function getListsHolidayMapper($filters = array(), $search_field, $data)
    {

        $result = array();


        $return_data = $this->get_nebula_holiday_settings_data(["filters"=>$filters,"data"=>$data]);
        $selhard_manu = $return_data['selhard_manu'];
    

        $result['data'] = array();
       
        // pre($selhard_manu);
        foreach ($selhard_manu as $i => $hard_manu) {
          
            $formattedDate = $this->getHolidayDateFormat($hard_manu['date']);

            $result['data'][] = array(
                // 'date' => date("Y/m/d", strtotime($hard_manu['date'])),
                'date' => $formattedDate,
                'day' => $hard_manu['day'],
                'holiday_markup' => $hard_manu['holiday_markup'],
                'country'=> ucfirst($hard_manu['country'])
            );
        }

        $return_count_data = $this->get_nebula_holiday_settings_data(["filters"=>$filters,"data"=>$data,"flag"=>"count"]);
        $result["recordsTotal"] = (int)count($return_count_data["selhard_manu"]);
      
        $result['getHolidayTabCount'] = $return_count_data["get_holiday_tab_count"];
        $result["recordsFiltered"] = (int)count($return_count_data["selhard_manu"]);
      
        return $result;
    }

    public function get_nebula_holiday_settings_data($param=array()){

        extract($param["filters"]);
        $data = $param["data"];
        $flag = $param["flag"];
        $selhard_manu = '';

        $get_holiday_tab_count = $this->getHolidayTabCount($data);

        $likeArr = array();
        if (!empty($search)) {
            //$likeArr['aorbis_vendor.name'] = $search;
        }
        $this->second_db->select('nebula_holiday_mapping.*')
            ->from('nebula_holiday_mapping');

        if (!empty($data['tab_id']) && $data['tab_id'] == 'weekend_datatable') {
            $this->second_db->where('nebula_holiday_mapping.holiday_markup', 'Weekend');
        }elseif (!empty($data['tab_id']) && $data['tab_id'] == 'all_holiday_datatable') {
            $this->second_db->where_in('nebula_holiday_mapping.country', ['india', 'us', 'both']);
            $this->second_db->not_like('nebula_holiday_mapping.holiday_markup', 'Weekend');
        }
        // elseif (!empty($data['tab_id']) && $data['tab_id'] == 'both_holiday_datatable') {
        //     $this->second_db->where('nebula_holiday_mapping.country', 'both');
        // }

        if(!empty($data['holiday_filter_val'])){
            if($data['holiday_filter_val'] == 'india'){
                $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);    
            }elseif($data['holiday_filter_val'] == 'us'){
                $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
            }elseif($data['holiday_filter_val'] == 'both'){
                $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
            }
        }
        if (!empty($search_field)) {
            $this->second_db->having("holiday_markup like '%$search_field%'");
        }
        if (!empty($likeArr)) {
            $this->second_db->group_start()->like($likeArr)->group_end();
        }
        $this->second_db->order_by("date","ASC");
        // $selhard_manu = $this->second_db->limit($limit, $offset)->get()->result_array();



        if(!empty($flag) && $flag=="count"){
            $selhard_manu = $this->second_db->get()->result_array();
        }else{
            $selhard_manu = $this->second_db->limit($limit, $offset)->get()->result_array();
        }

        return ["selhard_manu" => $selhard_manu, "get_holiday_tab_count" => $get_holiday_tab_count];
        // return $selhard_manu;

    }

    public function getHolidayTabCount($data){

        $tabs = ['all_holiday', 'india', 'us', 'both'];

        

        // Query for all holidays
        $all_weekend_and_holiday = $this->second_db->select('COUNT(*) AS all_weekend_and_holiday')
                                    ->from('nebula_holiday_mapping');
                                    if(!empty($data['holiday_filter_val'])){
                                        if($data['holiday_filter_val'] == 'india'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);    
                                        }elseif($data['holiday_filter_val'] == 'us'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
                                        }elseif($data['holiday_filter_val'] == 'both'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
                                        }
                                    }
                                    $all_weekend_and_holiday = $this->second_db->get()->row()->all_weekend_and_holiday; // Get count result
                                    // pre($all_weekend_and_holiday);

        // Query for Weekend holidays
        $weekend_holiday = $this->second_db->select('COUNT(*) AS weekend')
                                    ->from('nebula_holiday_mapping')
                                    ->where('holiday_markup', 'weekend');
                                    if(!empty($data['holiday_filter_val'])){
                                        if($data['holiday_filter_val'] == 'india'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);    
                                        }elseif($data['holiday_filter_val'] == 'us'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
                                        }elseif($data['holiday_filter_val'] == 'both'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
                                        }
                                    }
                                    $weekend_holiday =  $this->second_db->get()->row()->weekend; // Get count result
                                    // pre($weekend_holiday);

        // Query for All Holidays holidays
        $all_holiday = $this->second_db->select('COUNT(*) AS all_holiday')
                                    ->from('nebula_holiday_mapping')
                                    // ->where('country', 'all_holiday')
                                    ->not_like('holiday_markup', 'weekend');
                                    if(!empty($data['holiday_filter_val'])){
                                        if($data['holiday_filter_val'] == 'india'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);    
                                        }elseif($data['holiday_filter_val'] == 'us'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
                                        }elseif($data['holiday_filter_val'] == 'both'){
                                            $this->second_db->where('nebula_holiday_mapping.country', $data['holiday_filter_val']);
                                        }
                                    }
                                    $all_holiday =  $this->second_db->get()->row()->all_holiday; // Get count result
                                    // pre($all_holiday);

        // Return the results
        $result = [
            'all_weekend_and_holiday' => $all_weekend_and_holiday,
            'weekend_holiday' => $weekend_holiday,
            'all_holiday' => $all_holiday,
        ];

        return $result;
    }

    public function getHolidayDateFormat($holiday_date){

        $getDateFormat = $this->second_db->select('timezone_date_time.*')
                                    ->from('nebula_mapper_timezone_date_time AS timezone_date_time')  // Table alias should be defined correctly
                                    ->get()
                                    ->row_array();
                                    // pre($getDateFormat['date_format']);

        // Check if the format contains 'D' (weekday abbreviation)
        if (strpos($getDateFormat['date_format'], 'D') === false) {
            // If 'D' is not present, add it at the beginning of the format
            $getDateFormat['date_format'] = 'D, ' . $getDateFormat['date_format'];
        }
        
        // Now format the date with the updated format
        $formattedDate = date($getDateFormat['date_format'], strtotime($holiday_date));

        return $formattedDate;
    }

    public function getTicketClosingDate($created_date){
        // pre($created_date);
        $working_hrs = $this->second_db->select('nebula_mapper_working_hrs.*')
                                    ->from('nebula_mapper_working_hrs')
                                    ->get()
                                    ->result_array();
        // pre($working_hrs);

        $holiday_mapping = $this->second_db->select('holiday_mapping.*')
                                    ->from('nebula_holiday_mapping holiday_mapping')
                                    ->order_by('holiday_mapping.date', 'ASC')
                                    ->get()
                                    ->result_array();
        // pre($holiday_mapping);



        // $created_date;

        $holiday_mapping_array = [];
        if(!empty($holiday_mapping)){
            foreach ($holiday_mapping as $value) {
                $date = $value['date']; // Use date as the key
                $holiday_mapping_array[$date] = $value; // Assign the whole item to that key
            }
        }
        // pre($holiday_mapping_array);
        // check weekdays and their working hours which is define in $working_hrs_array as start_time & end_time 

        $working_hrs_array = [];
        if(!empty($working_hrs)){
            foreach ($working_hrs as $value) {
                $weekday = $value['weekday']; // Use weekday as the key
                $working_hrs_array[$weekday] = $value; // Assign the whole item to that key
            }
        }
        // pre($working_hrs_array);
        


        // $created_date
        // echo(strtotime("+72 hours") . "<br>");

        // $cenvertedTime = date('Y-m-d H:i:s',strtotime('+1 hour',strtotime($startTime)));

        $created_date = '2025-01-30 03:27:30';
        // pre($created_date);
        $created_timestamp = strtotime($created_date);
        // pre($created_timestamp); // 1738225650

        // Calculate the ticket closing time, 72 hours from created date
        $ticket_closing_timestamp = $created_timestamp + (72 * 60 * 60); // 1738484850 1735707600
        // pre($ticket_closing_timestamp);
        $ticket_closing_date = date('Y-m-d H:i:s', $ticket_closing_timestamp);
        // pre($ticket_closing_date); // 2025-02-02 03:27:30

        $holiday_timestamps = [];
        foreach ($holiday_mapping_array as $holiday) {
            $holiday_timestamps[] = strtotime($holiday['date']);
        }
        // pre($holiday_timestamps); 


        
        // Loop through holidays to check if any holiday falls within the next 72 hours
        foreach ($holiday_mapping_array as $holiday) {
            // Check if the holiday date is within the next 72 hours
            $holiday_timestamp = strtotime($holiday['date']);
            // pre("holiday_timestamp : " . $holiday_timestamp,0);
            if ($holiday_timestamp >= $created_timestamp && $holiday_timestamp <= $ticket_closing_timestamp) {
                // If holiday's day matches a working day in the working hours array, adjust closing time
                $holiday_day = strtolower($holiday['day']);  // Convert to lowercase to match array keys

                // Check if the holiday day exists in the working hours array
                if (isset($working_hrs_array[$holiday_day])) {
                    $workday = $working_hrs_array[$holiday_day];
                    $start_time = strtotime(date('Y-m-d ' . $workday['start_time'], $holiday_timestamp));
                    $end_time = strtotime(date('Y-m-d ' . $workday['end_time'], $holiday_timestamp));
                    
                    // If the holiday's day falls outside working hours, adjust to the working hours
                    if ($ticket_closing_timestamp < $start_time) {
                        // Adjust ticket closing to the start time of the working day
                        $ticket_closing_timestamp = $start_time;
                    } elseif ($ticket_closing_timestamp > $end_time) {
                        // Adjust ticket closing to the end time of the working day
                        $ticket_closing_timestamp = $end_time;
                    }
                }
            }
        }

        // pre($ticket_closing_timestamp);
        $adjusted_closing_date = date('Y-m-d H:i:s', $ticket_closing_timestamp);
        pre($adjusted_closing_date);


        // pre($holiday_timestamps);

        $holidays_in_next_72hrs = [];
        foreach ($holiday_timestamps as $holiday_timestamp) {
            if ($holiday_timestamp >= $created_timestamp && $holiday_timestamp <= $ticket_closing_timestamp) {
                $holidays_in_next_72hrs[] = date('Y-m-d', $holiday_timestamp);
            }
        }
        // pre($holidays_in_next_72hrs);

        // Check if any holidays exist in the next 72 hours
        // if (!empty($holidays_in_next_72hrs)) {
        //     pre("Holidays within the next 72 hours: " . implode(', ', $holidays_in_next_72hrs) . "\n");
        // }

        // pre(456);

        // Check working hours for weekdays within the next 72 hours
        $adjusted_closing_date = $ticket_closing_date;
        $current_day = date('l', $ticket_closing_timestamp);  // Get the weekday of the calculated closing date
        // pre($current_day);

        $adjusted_closing_date = $this->adjust_closing_time_for_working_hours($ticket_closing_date, $working_hrs_array);
        pre($adjusted_closing_date);

        pre(354);




    }

    public function adjust_closing_time_for_working_hours($closing_date, $working_hours_array) {
        // pre($working_hours_array);
        $closing_timestamp = strtotime($closing_date); // 1738484850
        $weekday = date('l', $closing_timestamp); // Sunday
        $day_of_week = strtolower($weekday); // sunday
        // pre($day_of_week);
        
        if (isset($working_hours_array[$day_of_week])) {
            $workday = $working_hours_array[$day_of_week];
            $start_time = strtotime(date('Y-m-d ' . $workday['start_time'], $closing_timestamp));
            $end_time = strtotime(date('Y-m-d ' . $workday['end_time'], $closing_timestamp));
            
            // If the ticket closing time falls outside working hours, adjust it
            if ($closing_timestamp < $start_time) {
                
                return date('Y-m-d H:i:s', $start_time);  // Set to start time of working hours
            }
            
            if ($closing_timestamp > $end_time) {
                return date('Y-m-d H:i:s', $end_time);  // Set to end time of working hours
            }
        }
        pre($closing_date);
        return $closing_date;  // If no adjustment is needed
    }

    //Naman Start
    public function priority_submit($data) {
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $insert_data = array(
            'priority' => $data['priority']
            // 'created_at' => $this->ist_created_date
        );

        $result = $this->second_db->select('COUNT(*) as total')
        ->from('nebula_priority_table')
        ->where("priority",$data['priority'])
        ->get()
        ->row_array();

        if(!empty($result) && $result["total"]>0){
            $content['status'] = 404;
            $content['message'] = 'Record already exist';
            return $content;
        }


        $this->second_db->insert('nebula_priority_table', merge_common_insert_array($insert_data));

        if ($this->second_db->affected_rows() > 0) {
            $content['status'] = 200;
            $content['message'] = 'Priority Added Succesfully';
        }
        return $content;
    }

    // Naman start for the edit and delete fun.
    public function priority_delete($data) {
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];
        $this->second_db->where('id', $data['id']);
        $this->second_db->delete('nebula_priority_table'); 
        if ($this->second_db->affected_rows() > 0) {
            $content['status'] = 200;
            $content['message'] = 'Priority deleted successfully';
        } 
        return $content;
    }

    public function priority_edit($data) {
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];
        $this->second_db->where('id', $data['id']);
        $this->second_db->update('nebula_priority_table', array('priority' => $data['newPriority']));
            if ($this->second_db->affected_rows() > 0) {
                $content['status'] = 200;
                $content['message'] = 'Priority updated successfully';  
            } 

        return $content;
    }
// Naman start for the edit and delete fun.

    public function get_all_priorities() {
        $result = $this->second_db->select('nebula_priority_table.priority,nebula_priority_table.created,nebula_priority_table.id')
                                ->from('nebula_priority_table')
                                ->get()
                                ->result_array();
                                // pre($result);
        
        return $result;
    }
    //Naman End


    /**
     * Used for Getting Purpose Master Data
     *  Data Return in Array Row Format
     */
    public function get_all_purpose()
    {
        $this->second_db->where("JSON_CONTAINS_PATH(mst_data, 'one', '$.purpose')", null, false);
        $query = $this->second_db->get('nebula_master');
        $result = $query->row_array();
        return $result;
    }

    /**
     * Used for Getting Purpose Master Data
     *  Data Return in Array Row Format
     */
    public function getAllPurposeProperties()
    {
        $this->second_db->where("JSON_CONTAINS_PATH(mst_data, 'one', '$.purpose_property')", null, false);
        $query = $this->second_db->get('nebula_master');
        $result = $query->row_array();
        return $result;
    }

    /**
     * Used for Performing Operation on Purpose Module
     * Opration : Insert, Update, Delete Purpose Data
     */
    public function purpose_submit($data)
    {
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $getCurrentUserid = getCurrentLoggedInUserID();
        $getPurposeData = $this->get_all_purpose();
        $getPurposeProperties = $this->getAllPurposeProperties();
        if (!empty($data)) {
            $purposeId = $data['id'];
            $action = $data['action'];
            $purposeValue = $data['purpose'];
            $backgroundColor = $data['background_color'];
            $fontColor = $data['font_color'];
            $borderColor = $data['border_color'];
            //Delete Purpose Data Code START
            if (isset($action) && $action == 'delete') {
                if ($getPurposeData) {
                    $getMstData = $getPurposeData['mst_data'];
                    $getData = json_decode($getMstData, true);
                    $purposeString = strtolower(str_replace(' ', '_', $purposeValue));
                    if (isset($getData["purpose"][$purposeString])) {
                        unset($getData["purpose"][$purposeString]);
                    }
                    $deleted_json = json_encode($getData);
                    $deletedData = [
                        'mst_data' => $deleted_json,
                        'updated' => date("Y-m-d h:i:s"),
                        'updated_by' => $getCurrentUserid,
                    ];
                    $this->second_db->where('id', $purposeId);
                    $this->second_db->update('nebula_master', $deletedData);

                    //Update Code Regarding Purpose Property Data
                    if ($getPurposeProperties) {
                        $purposePropId = $getPurposeProperties['id'];
                        $getPropMstData = $getPurposeProperties['mst_data'];
                        $purposeString = strtolower(str_replace(' ', '_', $purposeValue));
                        $propDataArray = json_decode($getPropMstData, true);
                        if (isset($propDataArray["purpose_property"][$purposeString])) {
                            unset($propDataArray["purpose_property"][$purposeString]);
                        }
                        $purposeProData = json_encode($propDataArray);
                        $purposeProUpdateData = array(
                            'mst_data' => $purposeProData,
                            'created' => date("Y-m-d h:i:s"),
                            'inserted_by' => $getCurrentUserid,
                        );
                        $this->second_db->where('id', $purposePropId);
                        $this->second_db->update('nebula_master', $purposeProUpdateData);
                    }

                    $content['status'] = 200;
                    $content['message'] = 'Purpose Deleted Succesfully';
                } else {
                    $content['message'] = 'Data not found';
                }
                return $content;
                //Deleted Purpose Data Code End
            } else if (isset($action) && $action == 'insert') {
                //Insert Code START
                $purposeString = strtolower(str_replace(' ', '_', $purposeValue));
                //INSERT if value find then Update Record START
                if ($getPurposeData) {
                    $purposeId = $getPurposeData['id'];
                    $getMstData = $getPurposeData['mst_data'];
                    $data = json_decode($getMstData, true);
                    $data['purpose'][$purposeString] = $purposeValue;
                    $updated_json = json_encode($data);
                    $updateData = [
                        'mst_data' => $updated_json,
                        'updated' => date("Y-m-d h:i:s"),
                        'updated_by' => $getCurrentUserid,
                    ];
                    $this->second_db->where('id', $purposeId);
                    $this->second_db->update('nebula_master', $updateData);
                    if ($getPurposeProperties) {
                        $purposePropId = $getPurposeProperties['id'];
                        $getPropMstData = $getPurposeProperties['mst_data'];
                        $propData = json_decode($getPropMstData, true);
                        //Purpose Property Details Insert
                        $purposeProperty = [
                            'background-color' => $backgroundColor,
                            'color' => $fontColor,
                            'border-color' => $borderColor,
                        ];
                        $propData['purpose_property'][$purposeString] = $purposeProperty;
                        $purposeProData = json_encode($propData);
                        $purposeProUpdateData = array(
                            'mst_data' => $purposeProData,
                            'created' => date("Y-m-d h:i:s"),
                            'inserted_by' => $getCurrentUserid,
                        );
                        $this->second_db->where('id', $purposePropId);
                        $this->second_db->update('nebula_master', $purposeProUpdateData);
                    }

                    $content['status'] = 200;
                    $content['message'] = 'Purpose Added Succesfully';
                    //INSERT if value find then Update Record END
                } else {
                    //Insert Record Code START
                    $purposeString = strtolower(str_replace(' ', '_', $purposeValue));
                    $insertData = [
                        "purpose" => [
                            $purposeString => $purposeValue
                        ]
                    ];
                    $inserted_json = json_encode($insertData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    $insert_data = array(
                        'mst_data' => $inserted_json,
                        'created' => date("Y-m-d h:i:s"),
                        'inserted_by' => $getCurrentUserid,
                    );
                    $this->second_db->insert('nebula_master', $insert_data);

                    //Purpose Property Details Insert
                    $purposeProperty = [
                        $purposeString => [
                            'background-color' => $backgroundColor,
                            'color' => $fontColor,
                            'border-color' => $borderColor,
                        ]
                    ];
                    $purposeArray = ["purpose_property" => $purposeProperty];
                    $purposeProData = json_encode($purposeArray);
                    $purposeProInsertData = array(
                        'mst_data' => $purposeProData,
                        'created' => date("Y-m-d h:i:s"),
                        'inserted_by' => $getCurrentUserid,
                    );
                    $this->second_db->insert('nebula_master', $purposeProInsertData);

                    $content['status'] = 200;
                    $content['message'] = 'Purpose Added Succesfully';
                    //INSERT Record code END
                }
            } else {
                //Edit Purpose Data Code START
                $purposeId = $data['id'];
                $purposeValue = $data['purpose'];
                $oldPurposeVal = $data['old_purpose'];
                $newPurposeVal = $data['new_purpose'];
                $oldPurposeString = strtolower(str_replace(' ', '_', $oldPurposeVal));
                $newPurposeString = strtolower(str_replace(' ', '_', $newPurposeVal));
                if ($getPurposeData) {
                    $getMstData = $getPurposeData['mst_data'];
                    $purposeId = $getPurposeData['id'];
                    $getData = json_decode($getMstData, true);
                    $getData['purpose'] = array_combine(
                        array_map(function ($key) use ($oldPurposeString, $newPurposeString) {
                            return $key === $oldPurposeString ? $newPurposeString : $key;
                        }, array_keys($getData['purpose'])), // Modify Keys
                    
                        array_map(function ($item) use ($oldPurposeVal, $newPurposeVal) {
                            return $item === $oldPurposeVal ? $newPurposeVal : $item;
                        }, $getData['purpose']) // Modify Values
                    );
                    $updatedJson = json_encode($getData);
                    $editedData = [
                        'mst_data' => $updatedJson,
                        'updated' => date("Y-m-d h:i:s"),
                        'updated_by' => $getCurrentUserid,
                    ];
                    $this->second_db->where('id', $purposeId);
                    $this->second_db->update('nebula_master', $editedData);

                    if ($getPurposeProperties) {
                        $purposePropId = $getPurposeProperties['id'];
                        $getPropMstData = $getPurposeProperties['mst_data'];
                        $propData = json_decode($getPropMstData, true);
                        //Purpose Property Details Insert
                        $purposeProperty = [
                            'background-color' => $backgroundColor,
                            'color' => $fontColor,
                            'border-color' => $borderColor,
                        ];
                        //Unset Key, If Old key and New Key Match then unset that specific key
                        if ($oldPurposeString != $newPurposeString) {
                            if (isset($propData["purpose_property"][$oldPurposeString])) {
                                unset($propData["purpose_property"][$oldPurposeString]);
                            }
                        }
                        $propData['purpose_property'][$newPurposeString] = $purposeProperty;
                        $purposeProData = json_encode($propData);
                        $purposeProUpdateData = array(
                            'mst_data' => $purposeProData,
                            'created' => date("Y-m-d h:i:s"),
                            'inserted_by' => $getCurrentUserid,
                        );
                        $this->second_db->where('id', $purposePropId);
                        $this->second_db->update('nebula_master', $purposeProUpdateData);
                    }

                    $content['status'] = 200;
                    $content['message'] = 'Purpose Edited Succesfully';
                } else {
                    $content['message'] = 'Data not found';
                }
                return $content;
            }
            //EDIT Purpose END
        } else {
            $content['message'] = "Data not found for insert purpose";
        }
        return $content;
    }
    
}