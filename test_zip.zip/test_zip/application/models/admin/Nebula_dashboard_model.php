<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Nebula_dashboard_model extends MY_Model
{

    public $_table = 'nebula_form_mst';

    public $_fields = "*";

    public $_where = array();

    public $_whereField = "";

    public $_whereFieldVal = "";

    public $_except_fields = array();

    private $ist_created_date;

    public function __construct()
    {
        parent::__construct();
        $this->load->database('default');
        $this->second_db = $this->load->database('second_default', TRUE);

        $this->load->model('admin/Nebula_mapper_model', 'nebula_mapper_model');

        $create_date = date('Y-m-d H:i:s');
        $this->ist_created_date = getISTTime($create_date);
        
    }

    public function show_requistion_list($filters = array(), $data)
    {
        $result = array();

        $data['loggedInUserDept'] = $this->getLoggedInUserDepartment(getCurrentLoggedInUserID());
        $purposeTypesArray = purposeTypes();// Get Purpose Type

        // $get_latest_timezone = $this->getLatestTimezone();
        // $data['get_latest_timezone'] = $get_latest_timezone; 

        $return_data  = $this->show_requistion_list_helper(["filters" => $filters, "data" => $data]);
        $get_result = $return_data["get_result"];
        $orion_user_data = $return_data["orion_user_data"];

        $params = array('url' => base_url($this->ADM_URL . strtolower($this->data['class'])));

        $result['data'] = array();

        $orion_user_type = (!empty($data['orion_user'])) ? $orion_user_data['type'] : '';
        $header_data = $this->getTableHeadings();
        $header_data_recent = $this->getTableHeadingsRecent();

        $result["header_data"] = $header_data;
        $result["header_data_recent"] = $header_data_recent;
        

        foreach ($get_result as $key => $value) {
            $get_result[$key]['orion_department'] = ucwords(str_replace("_", " ", $value['orion_department']));
            // $get_result[$key]['dept_tl'] = (!empty($value['dept_tl'])) ? $this->getDepartmentTLName($value['dept_tl']) : '';
            // $get_result[$key]['sw_tl_id'] = $this->getSoftwareTLName($value['sw_tl_id']);
            $get_result[$key]['status_type'] = $this->getBugStages();

            $get_assignee = $this->getTrainerNames($value['trainer_id']);
            $get_result[$key]['trainer_id'] = $get_assignee['all_users']; // $value['trainer_id'] current_assignee

            $get_created_by_user = $this->getUserNameByID($value['inserted_by'])['name'];

            $params['id'] = $value['ticket_id'];

            $extra = array();

            // $is_edit = is_access_module()["edit"]();

            // $is_view = is_access_module()["view"]();

            // $is_delete = is_access_module()["delete"]();

            // if ($is_edit == FALSE && $is_view == FALSE && empty($extra))
            // {
            //     $action = '-';
            // }

            // $action = $this->generate_actions($params, true, false, false, $extra); //$is_view
            // pre($action);

            // Working
            // $action .= '<a href="javascript:void()" class="btn btn-warning btn-sm report-workflow-data-edit mr-2" data-version-no="'.$value['ticket_id'].'" data-id="'.$value['id'].'" ><i class="fa fa-edit" aria-hidden="true"></i></a>';


            $disabled = '';
            $assign_to_name = '';

            if (!empty($orion_user_data['type'])) {

                if (in_array($orion_user_data['type'], nebula_sw_roles())) {

                    // $action = '<button title="View" data-toggle="modal" data-type="view" data-url="' . base_url() . 'Nebula_dashboard" data-id="' . $value['ticket_id'] . '" class="btn btn-icon btn-xs ml-2 btnView nebula_view_' . $value['ticket_id'] . '"><i class="fa fa-eye"></i></button>';

                    $action = '<a data-type="view" href="'.base_url().'Nebula_dashboard/open_ticket/'.$value['ticket_id'].'"  class="ml-3" style="color:#090a0a;"><i class="fa fa-eye"></i></a>';


                    if (!is_null($value['trainer_id'])) {
                        $disabled = 'disabled';
                    } else {
                        $disabled = '';
                    }

                    // if user id SW_DEV then only show assignee name
                    if ($orion_user_data['type'] == 'SW_DEV') {

                        $priority = ucfirst($value['priority']);

                        $ticket_purpose_type = $this->getRequestType($value['purpose']);
                        // $ticket_purpose_type = ucfirst($value['purpose']);

                        // $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                        /******************** START - Ticket Status dropdown for Developers ********************/
                            
                            // Set column are editable for who have rights 
                            if(in_array(ticket_conversions_status_filter_string(), checkUserPermission($orion_user_data['id'])["ticket_conversions_option"])){

                                $status_type = '<select class="custom-select status_type select2" name="status_type" id="status_type" data-ticket_id="' . $value['ticket_id'] . '" required ' . '>';
                                //MY: Add Comment because make Purpose Value Dynamically
                                //if ($value['purpose'] == 'report_bug' || $value['purpose'] == 'training' || $value['purpose'] == 'feature_request' || $value['purpose'] == 'assign_task') {
                                if (array_key_exists($value['purpose'], $purposeTypesArray)) {
                                    foreach ($get_result[$key]['status_type']['developer_status'] as $training_status_info) {
                                        $is_selected = (strtolower($value['status_type']) == strtolower($training_status_info)) ? 'selected' : '';
                                        $display_status = str_replace('_', ' ', ucwords($training_status_info));

                                        $color_code = "white";
                                        $text_color = "black";
                                        $border_color = "black";

                                        if ($display_status == "Assigned") {
                                            $color_code = '#fff9f2';
                                            $text_color = '#d17c0f';
                                            $border_color = '#d17c0f';
                                        } elseif ($display_status == "Closed") {
                                            $color_code = '#f6fdf9';
                                            $text_color = '#22c56c';
                                            $border_color = '#22c56c';
                                        } elseif ($display_status == "In progress") {
                                            $color_code = '#f6f9ff';
                                            $text_color = '#1c5ecb';
                                            $border_color = '#1c5ecb';
                                        } elseif ($display_status == "On hold") {
                                            $color_code = '#fff7f8';
                                            $text_color = "#f73f50";
                                            $border_color = "#f73f50";
                                        } else {
                                            $color_code = '#9a90d3';
                                            $text_color = "#ffffff";
                                            $border_color = "#ffffff";
                                        }
                                        $status_type .= '<option value="' . $training_status_info . '" ' . $is_selected . ' class="' . $training_status_info . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $display_status . '</option>';
                                    }
                                }
                            }else{
                                $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                            }
                        /******************** END - Ticket Status dropdown for Developers ********************/

                    } else {

                         /******************** START - Ticket Status dropdown ********************/

                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_status_filter_string(), checkUserPermission($orion_user_data['id'])["ticket_conversions_option"])){
                            
                                $status_type = '<select class="custom-select status_type select2" name="status_type" id="status_type" data-ticket_id="' . $value['ticket_id'] . '" required ' . '>';
                                //MY: Add Comment because make Purpose Value Dynamically
                                //if ($value['purpose'] == 'report_bug' || $value['purpose'] == 'training' || $value['purpose'] == 'feature_request' || $value['purpose'] == 'assign_task') {
                                if (array_key_exists($value['purpose'], $purposeTypesArray)) {    
                                    foreach ($get_result[$key]['status_type']['bug_report'] as $training_status_info) {
                                        $is_selected = (strtolower($value['status_type']) == strtolower($training_status_info)) ? 'selected' : '';
                                        $display_status = str_replace('_', ' ', ucwords($training_status_info));


                                        $color_code = "white";
                                        $text_color = "black";
                                        $border_color = "black";

                                        if ($display_status == "Open") {
                                            $color_code = '#f1f1f1';
                                            $text_color = '#333';
                                            $border_color = '#333';
                                        } elseif ($display_status == "Assigned") {
                                            $color_code = '#fff9f2';
                                            $text_color = '#d17c0f';
                                            $border_color = '#d17c0f';
                                        } elseif ($display_status == "Closed") {
                                            $color_code = '#f6fdf9';
                                            $text_color = '#22c56c';
                                            $border_color = '#22c56c';
                                        } elseif ($display_status == "Re open") {
                                            $color_code = '#fbf5f9';
                                            $text_color = "#b02381";
                                            $border_color = "#b02381";
                                        } elseif ($display_status == "In progress") {
                                            $color_code = '#f6f9ff';
                                            $text_color = '#1c5ecb';
                                            $border_color = '#1c5ecb';
                                        } elseif ($display_status == "On hold") {
                                            $color_code = '#fff7f8';
                                            $text_color = "#f73f50";
                                            $border_color = "#f73f50";
                                        } else {
                                            $color_code = '#9a90d3';
                                            $text_color = "#ffffff";
                                            $border_color = "#ffffff";
                                        }
                                        $status_type .= '<option value="' . $training_status_info . '" ' . $is_selected . ' class="' . $training_status_info . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $display_status . '</option>';
                                    }
                                }
                            }else{
                                $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                            }

                        /******************** END - Ticket Status dropdown ********************/

                    }


                        /******************** START - Ticket Purpose Type dropdown ********************/
                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_type_filter_string(), checkUserPermission($orion_user_data['id'])["ticket_conversions_option"])){
                                                    
                                $ticket_purpose_type = '<select class="custom-select change-ticket-purpose" id="change-ticket-priority" data-ticket_id="' . $value['ticket_id'] . '" required>';

                                //MY: Add Comment because make Purpose Value Dynamically
                                //$ticket_purpose_types = ticket_purpose_types();
                                $ticket_purpose_types = purposeTypes();
                                $ticketPurposeProperty = purposeTypeProperty();
                                foreach ($ticket_purpose_types as $option_k => $option_v) {
                                    $selected = ($value['purpose'] == $option_k) ? 'selected' : '';
                                    if (isset($ticketPurposeProperty[$option_k])) {
                                        $propertyData = $ticketPurposeProperty[$option_k];
                                        $color_code = $propertyData['background_color'];
                                        $text_color = $propertyData['color'];
                                        $border_color = $propertyData['border_color'];
                                    }

                                    /* if ($option_v == 'Bug') {
                                        $color_code = '#fff7f8';
                                        $text_color = "#f73f50";
                                        $border_color = "#f73f50";
                                    } elseif ($option_v == 'Feature') {
                                        $color_code = '#f6fdf9';
                                        $text_color = '#22c56c';
                                        $border_color = '#22c56c';
                                    } elseif ($option_v == 'Training') {
                                        $color_code = '#fff9f2';
                                        $text_color = '#d17c0f';
                                        $border_color = '#d17c0f';
                                    } elseif ($option_v == 'Task') {
                                        $color_code = '#f0f2fe';
                                        $text_color = "#0504fb";
                                        $border_color = "#0504fb";
                                    } */
                                    $option_v = strtok($option_v, " ");
                                    $ticket_purpose_type .= '<option value="' . $option_k . '" ' . $selected . ' class="' . $option_k . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $option_v . '</option>';
                                }

                                $ticket_purpose_type .= '</select>';
                            }else{
                                $ticket_purpose_type = $this->getRequestType($value['purpose']);
                            }

                        /******************** END - Ticket Purpose Type dropdown ********************/

                        /******************** START - Ticket Priority dropdown ********************/
                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_priority_filter_string(), checkUserPermission($orion_user_data['id'])["ticket_conversions_option"])){
                            
                                $priority = '<select class="custom-select change-ticket-priority" id="change-ticket-priority" data-ticket_id="' . $value['ticket_id'] . '" required>';

                                $priorityOptions = priorityOptions();

                                foreach ($priorityOptions as $option_k => $option_v) {
                                        $selected = '';
                                        if($value['priority'] == $option_k){
                                            $selected = 'selected';
                                        }else{
                                            $selected = '';
                                        }

                                    if ($option_v == 'Low') {
                                        $color_code = '#f6fdf9';
                                        $text_color = '#22c56c';
                                        $border_color = '#22c56c';
                                    } elseif ($option_v == 'Normal') {
                                        $color_code = '#fff9f2';
                                        $text_color = '#d17c0f';
                                        $border_color = '#d17c0f';
                                    } elseif ($option_v == 'High') {
                                        $color_code = '#fff7f8';
                                        $text_color = "#f73f50";
                                        $border_color = "#f73f50";
                                    }
                                        else {
                                            $color_code = '#fffbf0';  
                                            $text_color = "#9b59b6";
                                            $border_color = "#9b59b6";
                                        }

                                    $priority .= '<option value="' . $option_k . '" ' . $selected . ' class="' . $option_k . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $option_v . '</option>';
                                }

                                $priority .= '</select>';
                            }else{
                                $priority = ucfirst($value['priority']);
                            }
                        /******************** END - Ticket Priority dropdown ********************/

                        /******************** START - Ticket Assign To dropdown ********************/

                            if(in_array(ticket_conversions_assign_to_filter_string(), checkUserPermission($orion_user_data['id'])["ticket_conversions_option"])){
                            
                                // able to assign/change developer
                                $assign_to_name = '<select class="custom-select trainer list_assign_to_cls" name="trainer[]" id="list_assign_to" data-ticket_id="' . $value['ticket_id'] . '" required multiple>';
                                if (is_null($value['trainer_id']) || empty($value['trainer_id'])) {
                                    $assign_to_name .= '<option value="">-- Assign To --</option>';
                                }
    
                                foreach ($get_result[$key]['trainer_id'] as $trainer_info) {
                                    // Check if the current assign to is selected
                                    $is_selected = in_array($trainer_info['id'], array_column($get_assignee['current_assignee'], 'id')) ? 'selected' : '';
                                    $assign_to_name .= '<option value="' . $trainer_info['id'] . '" ' . $is_selected . '>' . ucwords(htmlspecialchars($trainer_info['first_name'])) . '</option>';
                                }
                                $assign_to_name .= '</select>';
                            }else{
                                // Show only developer name
                                $assign_to_name = $this->getTrainerNames($orion_user_data['id']);

                                $assign_to_name = $assign_to_name['current_assignee'];
                                $names = array_map(function ($item) {
                                    return $item['first_name'];
                                }, $assign_to_name);
                                $assign_to_name = implode(', ', $names);
                                $assign_to_name = (!empty($assign_to_name)) ? str_replace('_', ' ', ucwords($assign_to_name)) : 'Not Assign Yet';

                            }

                        /******************** END - Ticket Assign To dropdown ********************/
                } else {

                    // $action = '<button title="View" data-toggle="modal" data-type="view" data-url="' . base_url() . '/Nebula_dashboard" data-id="' . $value['ticket_id'] . '" class="btn btn-icon btn-xs ml-2 btnView nebula_view_' . $value['ticket_id'] . '"><i class="fa fa-eye"></i></button>';

                    // $action = '<button title="View" data-toggle="modal" data-type="view" data-url="'.base_url().'/Nebula_dashboard" data-id="'. $value['ticket_id'] .'" class="btn btn-icon btn-xs ml-2 btnView nebula_view_'. $value['ticket_id'] .'"><i class="fa fa-eye"></i></button>';

                    $action = '<a data-type="view" href="'.base_url().'Nebula_dashboard/open_ticket/'.$value['ticket_id'].'"  class="ml-3" style="color:#090a0a;"><i class="fa fa-eye"></i></a>';

                    $priority = ucfirst($value['priority']);

                    $ticket_purpose_type = $this->getRequestType($value['purpose']);
                    // $ticket_purpose_type = ucfirst($value['purpose']);

                    $disabled = 'disabled';

                    // $status_type = str_replace('_', ' ', ucwords($value['status_type']));

                    if($value['status_type'] == 'closed'){
                        $status_type = '<select class="custom-select status_type select2" name="status_type" id="status_type" data-ticket_id="' . $value['ticket_id'] . '" required ' . '>';

                        //MY: Add Comment because make Purpose Value Dynamically
                        //if ($value['purpose'] == 'report_bug' || $value['purpose'] == 'training' || $value['purpose'] == 'feature_request' || $value['purpose'] == 'assign_task') {
                        if (array_key_exists($value['purpose'], $purposeTypesArray)) {

                            $get_result[$key]['status_type']['bug_report'] = array("closed", "re_open");

                            foreach ($get_result[$key]['status_type']['bug_report'] as $training_status_info) {
                                $is_selected = (strtolower($value['status_type']) == strtolower($training_status_info)) ? 'selected' : '';
                                $display_status = str_replace('_', ' ', ucwords($training_status_info));

                                if ($display_status == "Closed") {
                                    $color_code = '#f6fdf9';
                                    $text_color = '#22c56c';
                                    $border_color = '#22c56c';
                                } elseif ($display_status == "Re open") {
                                    $color_code = '#fbf5f9';
                                    $text_color = "#b02381";
                                    $border_color = "#b02381";
                                }else {
                                    $color_code = '#9a90d3';
                                    $text_color = "#ffffff";
                                    $border_color = "#ffffff";
                                }

                                $status_type .= '<option value="' . $training_status_info . '" ' . $is_selected . ' class="' . $training_status_info . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $display_status . '</option>';
                            }
                        }

                    }else{
                        $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                    }

                    // $assign_to_name = $this->getAssignToName($value['trainer_id']);

                    $assign_to_name = $this->getTrainerNames($value['trainer_id']);
                    $assign_to_name = $assign_to_name['current_assignee'];
                    $names = array_map(function ($item) {
                        return $item['first_name'];
                    }, $assign_to_name);
                    $assign_to_name = implode(', ', $names);

                    $assign_to_name = (!empty($assign_to_name)) ? str_replace('_', ' ', ucwords($assign_to_name)) : 'Not Assign Yet';
                }
            } else {
                // if $orion_user_data['type'] is empty
                // Permission to access the view page and list page
                if (in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {

                    // || in_array($orion_user_data['type'], nebula_sw_roles())

                    //$action = '<button title="View" data-toggle="modal" data-type="view" data-url="' . base_url() . '/Nebula_dashboard" data-id="' . $value['ticket_id'] . '" class="btn btn-icon btn-xs ml-2 btnView nebula_view_' . $value['ticket_id'] . '"><i class="fa fa-eye"></i></button>';

                    $action = '<a data-type="view" href="'.base_url().'Nebula_dashboard/open_ticket/'.$value['ticket_id'].'"  class="ml-3" style="color:#090a0a;"><i class="fa fa-eye"></i></a>';

                    if (!is_null($value['trainer_id'])) {
                        $disabled = 'disabled';
                    } else {
                        $disabled = '';
                    }

                    // if user id SW_DEV then only show assignee name
                    if (getCurrentLoggedInUserType() == 'SW_DEV') {

                        /******************** START - Ticket Status dropdown for Developers ********************/
                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_status_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_conversions_option"])){

                                $status_type = '<select class="custom-select status_type select2" name="status_type" id="status_type" data-ticket_id="' . $value['ticket_id'] . '" required ' . '>';
                                //MY: Add Comment because make Purpose Value Dynamically
                                //if ($value['purpose'] == 'report_bug' || $value['purpose'] == 'training' || $value['purpose'] == 'feature_request' || $value['purpose'] == 'assign_task') {
                                if (array_key_exists($value['purpose'], $purposeTypesArray)) {
                                    foreach ($get_result[$key]['status_type']['developer_status'] as $training_status_info) {
                                        $is_selected = (strtolower($value['status_type']) == strtolower($training_status_info)) ? 'selected' : '';
                                        $display_status = str_replace('_', ' ', ucwords($training_status_info));

                                        $color_code = "white";
                                        $text_color = "black";
                                        $border_color = "black";

                                        if ($display_status == "Assigned") {
                                            $color_code = '#fff9f2';
                                            $text_color = '#d17c0f';
                                            $border_color = '#d17c0f';
                                        } elseif ($display_status == "Closed") {
                                            $color_code = '#f6fdf9';
                                            $text_color = '#22c56c';
                                            $border_color = '#22c56c';
                                        } elseif ($display_status == "In progress") {
                                            $color_code = '#f6f9ff';
                                            $text_color = '#1c5ecb';
                                            $border_color = '#1c5ecb';
                                        } elseif ($display_status == "On hold") {
                                            $color_code = '#fff7f8';
                                            $text_color = "#f73f50";
                                            $border_color = "#f73f50";
                                        } else {
                                            $color_code = '#9a90d3';
                                            $text_color = "#ffffff";
                                            $border_color = "#ffffff";
                                        }
                                        $status_type .= '<option value="' . $training_status_info . '" ' . $is_selected . ' class="' . $training_status_info . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $display_status . '</option>';
                                    }
                                }
                            }else{
                                $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                            }
                            
                        /******************** END - Ticket Status dropdown for Developers ********************/

                    } else {

                        /******************** START - Ticket Status dropdown ********************/

                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_status_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_conversions_option"])){
                            
                                $status_type = '<select class="custom-select status_type select2" name="status_type" id="status_type" data-ticket_id="' . $value['ticket_id'] . '" required ' . '>';
                                //MY: Add Comment because make Purpose Value Dynamically
                                //if ($value['purpose'] == 'report_bug' || $value['purpose'] == 'training' || $value['purpose'] == 'feature_request' || $value['purpose'] == 'assign_task') {
                                if (array_key_exists($value['purpose'], $purposeTypesArray)) {
                                    foreach ($get_result[$key]['status_type']['bug_report'] as $training_status_info) {
                                        $is_selected = (strtolower($value['status_type']) == strtolower($training_status_info)) ? 'selected' : '';
                                        $display_status = str_replace('_', ' ', ucwords($training_status_info));


                                        $color_code = "white";
                                        $text_color = "black";
                                        $border_color = "black";

                                        if ($display_status == "Open") {
                                            $color_code = '#f1f1f1';
                                            $text_color = '#333';
                                            $border_color = '#333';
                                        } elseif ($display_status == "Assigned") {
                                            $color_code = '#fff9f2';
                                            $text_color = '#d17c0f';
                                            $border_color = '#d17c0f';
                                        } elseif ($display_status == "Closed") {
                                            $color_code = '#f6fdf9';
                                            $text_color = '#22c56c';
                                            $border_color = '#22c56c';
                                        } elseif ($display_status == "Re open") {
                                            $color_code = '#fbf5f9';
                                            $text_color = "#b02381";
                                            $border_color = "#b02381";
                                        } elseif ($display_status == "In progress") {
                                            $color_code = '#f6f9ff';
                                            $text_color = '#1c5ecb';
                                            $border_color = '#1c5ecb';
                                        } elseif ($display_status == "On hold") {
                                            $color_code = '#fff7f8';
                                            $text_color = "#f73f50";
                                            $border_color = "#f73f50";
                                        } else {
                                            $color_code = '#9a90d3';
                                            $text_color = "#ffffff";
                                            $border_color = "#ffffff";
                                        }
                                        $status_type .= '<option value="' . $training_status_info . '" ' . $is_selected . ' class="' . $training_status_info . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $display_status . '</option>';
                                    }
                                }
                            }else{
                                $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                            }

                        /******************** END - Ticket Status dropdown ********************/

                    }

                        /******************** START - Ticket Purpose Type dropdown ********************/
                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_type_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_conversions_option"])){
                                                    
                                $ticket_purpose_type = '<select class="custom-select change-ticket-purpose" id="change-ticket-priority" data-ticket_id="' . $value['ticket_id'] . '" required>';

                                //MY: Add Comment because make Purpose Value Dynamically
                                //$ticket_purpose_types = ticket_purpose_types();
                                $ticket_purpose_types = purposeTypes();
                                $ticketPurposeProperty = purposeTypeProperty();
                                foreach ($ticket_purpose_types as $option_k => $option_v) {
                                    $selected = ($value['purpose'] == $option_k) ? 'selected' : '';
                                    if (isset($ticketPurposeProperty[$option_k])) {
                                        $propertyData = $ticketPurposeProperty[$option_k];
                                        $color_code = $propertyData['background_color'];
                                        $text_color = $propertyData['color'];
                                        $border_color = $propertyData['border_color'];
                                    }
                                    /* if ($option_v == 'Bug') {
                                        $color_code = '#fff7f8';
                                        $text_color = "#f73f50";
                                        $border_color = "#f73f50";
                                    } elseif ($option_v == 'Feature') {
                                        $color_code = '#f6fdf9';
                                        $text_color = '#22c56c';
                                        $border_color = '#22c56c';
                                    } elseif ($option_v == 'Training') {
                                        $color_code = '#fff9f2';
                                        $text_color = '#d17c0f';
                                        $border_color = '#d17c0f';
                                    } elseif ($option_v == 'Task') {
                                        $color_code = '#f0f2fe';
                                        $text_color = "#0504fb";
                                        $border_color = "#0504fb";
                                    } */
                                    $option_v = strtok($option_v, " ");
                                    $ticket_purpose_type .= '<option value="' . $option_k . '" ' . $selected . ' class="' . $option_k . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $option_v . '</option>';
                                }

                                $ticket_purpose_type .= '</select>';
                            }else{
                                $ticket_purpose_type = $this->getRequestType($value['purpose']);
                            }

                        /******************** END - Ticket Purpose Type dropdown ********************/

                        /******************** START - Ticket Priority dropdown ********************/
                            // Set column are editable for who have rights
                            if(in_array(ticket_conversions_priority_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_conversions_option"])){
                            
                                $priority = '<select class="custom-select change-ticket-priority" id="change-ticket-priority" data-ticket_id="' . $value['ticket_id'] . '" required>';

                                $priorityOptions = priorityOptions();

                                foreach ($priorityOptions as $option_k => $option_v) {
                                        $selected = '';
                                        if($value['priority'] == $option_k){
                                            $selected = 'selected';
                                        }else{
                                            $selected = '';
                                        }

                                    if ($option_v == 'Low') {
                                        $color_code = '#f6fdf9';
                                        $text_color = '#22c56c';
                                        $border_color = '#22c56c';
                                    } elseif ($option_v == 'Normal') {
                                        $color_code = '#fff9f2';
                                        $text_color = '#d17c0f';
                                        $border_color = '#d17c0f';
                                    } elseif ($option_v == 'High') {
                                        $color_code = '#fff7f8';
                                        $text_color = "#f73f50";
                                        $border_color = "#f73f50";
                                    }
                                        else {
                                            $color_code = '#fffbf0';  
                                            $text_color = "#9b59b6";
                                            $border_color = "#9b59b6";
                                        }

                                    $priority .= '<option value="' . $option_k . '" ' . $selected . ' class="' . $option_k . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $option_v . '</option>';
                                }

                                $priority .= '</select>';
                            }else{
                                $priority = ucfirst($value['priority']);
                            }
                        /******************** END - Ticket Priority dropdown ********************/

                        /******************** START - Ticket Assign To dropdown ********************/

                            if(in_array(ticket_conversions_assign_to_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_conversions_option"])){
                            
                                // able to assign/change developer
                                $assign_to_name = '<select class="custom-select trainer list_assign_to_cls" name="trainer[]" id="list_assign_to" data-ticket_id="' . $value['ticket_id'] . '" required multiple>';
                                if (is_null($value['trainer_id']) || empty($value['trainer_id'])) {
                                    $assign_to_name .= '<option value="">-- Assign To --</option>';
                                }

                                // pre($get_result[$key]['trainer_id']);
                                foreach ($get_result[$key]['trainer_id'] as $trainer_info) {
                                    // Check if the current assign to is selected
                                    // pre($trainer_info['id'],0);
                                    $is_selected = in_array($trainer_info['id'], array_column($get_assignee['current_assignee'], 'id')) ? 'selected' : '';
                                    $assign_to_name .= '<option value="' . $trainer_info['id'] . '" ' . $is_selected . '>' . ucwords(htmlspecialchars($trainer_info['first_name'])) . '</option>';
                                }
                                $assign_to_name .= '</select>';
                            }else{
                                // Show only developer name
                                $assign_to_name = $this->getTrainerNames($value['trainer_id']);
                                $assign_to_name = $assign_to_name['current_assignee'];
                                $names = array_map(function ($item) {
                                    return $item['first_name'];
                                }, $assign_to_name);
                                $assign_to_name = implode(', ', $names);
                                $assign_to_name = (!empty($assign_to_name)) ? str_replace('_', ' ', ucwords($assign_to_name)) : 'Not Assign Yet';
                            }

                        /******************** END - Ticket Assign To dropdown ********************/
                } else {

                    // $action = '<button title="View" data-toggle="modal" data-type="view" data-url="' . base_url() . '/Nebula_dashboard" data-id="' . $value['ticket_id'] . '" class="btn btn-icon btn-xs ml-2 btnView nebula_view_' . $value['ticket_id'] . '"><i class="fa fa-eye"></i></button>';

                    // $action = '<button title="View" data-toggle="modal" data-type="view" data-url="'.base_url().'/Nebula_dashboard" data-id="'. $value['ticket_id'] .'" class="btn btn-icon btn-xs ml-2 btnView nebula_view_'. $value['ticket_id'] .'"><i class="fa fa-eye"></i></button>';

                    $action = '<a data-type="view" href="'.base_url().'Nebula_dashboard/open_ticket/'.$value['ticket_id'].'"  class="ml-3" style="color:#090a0a;"><i class="fa fa-eye"></i></a>';

                    $priority = ucfirst($value['priority']);

                    $ticket_purpose_type = $this->getRequestType($value['purpose']);
                    // $ticket_purpose_type = ucfirst($value['purpose']);

                    $disabled = 'disabled';

                    if($value['status_type'] == 'closed'){
                        $status_type = '<select class="custom-select status_type select2" name="status_type" id="status_type" data-ticket_id="' . $value['ticket_id'] . '" required ' . '>';

                        //MY: Add Comment because make Purpose Value Dynamically
                        //if ($value['purpose'] == 'report_bug' || $value['purpose'] == 'training' || $value['purpose'] == 'feature_request' || $value['purpose'] == 'assign_task') {
                        if (array_key_exists($value['purpose'], $purposeTypesArray)) {
                            $get_result[$key]['status_type']['bug_report'] = array("closed", "re_open");

                            foreach ($get_result[$key]['status_type']['bug_report'] as $training_status_info) {
                                $is_selected = (strtolower($value['status_type']) == strtolower($training_status_info)) ? 'selected' : '';
                                $display_status = str_replace('_', ' ', ucwords($training_status_info));

                                if ($display_status == "Closed") {
                                    $color_code = '#f6fdf9';
                                    $text_color = '#22c56c';
                                    $border_color = '#22c56c';
                                } elseif ($display_status == "Re open") {
                                    $color_code = '#fbf5f9';
                                    $text_color = "#b02381";
                                    $border_color = "#b02381";
                                }

                                $status_type .= '<option value="' . $training_status_info . '" ' . $is_selected . ' class="' . $training_status_info . '" style="background-color:' . $color_code . '; color: ' . $text_color . '; border: 1px solid ' . $border_color . ';" data-color_code="' . $color_code . '">' . $display_status . '</option>';
                            }
                        }

                    }else{
                        $status_type = str_replace('_', ' ', ucwords($value['status_type']));
                    }

                    // $assign_to_name = $this->getAssignToName($value['trainer_id']);

                    $assign_to_name = $this->getTrainerNames($value['trainer_id']);
                    $assign_to_name = $assign_to_name['current_assignee'];
                    $names = array_map(function ($item) {
                        return $item['first_name'];
                    }, $assign_to_name);
                    $assign_to_name = implode(', ', $names);

                    $assign_to_name = (!empty($assign_to_name)) ? str_replace('_', ' ', ucwords($assign_to_name)) : 'Not Assign Yet';
                }
            }


            // Check user access
            $is_status_disabled = (getCurrentLoggedInUserType() != 'software') ? 'disabled' : '';

            // $request_type = '';
            // if($value['purpose'] == 'training'){
            //     $request_type = 'Training';
            // }elseif($value['purpose'] == 'report_bug'){
            //     $request_type = 'Bug';
            // }elseif($value['purpose'] == 'feature_request'){
            //     $request_type = 'Feature';
            // }

            $ticket_tags_string = '';

            if (!empty($value['ticket_tags'])) {
                $ticket_tags = explode(',', $value['ticket_tags']);

                foreach ($ticket_tags as $k => $v) {
                    $v = str_replace('#', '', $v);
                    // $ticket_tags_string .= '<span class="badge bg-dark">' . $v . '</span> ';
                    $ticket_tags_string .= '<span class="badge badge-dark mr-1 mb-1n admin_list_remove_tag" data-tag_ticket_id="' . $value['ticket_id'] . '" >' . $v . '<span class="rmTag ml-1" style="cursor: pointer; color: white;" data-tag_badge="' . $v . '">  x </span>' . '</span> ';
                }
            }
            // pre($ticket_tags_string);

            $value['created'] = $this->nebula_mapper_model->getDateTimeFormat($value['created']);
            if(!empty($value['updated'])){
                $value['updated'] = $this->nebula_mapper_model->getDateTimeFormat($value['updated']);
            }else{
                $value['updated'] = '';
            }

            // Working 
            $result['data'][] = array(

                'ticket_id' => $value['ticket_id'],

                'purpose' => $ticket_purpose_type,

                // 'notes' => ($value['notes'] != '' ? $value['notes'] : '-'),

                'title' => ($value['title'] != '' ? $value['title'] : '-'),

                'orion_department' => ($get_result[$key]['orion_department'] != '' ? $get_result[$key]['orion_department'] : '-'),

                'orion_module' => ($value['orion_module'] != '' ? $value['orion_module'] : '-'),

                // 'sw_tl_id' => ($get_result[$key]['sw_tl_id'] != '' ? $get_result[$key]['sw_tl_id'] : '-'),

                'trainer_id' => $assign_to_name,

                // 'priority' => (ucfirst($value['priority']) != '' ? ucfirst($value['priority']) : '-'),
                'priority' => $priority,

                'status_type' => $status_type,

                'ticket_tags' => $ticket_tags_string,

                'created' => ($value['created'] != '' ? $value['created'] : '-'),

                'updated' => ($value['updated'] != '' ? $value['updated'] : ''),

                'created_by' => (!empty($get_created_by_user)) ? $get_created_by_user : '-',

                'action' => $action
            );
        }

        $return_count_data  = $this->show_requistion_list_helper(["filters" => $filters, "data" => $data, "flag" => "count"]);
        // pre($return_count_data);

        $result['get_all_tab_count'] = $return_count_data['get_all_tab_count'];
        // pre($result['get_all_tab_count']);

        $result['get_all_today_status_count'] = $return_count_data['get_all_today_status_count'];
        // pre($result['get_all_today_status_count']);

        $result["recordsTotal"] = (int)count($return_count_data["get_result"]);
        $result["recordsFiltered"] = (int)count($return_count_data["get_result"]);
        $result["table_heading"] = $header_data;

        $result['all_final_dept'] = implode(',', $data['filter_global']['selectedDepartment']);

        // pre($return_data['get_all_tab_count']['all_type']);
        // $get_result['dept_final_count_values'] = implode(',', array_values($return_data['get_all_tab_count']['all_type']));
        // pre($get_result['dept_final_count_values']);

        return $result;
    }

    public function show_requistion_list_helper($param = array())
    {


        extract($param["filters"]);
        $data = $param["data"];
        $flag = $param["flag"];

        $likeArr = array();
        $purposeTypesArray = purposeTypes();//MY: Get Purpose Type

        if (!empty($search)) {
            $likeArr['form_mst.ticket_id'] = $search;
            $likeArr['form_mst.title'] = $search;
            $likeArr['form_mst.ticket_tags'] = $search;
            $likeArr['form_mst.orion_department'] = $search;
            $likeArr['form_mst.orion_module'] = $search;
            $likeArr['form_mst.notes'] = $search;
            $likeArr['form_mst.trainer_id'] = $search;
        }

        // To get All Tabs(statuses) count
        $get_all_tab_count = $this->getStatusCountAllTabs($param);
        // pre($get_all_tab_count);

        // $get_all_today_status_count = $get_all_tab_count['get_all_today_status_count'];
        // pre($get_all_today_status_count);

        // $get_all_tab_count = $get_all_tab_count['status_counts'];
        // pre($get_all_tab_count);



        // $this->second_db->select('form_mst.id, form_mst.ticket_id, form_mst.title, form_mst.purpose,form_mst.notes,form_mst.orion_department, form_mst.orion_module, form_mst.dept_tl, form_mst.sw_tl_id, form_mst.trainer_id, form_mst.priority, form_mst.status_type, form_mst.created, form_mst.updated, form_mst.ticket_tags')
        $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('is_deleted', '0');
            // ->order_by('form_mst.ticket_id', 'desc');

        // START - Conditions for tab change
            if ($data['tab_id'] == 'open_datatable') {
                $this->second_db->where_in('form_mst.status_type', ['open', 're_open']);
            } elseif ($data['tab_id'] == 'assigned_datatable') {
                $this->second_db->where('form_mst.status_type', 'assigned');
            } elseif ($data['tab_id'] == 'on_hold_datatable') {
                $this->second_db->where('form_mst.status_type', 'on_hold');
            } elseif ($data['tab_id'] == 'in_progress_datatable') {
                $this->second_db->where('form_mst.status_type', 'in_progress');
            } elseif ($data['tab_id'] == 'closed_datatable') {
                $this->second_db->where('form_mst.status_type', 'closed');
            }
            // elseif($data['tab_id'] == 're_open_datatable'){
            //     $this->second_db->where('form_mst.status_type', 're_open');
            // }
            elseif ($data['tab_id'] == 'not_a_bug_datatable') {
                $this->second_db->where('form_mst.status_type', 'not_a_bug');
            }
        // END - Conditions for tab change

        // START - Conditions for Flters : Department
            if (!empty($data['filter_global']['selectedDepartment'])) {
                $this->second_db->where_in('form_mst.orion_department', $data['filter_global']['selectedDepartment']);
            }
        // END - Conditions for Flters : Department

        // START - Conditions for Flters : Ticket Purpose
            if (!empty($data['filter_global']['selectedType'])) {
                //MY: Add Comment because make Purpose Value Dynamically
                if (array_key_exists($data['filter_global']['selectedType'], $purposeTypesArray)) {
                    $this->second_db->where('form_mst.purpose', $data['filter_global']['selectedType']);
                }
            }
        // END - Conditions for Flters : Ticket Purpose

        // START - Conditions for Flters : Date
            if (!empty($data['filter_global']['report_start_date'])) {
                $start_date = $data['filter_global']['report_start_date'] . ' 00:00:00';
                
                if(!empty($data['filter_global']['selectedCreatedUpdated'])){
                    if($data['filter_global']['selectedCreatedUpdated'] == 'created_at'){
                        $this->second_db->where('form_mst.created >=', $start_date);
                    }elseif($data['filter_global']['selectedCreatedUpdated'] == 'updated_at'){
                        $this->second_db->group_start()
                                        ->where('form_mst.created >=', $start_date)
                                        ->or_where('form_mst.updated >=', $start_date)
                                    ->group_end();
                    }
                }else{
                    $this->second_db->where('form_mst.created >=', $start_date);
                }
            
                if (!empty($data['filter_global']['report_end_date'])) {
                    $end_date = $data['filter_global']['report_end_date'] . ' 23:59:59';

                    $this->second_db->where('form_mst.created <=', $end_date);
                }
            }
        // END - Conditions for Flters : Date

        // START - Conditions for Flters : Ticket Current Status
            if(!empty($data['filter_global']['selectedStatus'])){
                $this->second_db->where_in('form_mst.status_type', $data['filter_global']['selectedStatus']);
            }
        // END - Conditions for Flters : Ticket Current Status

        // START - Query to get data from tbl_users for SW_ADMIN screen 
            if (!empty($data['orion_user'])) {
                $orion_username = $data['orion_user'];
                $orion_user_data = $this->db->select('tbl_users.id, tbl_users.type, tbl_users.name, tbl_users.email')
                    ->from('tbl_users')
                    ->where('tbl_users.username', $orion_username)
                    ->get()->row_array();
            }
        // END - Query to get data from tbl_users for SW_ADMIN screen 

        // START - if user dont have access of all dept then 
            if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                
                // if user have own dept access
                if(in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                    // if user is SW_DEV then only access SW depts
                    if (getCurrentLoggedInUserType() == 'SW_DEV') {
                        $data['loggedInUserDept'] = nebula_sw_roles();
                    }
                    $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                }else{
                    // if user expect SW_DEV then get records 
                    if (getCurrentLoggedInUserType() != 'SW_DEV') {
                        $this->second_db->where('form_mst.inserted_by', getCurrentLoggedInUserID());
                    }
                }                    
            }
        // END - if user dont have access of all dept then 

        // START - if users expect SW's they dont show tickets whos purpose is 'task_assign'
            if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
            }
        // END - if users expect SW's they dont show tickets whos purpose is 'task_assign'
        
        // START - if user have access of all dept then 
            if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

                // if user type is other than 'SW' then remove 'SW' users 
                if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                    foreach($data['loggedInUserDept'] as $key => $value){
                        if(in_array($value, nebula_sw_roles())){
                            unset($data['loggedInUserDept'][$key]);
                        }
                    }
                    $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                }
            }
        // END - if user have access of all dept then 

        // START - SW_ADMIN can serach any users screen's data 
        // Show orion_user's data with their id to get only selected user's data (for sw_admin login to search other user's screen)
            if (!empty($data['orion_user']) && !in_array($orion_user_data['type'], nebula_sw_roles())) {

                // To get depts 
                $data['loggedInUserDept'] = $this->getLoggedInUserDepartment($orion_user_data['id']);
                
                // If users expect SW's they dont show tickets whos purpose is 'task_assign'
                if(!in_array($orion_user_data['type'], nebula_sw_roles())){
                    $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                }

                if(!in_array(all_department_ticket_string(), checkUserPermission($orion_user_data['id'])["ticket_show_hide"])){
                    if(in_array(own_department_ticket_string(), checkUserPermission($orion_user_data['id'])["ticket_show_hide"])){
                        if ($orion_user_data['type'] == 'SW_DEV') {
                            $data['loggedInUserDept'] = nebula_sw_roles();
                        }
                        $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                    }else{
                        if ($orion_user_data['type'] != 'SW_DEV') {
                            $this->second_db->where('form_mst.inserted_by', $orion_user_data['id']);
                        }
                    }   
                } 

                // To get selected developer's assign tickets only (for sw_admin login to search dev's screen)
                if ($orion_user_data['type'] == 'SW_DEV') {
                    $this->second_db->group_start()
                        ->where('FIND_IN_SET(' . $orion_user_data['id'] . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                        ->or_where('form_mst.inserted_by', $orion_user_data['id']) // this condition to shows ticket created by searched developer
                    ->group_end();
                }
            }
        // END - SW_ADMIN can serach any users screen's data 

        // START - To get current assignee developer data (for dev login)
            if (getCurrentLoggedInUserType() == 'SW_DEV') {
                if(!in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) && !in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                        $this->second_db->group_start()
                            ->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                            ->or_where('form_mst.inserted_by', getCurrentLoggedInUserID()) // this condition to shows ticket created by loggnedIn developer
                        ->group_end();
                }
            }
        // END - To get current assignee developer data (for dev login)


        if (!empty($likeArr)) {

            $this->second_db->group_start()
                    ->like('ticket_id', $search)
                    ->or_like('notes', $search)
                    ->or_like('title', $search)
                    ->or_like('ticket_tags', $search)
                    ->or_like('orion_department', $search)
                    ->or_like('orion_module', $search)
                    ->or_like('trainer_id', $search)
                    ->or_like($likeArr)
                ->group_end();
        }

        if (!empty($flag) && $flag == "count") {
            $get_result = $this->second_db->get()->result_array();
        } else {

            switch (strtolower($sort))
            {
                    
                case 'ticket_id':
                                    $this->second_db->order_by("form_mst.ticket_id",$order);
                                    break;
                case 'created':
                                    $this->second_db->order_by("form_mst.created",$order);
                                    break;
                case 'purpose':
                                    $this->second_db->order_by("form_mst.purpose",$order);
                                    break;
                case 'priority':
                                    $this->second_db->order_by("form_mst.priority",$order);
                                    break;
                case 'title':
                                    $this->second_db->order_by("form_mst.title",$order);
                                    break;
                case 'orion_department':
                                    $this->second_db->order_by("form_mst.orion_department",$order);
                                    break;
                case 'orion_module':
                                    $this->second_db->order_by("form_mst.orion_module",$order);
                                    break;
                case 'trainer_id':
                                    $this->second_db->order_by("form_mst.trainer_id",$order);
                                    break;
                case 'status_type':
                                    $this->second_db->order_by("form_mst.status_type",$order);
                                    break;
                case 'ticket_tags':
                                    $this->second_db->order_by("form_mst.ticket_tags",$order);
                                    break;
                case 'created_by':
                                    $this->second_db->order_by("form_mst.inserted_by",$order);
                                    break;
                default:
                                    $this->second_db->order_by("form_mst.ticket_id", $order);        
                                    break;
            }
            
            $get_result = $this->second_db->limit($limit, $offset)->get()->result_array();
            // pre($get_result);
            // pre($this->second_db->last_query());
           
        }
        return ["get_result" => $get_result, "orion_user_data" => $orion_user_data, "get_all_tab_count" => $get_all_tab_count];
    }

    public function getLatestTimezone(){
        $timezone_result = $this->second_db->select('timezone_date_time.*')
                                        ->from('nebula_mapper_timezone_date_time AS timezone_date_time')  // Table alias should be defined correctly
                                        ->get()
                                        ->row_array();  
                                        
                                    
        return $timezone_result;

    }

    public function getStatusCountAllTabs($param = array())
    {

        extract($param["filters"]);
        $data = $param["data"];
        $flag = $param["flag"];

        if (!empty($data['orion_user'])) {
            $orion_username = $data['orion_user'];
            $orion_user_data = $this->db->select('tbl_users.id, tbl_users.type, tbl_users.name, tbl_users.email')
                ->from('tbl_users')
                ->where('tbl_users.username', $orion_username)
                ->get()->row_array();
            // pre($orion_user_data);
        }
        
        $purposeTypesArray = purposeTypes();//MY: Get Purpose Type
        $result = $this->second_db->select('status_type, COUNT(*) as status_count')
            ->from('nebula_form_mst form_mst')
            ->where('is_deleted', '0')
            ->group_by('status_type')
            ->order_by('status_type', 'asc');
        // ->get()->result_array();
        // pre($result);

        // START - if user dont have access of all dept then 
            if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                
                // If user have own dept access
                if(in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                    // If user is SW_DEV then only access SW depts
                    if (getCurrentLoggedInUserType() == 'SW_DEV') {
                        $data['loggedInUserDept'] = nebula_sw_roles();
                    }
                    $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                }else{
                    // If user expect SW_DEV then get records 
                    if (getCurrentLoggedInUserType() != 'SW_DEV') {
                        $this->second_db->where('form_mst.inserted_by', getCurrentLoggedInUserID());
                    }
                }                    
            }
        // END - if user dont have access of all dept then 

        // START - if users expect SW's they dont show tickets whos purpose is 'task_assign'
            if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
            }
        // END - if users expect SW's they dont show tickets whos purpose is 'task_assign'

        // START - if user have access of all dept then 
            if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

                // If user type is other than 'SW' then remove 'SW' users
                if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                    foreach($data['loggedInUserDept'] as $key => $value){
                        if(in_array($value, nebula_sw_roles())){
                            unset($data['loggedInUserDept'][$key]);
                        }
                    }   
                    $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                }
            }
        // END - if user have access of all dept then 
       

        // START - SW_ADMIN can serach any users screen's data
        // Show orion_user's data with their id to get only selected user's data (for sw_admin login to search other user's screen)
            if (!empty($data['orion_user']) && !in_array($orion_user_data['type'], nebula_sw_roles())) {

                // To get depts 
                $data['loggedInUserDept'] = $this->getLoggedInUserDepartment($orion_user_data['id']);

                // If users expect SW's they dont show tickets whos purpose is 'task_assign'
                if(!in_array($orion_user_data['type'], nebula_sw_roles())){
                    $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                }

                if(!in_array(all_department_ticket_string(), checkUserPermission($orion_user_data['id'])["ticket_show_hide"])){
                    if(in_array(own_department_ticket_string(), checkUserPermission($orion_user_data['id'])["ticket_show_hide"])){
                        if ($orion_user_data['type'] == 'SW_DEV') {
                            $data['loggedInUserDept'] = nebula_sw_roles();
                        }
                        $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                    }else{
                        if ($orion_user_data['type'] != 'SW_DEV') {
                            $this->second_db->where('form_mst.inserted_by', $orion_user_data['id']);
                        }
                    }   
                }  
                
                // To get selected developer's assign tickets only (for sw_admin login to search dev's screen)
                if ($orion_user_data['type'] == 'SW_DEV') {
                    $this->second_db->group_start()
                        ->where('FIND_IN_SET(' . $orion_user_data['id'] . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                        ->or_where('form_mst.inserted_by', getCurrentLoggedInUserID()) // this condition to shows ticket created by loggnedIn developer
                    ->group_end();
                }
                
            }
        // END - SW_ADMIN can serach any users screen's data

        // START - To get current assignee developer data (for dev login)
            if (getCurrentLoggedInUserType() == 'SW_DEV') {
                if(!in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) && !in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                $this->second_db->group_start()
                            ->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                            ->or_where('form_mst.inserted_by', getCurrentLoggedInUserID()) // this condition to shows ticket created by loggnedIn developer
                        ->group_end();
                }
            }
        // END - To get current assignee developer data (for dev login)

        // START - Conditions for Flters : Department
            if (!empty($data['filter_global']['selectedDepartment'])) {
                $this->second_db->where_in('form_mst.orion_department', $data['filter_global']['selectedDepartment']);
            }
        // END - Conditions for Flters : Department

        // START - Conditions for Flters : Ticket Purpose
            if (!empty($data['filter_global']['selectedType'])) {
                //MY: Add Comment because make Purpose Value Dynamically
                if (array_key_exists($data['filter_global']['selectedType'], $purposeTypesArray)) {
                    $this->second_db->where('form_mst.purpose', $data['filter_global']['selectedType']);
                }
            }
        // END - Conditions for Flters : Ticket Purpose

        // START - Conditions for Flters : Date
            if (!empty($data['filter_global']['report_start_date'])) {
                $start_date = $data['filter_global']['report_start_date'] . ' 00:00:00';

                // if(empty($data['filter_global']['selectedStatus'])){
                //     $this->second_db->where('form_mst.created >=', $start_date);
                // }else{
                //     $this->second_db->group_start()
                //                         ->where('form_mst.created >=', $start_date)
                //                         ->or_where('form_mst.updated >=', $start_date)
                //                     ->group_end();
                // }
                
                if(!empty($data['filter_global']['selectedCreatedUpdated'])){
                    if($data['filter_global']['selectedCreatedUpdated'] == 'created_at'){
                        $this->second_db->where('form_mst.created >=', $start_date);
                    }elseif($data['filter_global']['selectedCreatedUpdated'] == 'updated_at'){
                        $this->second_db->group_start()
                                        ->where('form_mst.created >=', $start_date)
                                        ->or_where('form_mst.updated >=', $start_date)
                                    ->group_end();
                    }
                }else{
                    $this->second_db->where('form_mst.created >=', $start_date);
                }

                if (!empty($data['filter_global']['report_end_date'])) {
                    $end_date = $data['filter_global']['report_end_date'] . ' 23:59:59';
                    $this->second_db->where('form_mst.created <=', $end_date);
                }
            }
        // END - Conditions for Flters : Date

        // START - Conditions for Flters : Ticket Current Status
            if(!empty($data['filter_global']['selectedStatus'])){
                $this->second_db->where_in('form_mst.status_type', $data['filter_global']['selectedStatus']);
            }
        // END - Conditions for Flters : Ticket Current Status


        $result = $this->second_db->get()->result_array();

        $get_all_status_types = $this->getStatusTypes();

        $status_counts = [];

        foreach ($result as $row) {
            $status_counts[$row['status_type']] = $row['status_count'];
        }

        foreach ($get_all_status_types as $status_key => $status_name) {
            if (!isset($status_counts[$status_key])) {
                $status_counts[$status_key] = 0;
            }
        }

        $status_counts['all_type'] = array_sum($status_counts);
        // pre($status_counts);


        // 2025-01-23 08:53:16
        // $today_date = date('Y-m-d');
        $today_date = $this->ist_created_date;

        // pre($today_date);
        $get_all_today_status_count = [];
        $get_today_count = $this->second_db->select('status_type, COUNT(*) as status_count')
            ->from('nebula_form_mst form_mst')
            ->where("DATE(form_mst.created)", $today_date)
            ->group_by('status_type')
            ->get()->result_array();
        // pre($get_today_count);
        // pre($this->second_db->last_query());

        // print_last_query();
        foreach ($get_today_count as $row) {
            $get_all_today_status_count[$row['status_type']] = $row['status_count'];
        }

        return $status_counts;
        // return ["status_counts" => $status_counts, "get_all_today_status_count" => $get_all_today_status_count];
    }

    public function getTodaysStatusCounts()
    {

        // 2025-01-23 08:53:16
        $today_date = date('Y-m-d');

        /* START - Date conversion in IST/EST Timezone */
            // $timezone_result = $this->second_db->select('timezone_date_time.*')
            //                             ->from('nebula_mapper_timezone_date_time AS timezone_date_time')  // Table alias should be defined correctly
            //                             ->get()
            //                             ->row_array();  
            //                             // pre($timezone_result);

            // $createdDate = new DateTime($today_date); // Convert string to DateTime object

            // // Set Timezone (IST/EST)
            // $createdDate = $createdDate->setTimezone(new DateTimeZone($timezone_result['timezone']));
            // $createdDateFormatted = $createdDate->format('Y-m-d');
            // pre($createdDateFormatted);
        /* END - Date conversion in IST/EST Timezone */

        $get_all_today_status_count = [];

        $get_today_count = $this->second_db->select('status_type, COUNT(*) as status_count')
            ->from('nebula_form_mst form_mst')
            ->where("DATE(form_mst.created)", $today_date);
        // ->where('form_mst.status_type', 'open');
        // ->where("DATE(form_mst.updated)", $today_date);

        if (getCurrentLoggedInUserType() == 'SW_DEV') {
            // $this->second_db->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ', form_mst.trainer_id) > 0');
            $this->second_db->group_start()
                ->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                ->or_where('form_mst.inserted_by', getCurrentLoggedInUserID()) // this condition to shows ticket created by loggnedIn developer
            ->group_end();
        }

        if (!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {
            $this->second_db->where('form_mst.inserted_by', getCurrentLoggedInUserID());
        }

        $get_today_count = $this->second_db
            ->group_by('status_type')
            ->get()
            ->result_array();
        // pre($this->second_db->last_query());

        // pre($get_today_count);

        // print_last_query();
        foreach ($get_today_count as $row) {
            $get_all_today_status_count[$row['status_type']] = $row['status_count'];
        }
        // pre($get_all_today_status_count);



        // to remove assigned stage
        // if(!empty($get_all_today_status_count['assigned'])){
        //     unset($get_all_today_status_count['assigned']);
        // }

        $reported_tickets = array_sum($get_all_today_status_count);
        // pre($reported_tickets);

        // Initialize the components for the string
        $status_parts = [
            'Reported' => $reported_tickets
        ];

        // Define the status labels
        $status_labels = [
            'closed' => 'Fixed',
            'open' => 'Open',
            'assigned' => 'Assigned',
            'in_progress' => 'In Progress',
            'on_hold' => 'On Hold',
            'not_a_bug' => 'Not a Bug'
        ];

        foreach ($status_labels as $key => $label) {
            if (isset($get_all_today_status_count[$key])) {
                $status_parts[$label] = $get_all_today_status_count[$key];
            }
        }

        $today_string = "<strong>Today:</strong> ";
        foreach ($status_parts as $label => $count) {
            $today_string .= "$label: $count | ";
        }

        // Remove the trailing pipe and space
        $today_string = rtrim($today_string, " |");

        // pre($today_string);
        return $today_string;
    }

    public function priorityOptions(){
        $priorityOptions = $this->second_db->select('nebula_priority_table.priority')
                                ->from('nebula_priority_table')
                                ->get()
                              ->result_array();

        return $formattedPriorityOptions;
    }

    public function getLoggedInUserDepartment($loggedIn_user){

        $user_type = $this->getUserNameByID($loggedIn_user)['type'];
        // pre($user_type);

        /* START - Working for department group */
            // $orion_department_group = orion_department_group();
            // $user_dept = array();
            // $user_dept = $user_type;

            // foreach($orion_department_group as $key => $value){
            //     if(in_array($user_type, $value)){
            //         $user_dept = $value;
            //     }
            // }
            // // pre($user_dept);

            // return $user_dept;
        /* END - Working for department group */
       
        // if ($user_type == 'estimator' || $user_type == 'estimation_tl') {
        //     $result = ['estimator', 'estimation_tl'];
        // } else {
        //     $isTl = substr($user_type, -3) === '_tl';
        //     $result = $isTl ? [$user_type, substr($user_type, 0, -3)] : [$user_type . '_tl', $user_type];
        // }

        if(in_array(all_department_ticket_string(), checkUserPermission($loggedIn_user)["ticket_show_hide"])){

            $all_dept = $this->nebula_dashboard_model->get_departments();
            // pre($all_dept);

            // pre($all_dept);
            $store_all_depts = [''];
            foreach($all_dept as $k => $v){
                $store_all_depts[$k] = $v['type']; 
            }
            // pre($store_all_depts);
            // $store_all_depts = implode(',', $store_all_depts);

            $result = $store_all_depts;

        }else if(in_array(own_department_ticket_string(), checkUserPermission($loggedIn_user)["ticket_show_hide"])){
            // pre(234);

            if ($user_type == 'estimator' || $user_type == 'estimation_tl') {
                $result = ['estimator', 'estimation_tl'];
            } else {
                $isTl = substr($user_type, -3) === '_tl';
                $result = $isTl ? [$user_type, substr($user_type, 0, -3)] : [$user_type . '_tl', $user_type];
            }

        }
        // elseif(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) && !in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
        //     $result = $user_type;
        // }

        // pre($result);
        return $result;

    }

    public function getTableHeadingsRecent(){
        $table_headings = array(
            'action' => 'Action',
            'ticket_id' => 'Ticket ID',
            'type' => 'Type',
            'priority' => 'Priority',
            'title' => 'Title',
            'created_by' => 'Created By'
        );

        return $table_headings;
    }

    public function getTableHeadings()
    {

        $table_headings = array(
            'action' => 'Action',
            'ticket_id' => 'Ticket ID',
            'type' => 'Type',
            'priority' => 'Priority',
            // 'notes' => 'Notes',
            'title' => 'Title',
            'orion_depatment' => 'Orion Department',
            'orion_module' => 'Category',
            // 'software_tl' => 'Software TL',
            'assign_to' => 'Assign To',
            'status' => 'Status',
            'ticket_tags' => 'Tags',
            'created_at' => 'Created At (IST)',
            'updated_at' => 'Updated At (IST)',
            'created_by' => 'Created By',
        );

        // START - Previous Working 
        // if (in_array(getCurrentLoggedInUserType(), nebula_sw_roles()) || !empty($orion_user_type)) {
        //     $table_headings = array(
        //         'action' => 'Action',
        //         'ticket_id' => 'Ticket ID',
        //         'type' => 'Type',
        //         'priority' => 'Priority',
        //         // 'notes' => 'Notes',
        //         'title' => 'Title',
        //         'orion_depatment' => 'Orion Department',
        //         'orion_module' => 'Category',
        //         // 'software_tl' => 'Software TL',
        //         'assign_to' => 'Assign To',
        //         'status' => 'Status',
        //         'ticket_tags' => 'Tags',
        //         'created_at' => 'Created At (IST)',
        //         'updated_at' => 'Updated At (IST)',
        //         'created_by' => 'Created By',
        //     );
        // } else {
        //     $table_headings = array(
        //         'action' => 'Action',
        //         'ticket_id' => 'Ticket ID',
        //         'type' => 'Type',
        //         'priority' => 'Priority',
        //         // 'notes' => 'Notes',
        //         'title' => 'Title',
        //         'orion_depatment' => 'Orion Department',
        //         'orion_module' => 'Category',
        //         'assign_to' => 'Assign To',
        //         'status' => 'Status',
        //         'ticket_tags' => 'Tags',
        //         'created_at' => 'Created At (IST)',
        //         'updated_at' => 'Updated At (IST)',
        //         'created_by' => 'Creared By',
        //     );
        // }
        // END - Previous Working
        
        return $table_headings;
    }

    public function getDepartmentTLName($dept_tl)
    {

        $departments = json_decode(json_decode($dept_tl, true));

        $department_tl_names = [];
        if (!empty($departments)) {

            $department_tl_names = $this->db->select('tbl_users.name')
                ->from('tbl_users')
                ->where_in('tbl_users.id', $departments)
                ->where_in('tbl_users.status', 'active')
                ->not_like('tbl_users.name', 'Chirag Thaker')
                ->get()->result_array();

            if (!empty($department_tl_names)) {
                $department_tl_names = multidimensional_to_single_array($department_tl_names);
            }
        }

        $dept_tl = implode(', ', $department_tl_names);

        return $dept_tl;
    }

    public function getSoftwareTLName($swTL)
    {
        $softwareTLs = json_decode(json_decode($swTL, true));

        if (empty($softwareTLs) || !is_array($softwareTLs)) {
            $softwareTLs = array(0);  // Use an array with a valid value to prevent any issues
        }

        $software_tl_names = $this->db->select('tbl_users.name')
            ->from('tbl_users')
            ->where_in('tbl_users.id', $softwareTLs)
            ->get()->result_array();

        if (!empty($software_tl_names)) {
            $software_tl_names = multidimensional_to_single_array($software_tl_names);
        }
        $swTL = ucfirst(implode(', ', $software_tl_names));

        return $swTL;
    }

    public function getAssignToName($user_id)
    {

        $assignee_name = $this->db->select('user.name')
            ->from('tbl_users user')
            ->where('user.id', $user_id)
            ->get()->row_array()["name"];
        // pre($assignee_name);
        return $assignee_name;
    }

    public function getTrainerNames($trainer_ids)
    {

        $trainer_ids = explode(',', $trainer_ids);
        // pre($trainer_ids);

        $not_assign_to_users = ['hignesh.hirani', 'kalpesh.patel']; // to not show these users in assign_to dropdown i.e. ticket is not assign to these users

        if (!empty($trainer_ids)) {

            $curr_assignee = $this->db->select('tbl_users.first_name, tbl_users.id')
                ->from('tbl_users')
                ->where('tbl_users.status', 'active')
                ->where_in('tbl_users.id', $trainer_ids)
                ->where_in('tbl_users.type', ['SW_DEV', 'SW_ADMIN', 'SW_QA'])
                ->where_not_in('tbl_users.username', $not_assign_to_users)
                ->get()->result_array();
        }

        $this->db->select('tbl_users.first_name, tbl_users.id')
            ->from('tbl_users')
            ->where('tbl_users.status', 'active')
            ->where_in('tbl_users.type', ['SW_DEV', 'SW_ADMIN', 'SW_QA'])
            ->where_not_in('tbl_users.username', $not_assign_to_users);
        $assign_to_names = $this->db->get()->result_array();
        $curr_assignee_ids = array_column($curr_assignee, 'id');

        $filtered_assign_to_names = array_filter($assign_to_names, function ($trainer) use ($curr_assignee_ids) {
            return in_array($trainer['id'], $curr_assignee_ids);
        });

        $remaining_assign_to_names = array_filter($assign_to_names, function ($trainer) use ($curr_assignee_ids) {
            return !in_array($trainer['id'], $curr_assignee_ids);
        });

        $final_assign_to_names = array_merge(array_values($filtered_assign_to_names), array_values($remaining_assign_to_names));

        return ["all_users" => $final_assign_to_names, "current_assignee" => $filtered_assign_to_names];
    }

    public function getStatusCount($filter_type = false, $user_id = false)
    {
        // $status_count = $this->second_db->select('form_mst.status_type')
        //                          ->from('nebula_form_mst form_mst')
        //                          ->where('is_deleted', '0')
        //                          ->get()->result_array();

        // pre($filter_type);
        $status_count = $this->second_db->select('form_mst.status_type')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.is_deleted', '0');

        // if (getCurrentLoggedInUserType() != 'software') {
        // for all software users
        if (!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {
            $this->second_db->where('form_mst.inserted_by', $user_id);
        }

        if (getCurrentLoggedInUserType() == 'SW_DEV') {
            $this->second_db->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ',form_mst.trainer_id) > 0');
        }

        if (!empty($filter_type)) {
            $this->second_db->where('form_mst.purpose', $filter_type);
        }

        $status_count = $this->second_db->get()->result_array();

        $status_types = ['open', 'assigned', 'on_hold', 'in_progress', 'closed', 'not_a_bug'];
        $status_counts = array_fill_keys($status_types, 0);
        $total_count = 0;

        foreach ($status_count as $key => $value) {
            $status = $value['status_type'];

            // Check if the status is 'open' or 're_open', treat them as one category
            if ($status == 'open' || $status == 're_open') {
                $status_counts['open']++;  // Use 'open_reopen' to group 'open' and 're_open'
            } elseif (in_array($status, $status_types)) {
                $status_counts[$status]++;
            }

            $total_count++;
        }

        $status_counts['total_count'] = $total_count;
        return $status_counts;
    }

    public function getBugStages()
    {
        // $purpose_stages = [
        //     "bug" => array("Open", "In Progress", "Fixed", "Closed", "Re Open"),
        //     "training" => array("Pending", "On Going", "Completed")
        // ];
        //MY: Add Comment because make Purpose Value Dynamically
        $purpose_stages = [
            "bug_report" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "training_request" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "feature_request" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "task_assign" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "developer_status" => array("assigned", "on_hold", "in_progress", "closed", "not_a_bug")
        ];
        //MY: Add Comment because make Purpose Value Dynamically
        /* $purpose_stages = [
            "bug" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "training" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "feature_request" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "assign_task" => array("open", "assigned", "on_hold", "in_progress", "closed", "re_open", "not_a_bug"),
            "developer_status" => array("assigned", "on_hold", "in_progress", "closed", "not_a_bug")
        ]; */

        return $purpose_stages;
    }

    public function getDeveloperStatusTypes(){
        $status_types = array(
            'open' => "Open",
            'assigned' => "Assigned",
            'on_hold' => "On Hold",
            'in_progress' => "In Progress",
            'closed' => "Closed",
            'not_a_bug' => "Not A Bug",
        );
        return $status_types;
    }

    public function getStatusTypes()
    {
        $status_types = array(
            'open' => "Open",
            'assigned' => "Assigned",
            'on_hold' => "On Hold",
            'in_progress' => "In Progress",
            'closed' => "Closed",
            're_open' => "Re Open",
            'not_a_bug' => "Not A Bug",
        );
        return $status_types;
    }

    public function get_departments()
    {

        // $departments = $this->db->select('tbl_users.type')
        //                         ->from('tbl_users')
        //                         ->distinct('type')
        //                         ->not_like('type', '_tl')
        //                         ->not_like('type', 'SW_ADMIN')
        //                         ->not_like('type', 'SW_DEV')
        //                         ->not_like('type', 'SW_QA')
        //                         ->get()->result_array();
        // print_last_query();
        // pre($departments);

        $departments = $this->db->distinct()  // Specify that you want distinct results
            ->select('tbl_users.type')  // Select the 'type' column
            ->from('tbl_users')  // Specify the table
            //->not_like('type', '_tl')  // Exclude types containing '_tl'
            // ->not_like('type', 'SW_ADMIN')  // Exclude 'SW_ADMIN'
            // ->not_like('type', 'SW_DEV')  // Exclude 'SW_DEV'
            // ->not_like('type', 'SW_QA')  // Exclude 'SW_QA'
            ->get()  // Execute the query
            ->result_array();
        return $departments;
    }

    public function getSubModulesByDepartmentType($department_type)
    {
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $sub_module = $this->db->select('mst_role_rights.rr_modulecode')
            ->from('mst_role_rights')
            ->where('mst_role_rights.rr_rolecode', $department_type)
            ->get()->result_array();
        if (!empty($sub_module)) {
            $sub_module = multidimensional_to_single_array($sub_module);
            // $content['status'] = 200;
            // $content['message'] = 'success';
        }

        $sub_module = check_sub_modules($sub_module); // funtion to remove unnecessorry sub modules

        array_push($sub_module, 'NEBULA'); // if any bug in nebula then for this

        if (in_array($department_type, nebula_sw_roles())) {
            $sub_module = array("NEBULA"); // to set NEBULA only for these department
        }

        return $sub_module;
    }

    public function getDepartmentTL($department_type)
    {

        $departments = $this->get_departments();

        $department_tl = null;

        if ($department_type == 'estimator') {
            $department_tl = 'estimation_tl';
        } else {
            foreach ($departments as $department) {
                // Priority to '_tl' type, then exact match
                if ($department['type'] == $department_type . '_tl') {
                    $department_tl = $department['type'];
                    break;
                } elseif ($department['type'] == $department_type && !$department_tl) {
                    // Set department_tl to exact match if '_tl' is not found
                    $department_tl = $department['type'];
                }
            }
        }

        if (!empty($department_tl)) {
            $department_tl = $this->db->select('tbl_users.name, tbl_users.id')
                ->from('tbl_users')
                ->where('tbl_users.type', $department_tl)
                ->where('tbl_users.status', 'active')
                ->not_like('tbl_users.name', 'Chirag Thaker')
                ->get()->result_array();
        }

        return $department_tl;
    }

    public function getSoftwareTL($sub_module)
    {
        $software_tl = $this->db->select('tbl_users.name, nebula_modules_mapping.sw_tl_id')
            ->from('tbl_users')
            ->join('nebula_modules_mapping', 'nebula_modules_mapping.sw_tl_id = tbl_users.id', 'inner')  // Join condition
            ->where('nebula_modules_mapping.modulecode', $sub_module)  // Condition on second database table
            ->where('tbl_users.type', 'software')
            ->where('tbl_users.status', 'active')
            ->get()->result_array();

        return $software_tl;
    }

    public function getTrainer($sub_module)
    {
        $trainer_name = $this->db->select('tbl_users.name, nebula_modules_mapping.trainer_id')
            ->from('tbl_users')
            ->join('nebula_modules_mapping', 'nebula_modules_mapping.trainer_id = tbl_users.id', 'inner')  // Join condition
            ->where('nebula_modules_mapping.modulecode', $sub_module)
            ->where('tbl_users.status', 'active')
            ->where('tbl_users.type', 'SW_DEV')
            ->get()->row_array();

        return $trainer_name;
    }

    public function getTicketData($ticket_id)
    {
        $get_result = $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.ticket_id', $ticket_id)
            ->get()->row_array();
        return $get_result;
    }

    // assign_to function 
    public function updateTrainer($param)
    {

        // if(empty($param['assign_to_ids'][0])){
        //     unset($param['assign_to_ids'][0]);
        // }
        foreach ($param['assign_to_ids'] as $key => $value) {
            // $param['assign_to_ids'][$key] = $value['id'];
            if (empty($param['assign_to_ids'][$key])) {
                unset($param['assign_to_ids'][$key]);
            }
        }
        // pre($param['assign_to_ids']);
        $assign_to_ids = implode(',', $param['assign_to_ids']);
        // pre($assign_to_ids);
        $assign_to_ids_one = $param['assign_to_ids'];
        // pre($assign_to_ids_one);
        $getTicketData = $this->getTicketData($param['ticket_id']);
        $trainer_id_array = explode(',', $getTicketData['trainer_id']);
        $current_assign_to = array_diff($assign_to_ids_one, $trainer_id_array);
        $current_assign_to = implode(',', $current_assign_to);

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];



        // $get_result = $this->second_db->select('form_mst.*')
        //                         ->from('nebula_form_mst form_mst')
        //                         ->where('form_mst.ticket_id' , $param['ticket_id'])
        //                         ->get()->row_array();
        $get_result = $this->getTicketData($param['ticket_id']);

        $check_data = $this->second_db->select('nebula_form_log.*')
            ->from('nebula_form_log')
            ->where('nebula_form_log.ticket_id', $param['ticket_id'])
            ->where('nebula_form_log.is_latest', '1')
            ->get()->result_array();

        $update = $this->second_db->where('ticket_id', $param['ticket_id'])
            ->update('nebula_form_mst', ['trainer_id' => $assign_to_ids]);

        $update_nebula_log = array(
            "ticket_id" => $param['ticket_id'],
            "form_purpose" => $get_result['purpose'], // get purpose i.e. report_bug/training
            //"status_type" => 'assign_to', // report_bug OR training statuss
            //"old_data" => $get_result['trainer_id'], // save old trainer
            //"new_data" => $param['trainer_id'], // save new trainers
            "status_type" => 'assign_to', // report_bug OR training statuss OR feature_request
            "old_data" => $get_result['trainer_id'], // save old assignee's
            "new_data" => $assign_to_ids, // save new assignee's
            "is_latest" => '1',
            "created" => $this->ist_created_date,
            "created_by" => getCurrentLoggedInUserID()
        );

        foreach ($check_data as $key => $value) {
            if ($value['status_type'] == 'assign_to') {
                $update = $this->second_db->where('ticket_id', $param['ticket_id'])
                    ->where('nebula_form_log.status_type', $value['status_type'])
                    ->where('nebula_form_log.is_latest', '1')
                    ->update('nebula_form_log', ['is_latest' => '0']);
            }
        }

        // for insert new log for assign to
        $this->second_db->insert('nebula_form_log', $update_nebula_log);
        $last_insert_id = $this->second_db->insert_id();

        if(count($param['assign_to_ids']) == 1 && ($get_result['status_type'] == 'open' || $get_result['status_type'] == 're_open')){
            $update_status = array(
                "ticket_id" => $param['ticket_id'],
                "status_stage" => 'assigned',
            );

            $return_updated_status =  $this->updateStatus($update_status);
        }

        if ($update && $last_insert_id > 0) {
            $content['status'] = 200;
            $content['message'] = 'Assigned Successfully';

            if(!empty($current_assign_to)){

                $get_result_new = $this->getTicketData($param['ticket_id']);

                $assigned_by_user_id = getCurrentLoggedInUserID();
                $assigned_by_user_name = $this->getUserNameByID($assigned_by_user_id)['name'];
                $assigned_by_user_email = $this->getUserNameByID($assigned_by_user_id)['email'];
    
                $assigned_to_user_name = $this->getUserNameByID($current_assign_to)['name'];
                $assigned_to_user_email = $this->getUserNameByID($current_assign_to)['email'];
    
                $data = [
                    'ticket_id' => $get_result_new['ticket_id'],
                    'title' => $get_result_new['title'],
                    'ticket_discription' => $get_result_new['notes'],
                    'assigned_by_user_name' => $assigned_by_user_name,
                    'assigned_by_user_email' => $assigned_by_user_email,
                    'assigned_to_user_name' => $assigned_to_user_name,
                    'assigned_to_user_email' => $assigned_to_user_email,
                ];
                // uncomment when going to live
                $send_email_result = $this->send_nebula_email_for_assigned_ticket($data);
                // $send_email_result = $this->send_nebula_email_opend($data);

            }

            
        }
        return $content;
    }

    public function updateStatus($param)
    {
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $get_result = $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.ticket_id', $param['ticket_id'])
            ->get()->row_array();

        $check_data = $this->second_db->select('nebula_form_log.*')
            ->from('nebula_form_log')
            ->where('nebula_form_log.ticket_id', $param['ticket_id'])
            ->where('nebula_form_log.is_latest', '1')
            ->get()->result_array();

        // $update = $this->second_db->where('ticket_id', $param['ticket_id'])
        //            ->update('nebula_form_mst', ['status_type' => $param['status_stage'],
        //                                              'progress' => 100]);
        $get_result_new = $this->getTicketData($param['ticket_id']);
        $assigned_ticket_id = $get_result_new['ticket_id'];
        $assigned_user_id = getCurrentLoggedInUserID();
        $assigned_by_user_name = $this->getUserNameByID($assigned_user_id)['name'];


        $update_data = [
            'status_type' => $param['status_stage'],
            'updated' => $this->ist_created_date
        ];

        $data = [
            // 'status_type' => $param['status_stage'],
            'ticket_id' => $assigned_ticket_id,
            'user_name'  =>  $assigned_by_user_name
        ];
        // $send_email_result = $this->send_nebula_email_status_priorty($data);

        // If the status_stage is 'closed', add the 'updated' field
        if ($param['status_stage'] == 'closed') {
            $update_data['progress'] = 100;
        }
        $update = $this->second_db->where('ticket_id', $param['ticket_id'])
            ->update('nebula_form_mst', $update_data);

        // Update Log data
        $update_nebula_log = array(
            "ticket_id" => $param['ticket_id'],
            "form_purpose" => $get_result['purpose'], // get purpose i.e. report_bug/training
            "status_type" => 'status', // report_bug OR training status
            "old_data" => $get_result['status_type'], // save old trainer
            "new_data" => $param['status_stage'], // save new trainers
            "is_latest" => '1',
            "created" => $this->ist_created_date,
            "created_by" => getCurrentLoggedInUserID()
        );

        // to update log if status is closed then update progress to 100 
        if ($param['status_stage'] == 'closed') {
            $update_nebula_log_progress = array(
                "ticket_id" => $param['ticket_id'],
                "form_purpose" => $get_result['purpose'], // get purpose i.e. report_bug/training
                "status_type" => 'progress', // report_bug OR training status
                "old_data" => $get_result['progress'], // old data of progress
                "new_data" => $update_data['progress'], // new data of progress
                "is_latest" => '1',
                "created" => $this->ist_created_date,
                "created_by" => getCurrentLoggedInUserID()
            );
        }

        foreach ($check_data as $key => $value) {
            if ($value['status_type'] == 'status') {
                $this->second_db->where('ticket_id', $param['ticket_id'])
                    ->where('nebula_form_log.status_type', $value['status_type'])
                    ->where('nebula_form_log.is_latest', '1')
                    ->update('nebula_form_log', ['is_latest' => '0']);
            }
            if ($value['status_type'] == 'progress') {
                $this->second_db->where('ticket_id', $param['ticket_id'])
                    ->where('nebula_form_log.status_type', $value['status_type'])
                    ->where('nebula_form_log.is_latest', '1')
                    ->update('nebula_form_log', ['is_latest' => '0']);
            }
        }

        // for insert new log for assign to
        $this->second_db->insert('nebula_form_log', $update_nebula_log);
        $last_insert_id = $this->second_db->insert_id();

        $this->second_db->insert('nebula_form_log', $update_nebula_log_progress);

        if ($update && $last_insert_id > 0) {
            $content['status'] = 200;
            $content['message'] = 'Status Update Successfully';

            /* START - Send Email on status Update */

            //  Ticket id D
            //  ticket status D 
            //  username 
            //  show ticket id url D
            //  view ticket id url D
            
            // pre($update_data);
            // if (isset($update_data['status_type']) && !empty($update_data['status_type'])) {

            //     // $get_result_new = $this->getTicketData($param['ticket_id']);
            //     $ticket_id = $param['ticket_id'];
            //     $ticket_status = $update_data['status_type'];
            //     $status_changed_by_id = getCurrentLoggedInUserID();
            //     $status_changed_by_name = $this->getUserNameByID($status_changed_by_id)['name'];
                
            //     $data = [
            //         'ticket_id' => $ticket_id,
            //         'ticket_status' => $ticket_status,
            //         'status_changed_by_name' => $status_changed_by_name,
            //     ];
            //     $send_email_result = $this->send_nebula_email_for_status_change($data);
            // }


            /* END - Send Email on status Update */
        }
        return $content;
    }

    // public function updateListPageDropdown($param){

    //     $content = array();
    //     $content['status'] = 404;
    //     $content['message'] = $this->data['language']['err_something_went_wrong'];

    //     $get_result = $this->second_db->select('form_mst.*')
    //                                 ->from('nebula_form_mst form_mst')
    //                                 ->where('form_mst.ticket_id' , $param['ticket_id'])
    //                                 ->get()->row_array();

    //     $updated_data = [];

    //     if(isset($param['ticket_purpose']) && !empty($param['ticket_purpose'])){
    //         $updated_data['purpose'] = $param['ticket_purpose'];

    //         $log_status_type = 'purpose';
    //         $old_data = $get_result['purpose'];
    //         $new_data = $param['ticket_purpose'];

    //         $content_message = 'Ticket Type Updated Successfully';

    //     }elseif(isset($param['ticket_priority']) && !empty($param['ticket_priority'])){
    //         $updated_data['priority'] = $param['ticket_priority'];

    //         $log_status_type = 'priority';
    //         $old_data = $get_result['priority'];
    //         $new_data = $param['ticket_priority'];

    //         $content_message = 'Ticket Priority Updated Successfully';
    //     }

    //     $update = $this->second_db->where('ticket_id', $param['ticket_id'])
    //                                 ->update('nebula_form_mst', $updated_data);

    //     // Update Log data
    //     $update_nebula_log = array(
    //         "ticket_id" => $param['ticket_id'],
    //         "form_purpose" => $get_result['purpose'], // get purpose i.e. report_bug/training
    //         "status_type" => $log_status_type, // report_bug OR training status
    //         "old_data" => $old_data, // save old trainer
    //         "new_data" => $new_data, // save new trainers
    //         "is_latest" => '1',
    //         "created" => $this->ist_created_date, 
    //         "created_by" => getCurrentLoggedInUserID() 
    //     );

    //     // pre($content_message);
    //     $update_log_data = $this->updateLogData($param['ticket_id'], $update_nebula_log);

    //     if ($update && $update_log_data > 0) {
    //         // pre(345);
    //         $content['status'] = 200;
    //         $content['message'] = $content_message;
    //     } 
    //     return $content;
    // }

    public function updateLogData($ticket_id, $update_nebula_log)
    {

        // pre($update_nebula_log);

        $check_log_data = $this->second_db->select('nebula_form_log.*')
            ->from('nebula_form_log')
            ->where('nebula_form_log.ticket_id', $ticket_id)
            ->where('nebula_form_log.is_latest', '1')
            ->get()->result_array();
        // pre($check_log_data,0);

        foreach ($check_log_data as $key => $value) {
            if ($value['status_type'] == $update_nebula_log['status_type']) {
                $this->second_db->where('ticket_id', $ticket_id)
                    ->where('nebula_form_log.status_type', $value['status_type'])
                    ->where('nebula_form_log.is_latest', '1')
                    ->update('nebula_form_log', ['is_latest' => '0']);
            }
        }

        // pre($check_log_data);

        // for insert new log for assign to
        $this->second_db->insert('nebula_form_log', $update_nebula_log);
        $last_insert_id = $this->second_db->insert_id();

        return $last_insert_id;
    }

    public function updateListPageDropdown($param)
    {
        // pre($param);
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $get_result = $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.ticket_id', $param['ticket_id'])
            ->get()->row_array();

        $updated_data = [];

        if (isset($param['ticket_purpose']) && !empty($param['ticket_purpose'])) {
            $updated_data['purpose'] = $param['ticket_purpose'];

            $log_status_type = 'purpose';
            $old_data = $get_result['purpose'];
            $new_data = $param['ticket_purpose'];

            $content_message = 'Ticket Type Updated Successfully';
        } elseif (isset($param['ticket_priority']) && !empty($param['ticket_priority'])) {
            $updated_data['priority'] = $param['ticket_priority'];

            $log_status_type = 'priority';
            $old_data = $get_result['priority'];
            $new_data = $param['ticket_priority'];
            // pre($new_data);
            $content_message = 'Ticket Priority Updated Successfully';
        } elseif (isset($param['removed_tag']) && !empty($param['removed_tag'])) {
            $param['removed_tag'] = '#' . $param['removed_tag'];

            $ticket_tags_before_remove = explode(',', $get_result['ticket_tags']); // get all previous tags
            foreach ($ticket_tags_before_remove as $k => $v) {
                // 
                if ($v == $param['removed_tag']) {
                    unset($ticket_tags_before_remove[$k]); // unset for remove the tag
                }
            }
            $ticket_tags_after_remove = array_unique($ticket_tags_before_remove);
            $tagList = implode(',', $ticket_tags_after_remove); // add tags in ',' seperated

            $log_status_type = 'ticket_tags'; // column name from nebula_form_mst table
            $old_data = $get_result['ticket_tags'];
            $new_data = $tagList;

            $updated_data['ticket_tags'] = $tagList;

            $content_message = 'Tag Removed Successfully';
        }
        // pre($updated_data);

        $update = $this->second_db->where('ticket_id', $param['ticket_id'])
            ->update('nebula_form_mst', $updated_data);

        // Update Log data
        $update_nebula_log = array(
            "ticket_id" => $param['ticket_id'],
            "form_purpose" => $get_result['purpose'], // get purpose i.e. report_bug/training
            "status_type" => $log_status_type, // report_bug OR training status
            "old_data" => $old_data, // save old trainer
            "new_data" => $new_data, // save new trainers
            "is_latest" => '1',
            "created" => $this->ist_created_date,
            "created_by" => getCurrentLoggedInUserID()
        );
        // pre($update_nebula_log);

        // pre($content_message);
        $update_log_data = $this->updateLogData($param['ticket_id'], $update_nebula_log);

        if ($update && $update_log_data > 0) {
            // pre(345);
            $content['status'] = 200;
            $content['message'] = $content_message;

            if (isset($param['ticket_priority']) && !empty($param['ticket_priority'])) {

                $get_result_new = $this->getTicketData($param['ticket_id']);
                $assigned_ticket_id = $get_result_new['ticket_id'];
                $assigned_user_id = getCurrentLoggedInUserID();
                $assigned_by_user_name = $this->getUserNameByID($assigned_user_id)['name'];
                $assigned_by_user_email = $this->getUserNameByID($assigned_user_id)['email'];

                $data = [
                    'ticket_id' => $assigned_ticket_id,
                    'user_name'  =>  $assigned_by_user_name,
                    'ticket_priority' => $param['ticket_priority'],
                ];
                // send_nebula_email_status_priorty
                $send_email_result = $this->send_nebula_email_for_priorty_change($data);
            }
        }


        return $content;
    }

    public function updateViewPageComments($param){
        // pre($param);

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];
        $content['comments_log'] = $this->getCommentsLog($param['ticket_id']);

        $form_data = $this->getFormData($param['ticket_id']);

        $upload_data = [];

        // insert data in $upload_data
        if(!empty($param['ticket_id']) && isset($param['new_comments']) && !empty($param['new_comments'])){
            $update_data = [
                'ticket_id' => $param['ticket_id'],
                'comments' => $param['new_comments'],
            ];
        }

        // $comments_log = $this->getCommentsLog($param['ticket_id']);

        // check consition and insert data
        if(!empty($update_data)){

            $update_data['created'] = $this->ist_created_date;
            $update_data['inserted_by'] = getInsertedBy();
            
            $this->second_db->insert('nebula_ticket_comments', $update_data);
            $last_insert_id = $this->second_db->insert_id();
            
        }
        // pre($content);
        
        if($last_insert_id > 0){
            
            $content['status'] = 200;
            $content['message'] = 'Comment Added Successfully';
            $content['comments_log'] = $this->getCommentsLog($param['ticket_id']);

            $update_log_data['ticket_id'] = $param['ticket_id'];
            $update_log_data['new_comments'] = $param['new_comments'];
            
            // Add comment log & Show Activity Log
            $this->updateViewPageChanges($update_log_data);
    
            // send email on comment add
            if (!empty($update_data)) {

                $ticket_id = $update_data['ticket_id'];
                $get_result_data = $this->getTicketData($ticket_id);

                $comment_user_id = getCurrentLoggedInUserID();
                $comment_added_email = '';

                // if commented user is not same as ticket created user
                if($get_result_data['inserted_by'] != $comment_user_id){
                    $comment_added_email = $this->getUserNameByID($get_result_data['inserted_by'])['email'];
                }

                $commented_by_user_name = $this->getUserNameByID($comment_user_id)['name'];

                $data = [
                    'ticket_id' => $ticket_id,
                    'user_name'  =>  $commented_by_user_name,
                    'title' => $get_result_data['title'],
                    'new_comment' => $update_data['comments'],
                    'email_ids' => (!empty($comment_added_email)) ? $comment_added_email : '',
                ];
                $send_email_result = $this->send_nebula_email_for_new_comment($data);
            }
        }

        return $content;
    }

    public function getCommentFormattedDate($created) {
        $dateTime = new DateTime($created);
        $currentDate = new DateTime(); // Current date and time
    
        $formattedTime = $dateTime->format('h:i A');
    
        // Check if the date is today
        if ($dateTime->format('Y-m-d') == $currentDate->format('Y-m-d')) {
            $formattedDate_heading = 'Today';
        }
        // Check if the date is yesterday
        elseif ($dateTime->format('Y-m-d') == $currentDate->modify('-1 day')->format('Y-m-d')) {
            $formattedDate_heading = 'Yesterday';
        }
        // For other dates, return 'Month, Day'
        else {
            $formattedDate_heading = $dateTime->format('F, d');
        }
    
        return [
            "formattedTime" => $formattedTime,
            "formattedDate_heading" => $formattedDate_heading
        ];
    }
    

    public function getCommentsLog($ticket_id){
        // pre($ticket_id);

        $result = $this->second_db->select('nebula_ticket_comments.*')
                                    ->from('nebula_ticket_comments')
                                    ->where('ticket_id', $ticket_id)
                                    ->get()->result_array();
        
        $comment_log_result = [];
        $comment_log_result = $result;

        // $log_result[$key]['created'] = $this->nebula_mapper_model->getDateTimeFormat($value['created']); // to get current date time format from mapper(settings)
        
        foreach($comment_log_result as $key => $value){
            // $comment_log_result[$key]['created_date'] = $this->getCommentFormattedDate($value['created'])['formattedDate_heading'];
            // $comment_log_result[$key]['created_time'] = $this->getCommentFormattedDate($value['created'])['formattedTime'];

            $comment_log_result[$key]['comment_created'] = $this->nebula_mapper_model->getDateTimeFormat($value['created']);

            $comment_log_result[$key]['created_by_name'] = $this->getUserNameByID($value['inserted_by'])['name'];
            $comment_log_result[$key]['created_by_type'] = ucwords(str_replace('_', ' ', $this->getUserNameByID($value['inserted_by'])['type']));
        }
        // pre($comment_log_result);

        $comment_log_result = helper_array_column_multiple_key($comment_log_result, ["created_date"], true);
        // pre($comment_log_result);

        // <div class="line-date"><span>January 16</span></div>
        // <div class="comment-box">
        //     <div class="comment-profile">
        //     <img src="<?php echo base_url(ADM_THEME_COMMON_NEBULA_IMG) profile_pic.jpg" alt="">
        //     </div>
        //     <div class="comment-text-box">
        //     <div class="commente-name">vrushabh.gundecha <span>1:53 PM</span></div>
        //     <div class="commente-comment">if i want to create screen like this then how can i </div>
        //     </div>
        // </div>

        // New div with user type and times ago
        // <div class="comment-box">
        //     <div class="comment-profile">
        //         <img src="http://localhost/AO/themes/admin/common/img/nebula/profile_pic.jpg" alt="">
        //     </div>
        //     <div class="comment-text-box">
        //         <div class="commente-name">Harshal Patel
        //             <small><div class="badge bg-dark badge-pill ml-2 mr-1">SW_DEV</div> 5 hours ago </small>
        //             <span>created on 30-Jan-2025 03:36 PM</span>
        //         </div>
        //         <div class="commente-comment"><p>dsfhg zjdgh</p></div>
        //     </div>
        // </div>

        $comment_log_result_string = '';

        // Working
        // foreach($comment_log_result as $key => $value){

        //     $comment_log_result_string .= '<div class="line-date"><span>'.$key.'</span></div>';

        //     foreach($value as $k => $v){ 
        //         $comment_log_result_string .= '<div class="comment-box"><div class="comment-profile"><img src="'.base_url(ADM_THEME_COMMON_NEBULA_IMG).'profile_pic.jpg" alt=""></div><div class="comment-text-box"><div class="commente-name">'. $v['created_by_name'] .'<span>'. $v['created_time'] .'</span></div><div class="commente-comment">'. $v['comments'] .'</div></div></div>';
        //     }
        // }

        // pre($comment_log_result_string);
        foreach($comment_log_result as $key => $value){

            // $comment_log_result_string .= '<div style="max-height:88px;overflow:auto">';
            //$comment_log_result_string .= '<div class="line-date"><span>'.$key.'</span></div>';

            foreach($value as $k => $v){ 

                $timeago_nebula_activity = timeago_project_notes($v["created"]);

                $comment_log_result_string .= '<div class="comment-box"><div class="comment-profile"><img src="'.base_url(ADM_THEME_COMMON_NEBULA_IMG).'profile_pic.jpg" alt=""></div><div class="comment-text-box"><div class="commente-name">'. $v['created_by_name'] .'<small><div class="badge bg-dark badge-pill ml-2 mr-1">'. $v['created_by_type'] .'</div>'. $timeago_nebula_activity .'</small> <span style="margin-right:-35px;">Created on '. $v['comment_created'] .'</span></div><div class="commente-comment">'. $v['comments'] .' <hr></div></div></div>';
            }
            // $comment_log_result_string .= '</div>';
        }

        // pre($comment_log_result_string);
        return $comment_log_result_string;
    }

    public function get_nebula_form_data($edit_id){
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $get_result = $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.ticket_id', $edit_id)
            ->get()->row_array();

        $get_other_modules = $this->getSubModulesByDepartmentType($get_result['orion_department']);
        $get_result['orion_module'] = array_merge([$get_result['orion_module']], $get_other_modules);
        $get_result['orion_module'] = array_unique($get_result['orion_module']);

        if (!empty($get_result)) {
            $content['status'] = 200;
            $content['message'] = "success";
            $content['data'] = $get_result;
        }
        // pre($content);
        return $content;
    }

    public function submitNebula($postdata)
    {

        // pre($postdata);

        // $create_date = $this->ist_created_date;
        // $this->ist_created_date = getISTTime($create_date);
        // $getTicketClosingDate = $this->nebula_mapper_model->getTicketClosingDate($create_date);

        $content = array();
        $final_uploaded_file = array();
        $param = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $date_time = $postdata['date_time'] . ' ' . $postdata['time_hrs_mins'];
        $ticket_id = "";

        if (isset($postdata['edit_id']) && !empty($postdata['edit_id'])) {
            $ticket_id = $postdata['edit_id'];
        } else {
            $ticket_id = $this->getTicketId();
        }

        $check_ticket = $this->second_db->select('nebula_form_mst.ticket_id, nebula_form_mst.uploaded_file')
            ->from('nebula_form_mst')
            ->where('nebula_form_mst.ticket_id', $ticket_id)
            ->get()->row_array();
        // pre($check_ticket);

        if (isset($_FILES['uploaded_files']) && !empty($_FILES['uploaded_files']['name'][0])) {
            $uploaded_files = $_FILES['uploaded_files'];

            $upload_paths = nebula_file_upload_path($ticket_id);
            $path = $upload_paths['path'];
            $store_path = $upload_paths['store_path'];
            $param['nebula_file_upload'] = 1;

            $prev_count = 0;

            $path = rtrim($path, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

            if (is_dir($path)) {
                $files = scandir($path);  // Scan the folder for files
                // Remove '.' and '..' from the result
                $files = array_diff($files, array('.', '..'));
                $prev_count = count($files);
            }

            $final_uploaded_files = [];

            foreach ($uploaded_files['name'] as $key => $value) {
                $file_extension = pathinfo($uploaded_files['name'][$key], PATHINFO_EXTENSION);
                $param['new_file_name'] = $ticket_id . ($prev_count + $key) . '.' . $file_extension;

                $file_data = [
                    'name' => $uploaded_files['name'][$key],
                    'type' => $uploaded_files['type'][$key],
                    'tmp_name' => $uploaded_files['tmp_name'][$key],
                    'error' => $uploaded_files['error'][$key],
                    'size' => $uploaded_files['size'][$key]
                ];

                $upload_array = upload_file($file_data, $path, $param);

                if ($upload_array["status"] == "1") {
                    $final_uploaded_files[] = $upload_array["file_name"];
                    $content["file_upload_or_not"] = 1;
                }
            }

            if (!empty($final_uploaded_files)) {
                $postdata['file_paths'] = array_map(function ($file) use ($store_path) {
                    return $store_path . $file;
                }, $final_uploaded_files);

                if (!empty($check_ticket['uploaded_file'])) {
                    $postdata['file_paths'] = $check_ticket['uploaded_file'] . ',' . implode(',', $postdata['file_paths']);
                } else {
                    $postdata['file_paths'] = implode(',', $postdata['file_paths']);
                }
                $date_time = $this->ist_created_date;
            } else {
                $postdata['file_paths'] = NULL;
            }
        } else {
            $postdata['file_paths'] = NULL;
        }

        $formData = array(
            'ticket_id' => $ticket_id,
            'title' => (isset($postdata['title'])) ? $postdata['title'] : '-',
            'notes' => (isset($postdata['notes'])) ? $postdata['notes'] : '-',
            'orion_department' => (isset($postdata['orion_department'])) ? $postdata['orion_department'] : '-',
            'orion_module' => (isset($postdata['orion_sub_modules'])) ? $postdata['orion_sub_modules'] : '-',
            'dept_tl' => (!empty(json_encode($postdata['department_ids']))) ? json_encode($postdata['department_ids']) : '-',
            'sw_tl_id' => (isset($postdata['software_ids'])) ? json_encode($postdata['software_ids']) : '-',
            'trainer_id' => (isset($postdata['trainer_id'])) ? $postdata['trainer_id'] : NULL,
            'priority' => (isset($postdata['priority'])) ? $postdata['priority'] : '-',
            // 'status_type' => $postdata['status_type'],
            'status_type' => 'open',
            // 'training_date_time' => $date_time,
            'created' => $this->ist_created_date,
            'purpose' => (isset($postdata['purpose'])) ? $postdata['purpose'] : '-',
            'uploaded_file' => $postdata['file_paths'],
            'ticket_page_URL' => (!empty($postdata['currentPageURL'])) ? $postdata['currentPageURL'] : '',
            'user_ip_address' => $_SERVER['REMOTE_ADDR'],
            'inserted_by'=>getInsertedBy(),

        );

        // Start transaction
        $this->common->begin_transaction();

        if (!empty($check_ticket)) {
            $this->second_db->where('ticket_id', $ticket_id)
                ->update('nebula_form_mst', $formData);

            if ($this->second_db->affected_rows() > 0) {
                $update_success = true;
            } else {
                $update_success = false;
            }
        } else {

            $this->second_db->insert('nebula_form_mst', $formData);
            $last_insert_id = $this->second_db->insert_id();
        }

        $last_insert_id = '';
        if (empty($last_insert_id)) {
            $content['status'] = 200;
            $content['message'] = 'Nebula Form Submitted Successfully';

            /*---- START - Email Functionality ----*/

            // $user_detail = $this->second_db->get_where('tbl_users',['id'=>$this->user_id])->row_array();
            $email_ids = get_nebula_form_email_id()["nebula_form"]["email_id"];
            // $subject = isset($formData['notes']) ? $formData['notes'] : '';
           
            $created_by_for_email_data = $this->getUserNameByID($formData['inserted_by']);
            $data = [
                "title" => $formData['title'],
                "ticket_id" => $ticket_id,
                "ticket_discription" => $formData['notes'],
                "created_by_name" => $created_by_for_email_data['name'],
                "created_by_email" => $created_by_for_email_data['email'],
                "email_ids" => $created_by_for_email_data['email'],
            ];

            // uncomment when going to live
            $send_email_result = $this->send_nebula_email_for_ticket_opned($data);
            // $send_email_result = $this->send_nebula_email($data);

            /*---- END - Email Functionality ----*/
        } elseif ($update_success) {
            $content['status'] = 200;
            $content['message'] = 'Nebula Form Update Successfully';
        }

        // if($this->common->get_db_transaction_status())
        // {
        //     $this->common->complete_transaction();
        // }
        // else
        // {
        //     $this->common->rollback_transaction();
        // }

        return $content;
    }

    public function getTicketId()
    {

        // Get current date in yymmdd format (Year, Month, Day)
        $currentYearMonth = date('ymd');

        $getLastTicketId = $this->second_db->select('nebula_form_mst.ticket_id')
            ->from('nebula_form_mst')
            ->order_by('ticket_id', 'desc')
            ->limit(1)
            ->get()->row_array();

        if (empty($getLastTicketId['ticket_id'])) {
            $ticket_id = $currentYearMonth . '001';  // Start with '001' for the new month
        } else {
            $ticket_id = $getLastTicketId['ticket_id'];

            $lastTicketYearMonth = substr($ticket_id, 0, 6);  // Extract the year and month

            $lastTicketNumeric = substr($ticket_id, 6);  // Extract the numeric part

            // Check if the last ticket's year and month match the current year and month
            if ($lastTicketYearMonth !== $currentYearMonth) {
                $ticket_id = $currentYearMonth . '001'; // if month change then reset to '001'
            } else {
                $newTicketNumeric = (int)$lastTicketNumeric + 1;

                if ($newTicketNumeric > 999) {
                    $ticket_id = $currentYearMonth . '001';
                } else {
                    // Otherwise, pad the numeric part to 3 digits
                    $ticket_id = $currentYearMonth . str_pad($newTicketNumeric, 3, '0', STR_PAD_LEFT);
                }
            }
        }

        return $ticket_id;
    }
    public function url()
    {
        $show_ticket_url =  base_url() . 'Nebula_dashboard';
        return $show_ticket_url;
    }

    public function send_nebula_email_for_ticket_opned($data){
       
        $ticket_id = $data['ticket_id'];
        $title = $data['title'];
        $ticket_discription = $data['ticket_discription'];
        $username = $data['created_by']['name'];
        $created_by_name = $data['created_by_name'];
        $created_by_email = $data['created_by_email'];
        
        $show_ticket_url =  $this->url();
        $view_ticket_id_url = base_url() . 'Nebula_dashboard/open_ticket/' . $ticket_id;

        $email_data = generateEmailTemplate('nebula_ticket_opened', array("{{TICKET_ID}}", "{{TICKET_TITLE}}", "{{TICKET_URL}}", "{{DESCRIPTION_TEXT}}", "{{TICKET_ID_URL}}", "{{USER_NAME}}"), array($ticket_id, $title, $show_ticket_url, $ticket_discription, $view_ticket_id_url, $created_by_name));

        $email_data["fromemail"] = $data["email_ids"];

        $sub = $email_data["subject"] . ' for ' . $ticket_id; //  . ': ' . $data['form_subject']
        $bcc = $email_data["bcc_email_id"];
        $allcontactemail = 'bugs@aorbis.com';

        $emailans = sendEmailAddress($allcontactemail, $sub, $email_data['message'], $email_data["fromemail"], $email_data["fromname"], '', ["bcc_email_id" => $bcc]);

        return $emailans;
    }

    public function send_nebula_email($data)
    {
        $ticket_id = $data['ticket_id'];
        $title = $data['title'];
        $URL =  $this->url();
        $ticket_discription = $data['ticket_discription'];
        $username = $data['created_by']['name'];
        $ticketid_url = base_url() . 'Nebula_dashboard/open_ticket/' . $ticket_id;


        $email_data = generateEmailTemplate('requisition_form', array("{{TICKET_ID}}", "{{TICKET_TITLE}}", "{{TICKET_URL}}", "{{TICKET_CONTENT}}", "{{TICKET_ID_URL}}", "{{USER_NAME}}"), array($ticket_id, $title, $URL, $ticket_discription, $ticketid_url, $username));
        $sub = $email_data["subject"] . ' for ' . $data['ticket_id']; //  . ': ' . $data['form_subject']
        $bcc = $email_data["bcc_email_id"];
        $allcontactemail = $data["email_ids"];
        $emailans = sendEmailAddress($allcontactemail, $sub, $email_data['message'], $email_data["fromemail"], $email_data["fromname"], '', ["bcc_email_id" => $bcc]);
        return $emailans;
    }


    public function send_nebula_email_for_assigned_ticket($data){
        
        $ticket_id = $data['ticket_id'];
        $assigned_by_user_name = $data['assigned_by_user_name'];
        $assigned_by_user_email = $data['assigned_by_user_email'];
        $assigned_to_user_name = $data['assigned_to_user_name'];
        $assigned_to_user_email = $data['assigned_to_user_email'];
        $title = $data['title'];
        $ticket_discription = $data['ticket_discription'];
        $send_email_ids = [$assigned_by_user_email, $assigned_to_user_email];
        // pre($send_email_ids);

        $show_ticket_url =  $this->url();
        $view_ticket_id_url = base_url() . 'Nebula_dashboard/open_ticket/' . $ticket_id;

        $email_data = generateEmailTemplate('nebula_ticket_assigned', array("{{TASK_ID}}", "{{TASK_TITLE}}", "{{TICKET_URL}}", "{{DESCRIPTION_TEXT}}", "{{TICKET_ID_URL}}", "{{USER_NAME}}", "{{ASSIGNED_TO_USER_NAME}}"), array($ticket_id, $title, $show_ticket_url, $ticket_discription, $view_ticket_id_url, $assigned_by_user_name, $assigned_to_user_name));

        $sub = $email_data["subject"] . ' for ' . $ticket_id; //  . ': ' . $data['form_subject']
        $bcc = $email_data["bcc_email_id"];
        $allcontactemail = $send_email_ids;

        $emailans = sendEmailAddress($allcontactemail, $sub, $email_data['message'], $email_data["fromemail"], $email_data["fromname"], '', ["bcc_email_id" => $bcc]);

        return $emailans;
    }

    public function send_nebula_email_opend($data)
    {
        $assigned_by_user_name = $data['assigned_by_user_name'];
        $assigned_ticket_id = $data['assigned_ticket_id'];
        $assigned_content_description = $data['assigned_content_description'];
        $assigned_task_title = $data['assigned_title'];
        $assigned_to_user_name = $data['assigned_to_user_name'];
        $URL =  $this->url();
        $assigned_ticketid_url = base_url() . 'Nebula_dashboard/open_ticket/' . $assigned_ticket_id;
        $signature = "Thank You" . "<br>" . "Software Team";

        $email_data = generateEmailTemplate('nebula_form_opend', array("{{USER_NAME}}", "{{ASSIGNED_TO_USER_NAME}}", "{{TASK_ID}}", "{{TASK_TITLE}}", "{{CONTEXT_TITLE}}", "{{TICKET_URL}}", "{{TICKET_ID_URL}}", "{{SIGNATURE}}"), array($assigned_by_user_name, $assigned_to_user_name, $assigned_ticket_id, $assigned_task_title, $assigned_content_description, $URL, $assigned_ticketid_url, $signature));

        $sub = $email_data["subject"] . ' for ' . $data['ticket_id']; //  . ': ' . $data['form_subject']
        $bcc = $email_data["bcc_email_id"];
        $allcontactemail = $data["email_ids"];
        $emailans = sendEmailAddress($allcontactemail, $sub, $email_data['message'], $email_data["fromemail"], $email_data["fromname"], '', ["bcc_email_id" => $bcc]);
        return $emailans;
    }

    public function send_nebula_email_for_priorty_change($data)
    {
        $ticket_id = $data['ticket_id'];
        $user_name = $data['user_name'];
        $URL =  $this->url();
        $ticket_priority = ucfirst($data['ticket_priority']);
        $assigned_ticketid_url = base_url() . 'Nebula_dashboard/open_ticket/' . $ticket_id;

        $email_data = generateEmailTemplate('nebula_change_priority', array("{{TICKET_ID}}", "{{USER_NAME}}", "{{TICKET_URL}}", "{{TICKET_PRIORITY}}", "{{TICKET_ID_URL}}"), array($ticket_id, $user_name, $URL, $ticket_priority, $assigned_ticketid_url));

        $sub = $email_data["subject"] . ' for ' . $data['ticket_id']; //  . ': ' . $data['form_subject']
        $bcc = $email_data["bcc_email_id"];
        $allcontactemail = $data["email_ids"];
        $emailans = sendEmailAddress($allcontactemail, $sub, $email_data['message'], $email_data["fromemail"], $email_data["fromname"], '', ["bcc_email_id" => $bcc]);
        return $emailans;
    }

    public function send_nebula_email_for_new_comment($data){

        $ticket_id = $data['ticket_id'];
        $user_name = $data['user_name'];
        $show_ticket_url =  $this->url();
        $view_ticket_id_url = base_url() . 'Nebula_dashboard/open_ticket/' . $ticket_id;
        $ticket_title = $data['title'];
        $new_comment = $data['new_comment'];

        $send_email_ids = $data["email_ids"];

        $email_data = generateEmailTemplate('nebula_new_comment', array("{{TICKET_ID}}", "{{USER_NAME}}", "{{TICKET_URL}}", "{{TICKET_TITLE}}", "{{TICKET_ID_URL}}", "{{COMMENT_TEXT}}"), array($ticket_id, $user_name, $show_ticket_url, $ticket_title, $view_ticket_id_url, $new_comment));

        $sub = $email_data["subject"] . ' for ' . $ticket_id; //  . ': ' . $data['form_subject']
        $bcc = $email_data["bcc_email_id"];
        $allcontactemail = $send_email_ids;
        $emailans = sendEmailAddress($allcontactemail, $sub, $email_data['message'], $email_data["fromemail"], $email_data["fromname"], '', ["bcc_email_id" => $bcc]);

        return $emailans;

    }

    public function getFormData($ticket_id)
    {
        $result = $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.ticket_id', $ticket_id)
            ->get()->row_array();
        // pre($result);
        return $result;
    }

    public function getFormattedDate($created)
    {
        $dateTime = new DateTime($created);
        $getDate = $dateTime->format('m/d/Y');
        $formattedDate = $dateTime->format('Y/m/d h:i A');
        $formattedDate_heading = $dateTime->format('Y F, d');
        return ["formattedDate" => $formattedDate, "formattedDate_heading" => $formattedDate_heading, "getDate" => $getDate];
    }

    public function getDeveloperNames($dev_ids)
    {

        $dev_ids = explode(',', $dev_ids);

        $dev_name = $this->db->select('user.name')
            ->from('tbl_users user')
            ->where_in('user.id',  $dev_ids)
            ->get()->result_array();
        $dev_name = implode(',', array_column($dev_name, 'name'));

        return $dev_name;
    }

    public function getRequestType($request_type)
    {
        //MY: Add Comment because make Purpose Value Dynamically
        $purposeTypesArray = purposeTypes();// Get Purpose Type
        if (array_key_exists($request_type, $purposeTypesArray)) {
            $ticket_type = strtoupper(strtok($purposeTypesArray[$request_type], " "));
        }
        return $ticket_type;
    }

    public function getUserNameByID($created_id)
    {
        $created_by = $this->db->select('user.*')
            ->from('tbl_users user')
            ->where('user.id', $created_id)
            // ->where_in('user.status', 'active')
            ->get()->row_array();
        // pre($created_by);
        return $created_by;
    }

    public function getUploadedFiles($uploadedFiles){

        // Storing the entire logic into a variable
        $returnData = $thumbnailList = [];
        $filesHtml = '';
        $className = 'not-column-modal-data';
        // Get the uploaded files and split them into an array
        // $uploadedFiles = $ticket_details['data']['uploaded_file'];
        $uploadedFilesArray = explode(',', $uploadedFiles);

        if (empty($uploadedFiles)) {
            $filesHtml = '<p></p>';
        } else {
            // Check if there are multiple files
            if (count($uploadedFilesArray) > 1) {
                $filesHtml .= '<ul>';
                $i = 1;
                foreach ($uploadedFilesArray as $file) {
                    $file = trim($file);
                    $fileExtension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    $className = 'not-column-modal-data';

                    // Determine the file thumbnail based on the file extension
                    if (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
                        $thumbnail = $file;
                        $thumbnailList[] = $thumbnail;
                        $className = "column-modal-data";
                    } else if ($fileExtension === 'xlsx') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'xlsx.png';
                    } else if ($fileExtension === 'xls') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'xls.png';
                    } else if ($fileExtension === 'doc') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'doc.png';
                    } else if ($fileExtension === 'docx') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'docx.png';
                    } else if ($fileExtension === 'tsv') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'tsv.png';
                    } else if ($fileExtension === 'txt') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'txt.png';
                    } else if ($fileExtension === 'rtf') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'rtf.png';
                    } else if ($fileExtension === 'pdf') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'pdf.png';
                    } else if ($fileExtension === 'csv') {
                        $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'csv.png';
                    } else {
                        $thumbnail = 'path/to/default/file-icon.png';
                    }

                    // Add each file to the list with its thumbnail
                    $filesHtml .= '<li class="'.$className.'">';
                    if ($className == "column-modal-data") {
                        $filesHtml .= '<img src="' . $thumbnail . '" alt="Thumbnail" onclick="openModal();currentSlide('.$i.')" class="hover-shadow-light cursor" style="height: 94px;object-fit: scale-down; margin-right: 10px;">';
                    } else {
                        $filesHtml .= '<img src="' . $thumbnail . '" alt="Thumbnail" class="hover-shadow-light cursor" style="height: 94px;object-fit: scale-down; margin-right: 10px;">';
                    }
                    $filesHtml .= '<a href="' . $file . '" target="_blank">' . basename($file) . '</a>';
                    $filesHtml .= '</li>';
                    $i++;
                }
                $filesHtml .= '</ul>';
            } else {
                // For a single file, display with thumbnail
                $file = $uploadedFilesArray[0];
                $fileExtension = strtolower(pathinfo($file, PATHINFO_EXTENSION));

                // Determine the file thumbnail based on the file extension
                if (in_array($fileExtension, ['jpg', 'jpeg', 'png'])) {
                    $thumbnail = $file;
                    $thumbnailList[] = $thumbnail;
                    $className = "column-modal-data";
                } else if ($fileExtension === 'xlsx') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'xlsx.png';
                } else if ($fileExtension === 'xls') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'xls.png';
                } else if ($fileExtension === 'doc') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'doc.png';
                } else if ($fileExtension === 'docx') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'docx.png';
                } else if ($fileExtension === 'tsv') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'tsv.png';
                } else if ($fileExtension === 'txt') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'txt.png';
                } else if ($fileExtension === 'rtf') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'rtf.png';
                } else if ($fileExtension === 'pdf') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'pdf.png';
                } else if ($fileExtension === 'csv') {
                    $thumbnail = base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'csv.png';
                } else {
                    $thumbnail = 'path/to/default/file-icon.png';
                }

                $filesHtml .= '<li class="'.$className.'">';
                if ($className == "column-modal-data") {
                    $filesHtml .= '<img src="' . $thumbnail . '" alt="Thumbnail" onclick="openModal();currentSlide(1)" class="hover-shadow-light cursor" style="height: 94px;object-fit: scale-down; margin-right: 10px;">';
                } else {
                    $filesHtml .= '<img src="' . $thumbnail . '" alt="Thumbnail" class="hover-shadow-light cursor" style="height: 94px;object-fit: scale-down; margin-right: 10px;">';
                }
                $filesHtml .= '<a href="' . $file . '" target="_blank">' . basename($file) . '</a>';
                $filesHtml .= '</li>';
            }
        }

        return $returnData = [
            'thumbnail_path_list' => $thumbnailList,
            'files_html' => $filesHtml,
        ];

    }

    public function getTicketDetails($ticket_id){

        $result = $this->second_db->select('form_mst.*')
            ->from('nebula_form_mst form_mst')
            ->where('form_mst.ticket_id', $ticket_id)
            ->get()->row_array();
        // pre($result);

        $assign_to_name = $this->getTrainerNames($result['trainer_id']);
        $assign_to_name = $assign_to_name['current_assignee'];
        $names = array_map(function ($item) {
            return $item['first_name'];
        }, $assign_to_name);

        $assign_to_name = implode(', ', $names);
        // $assign_to_name = helper_array_column($assign_to_name,"id","name");

        $created_by = $this->getUserNameByID($result['inserted_by'])['name'];

        $ticket_type = "";

        $result['request_type'] = $this->getRequestType($result['purpose']);

        $get_mapper_format = $this->nebula_mapper_model->getDateTimeFormat($result['created']);

        $formattedDate = $get_mapper_format;

        // $formattedDate = $this->getFormattedDate($result['created'])['formattedDate'];
        $formattedDate_heading = $this->getFormattedDate($result['created'])['formattedDate_heading'];

        // to get re-open data
        $re_open_at = false;
        if ($result['status_type'] == 're_open') {
            $re_open_at = true;
        }
        // $get_log_details = $this->second_db->select('form_mst_log.created')
        //                             ->from('nebula_form_log form_mst_log')
        //                             ->where('form_mst_log.ticket_id', $ticket_id)
        //                             ->where('form_mst_log.new_data', 're_open')
        //                             ->where('form_mst_log.is_latest', 1)
        //                             ->get()->row_array();
        // pre($get_log_details);

        $get_log_details = $this->second_db->select('form_mst_log.*')
            ->from('nebula_form_log form_mst_log')
            ->where('form_mst_log.ticket_id', $ticket_id);

        if ($re_open_at) {
            $get_log_details->where('form_mst_log.new_data', 're_open')
                ->where('form_mst_log.is_latest', 1);
            $get_log_details_result = $get_log_details->get()->row_array()['created'];
        } else {
            $get_log_details_result = $get_log_details->get()->result_array();
        }

        if ($result['status_type'] == 're_open') {
            // $re_open_at = $get_log_details['created'];
            $re_open_at = $get_log_details_result;
            // pre($re_open_at);
            // pre($get_log_details_result);
            // $re_open_at = $this->nebula_mapper_model->getDateTimeFormat($get_log_details['created']);
            $re_open_at = $this->nebula_mapper_model->getDateTimeFormat($get_log_details_result);
            // pre($re_open_at);
        }

        $created_by_type = $this->getUserNameByID($result['inserted_by'])['type'];
        $created_by_type = ucwords(str_replace('_', ' ', $created_by_type));

        /*-------------------------- START - To get activity users list unique with count --------------------------*/

        $activity_users_list = array();
        foreach ($get_log_details_result as $k => $v) {
            $activity_users_list[$k] = $this->getUserNameByID($v['created_by'])['type'];
        }
        // pre($activity_users_list);

        // Push created user type in user types count
        // $get_created_user_type = $this->getUserNameByID($result['inserted_by'])['type'];
        // array_push($activity_users_list, $get_created_user_type);

        // pre($activity_users_list);

        $counted = array_count_values($activity_users_list);
        $final_activity_users_list = $counted;
        // Sort the counted values by the frequency
        // ksort($counted);

        // // Create the final result array with counts as the keys
        // $result_activity_users = [];
        // foreach ($counted as $value => $count) {
        //     $result_activity_users[$count] = $value;
        // }


        /*-------------------------- END - To get activity users list unique with count --------------------------*/

        $comments_log = $this->getCommentsLog($ticket_id);


        $data['ticket_created_user_type'] = $created_by_type;
        $data['ticket_created_user_date'] = $formattedDate;
        $data['ticket_created_user_name'] = $created_by;

        // To get activity log data
        $log_result = $this->getUpdatedActivityLog($ticket_id, $result['created'], $data);
        // pre($log_result);

        // pre($activity_ticket_created_log);

        // $get_mapper_format = $this->nebula_mapper_model->getDateTimeFormat($result['created']);

        $created_at = $this->nebula_mapper_model->getDateTimeFormat($result['created']);
        if(!empty($result['updated'])){
            $updated_at = $this->nebula_mapper_model->getDateTimeFormat($result['updated']);
        }else{
            $updated_at = '';
        }

        // "created_at" => (isset($result['created'])) ? $result['created'] : 'NA',
        // "updated_at" => $result['updated'],

        $uploadedFile = $this->getUploadedFiles($result['uploaded_file']);
        
        $result['data'] = array(

            "purpose" => $result['request_type'],
            "title" => ucfirst($result['title']),
            "status_type" => $result['status_type'],
            "assign_to" => ($result['trainer_id'] == NULL) ? 'Not Assigned Yet' : ucfirst($assign_to_name),
            "priority" => ucfirst($result['priority']),
            "orion_department" => $result['orion_department'],
            "orion_module" => $result['orion_module'],
            "created_by" => $created_by,
            "created_at" => $created_at,
            "updated_at" => $updated_at,
            "notes" => $result['notes'],
            "uploaded_file" => isset($uploadedFile['files_html']) ? $uploadedFile['files_html'] : null,
            "uploaded_file_path" => isset($uploadedFile['thumbnail_path_list']) ? $uploadedFile['thumbnail_path_list'] : null,
            "ticket_page_URL" =>  $result['ticket_page_URL'],
            "user_ip_address" => (!empty($result['user_ip_address'])) ? $result['user_ip_address'] : 'Not Available',
            "formatted_date" => $formattedDate,
            "formatted_date_heading" => $formattedDate_heading,
            "progress_bar" => $result['progress'],
            "ticket_tags" => $result['ticket_tags'],
            "activity_log" => $log_result,
            // "activity_ticket_created_log" => $activity_ticket_created_log,
            "all_status_types" => $this->getStatusTypes(), // for SW_ADMIN & SW_QA
            "developer_all_status_types" => $this->getDeveloperStatusTypes(), // for SW_DEV
            "re_open_at" => $re_open_at,
            "created_by_type" => $created_by_type,
            "activity_users_list" => $final_activity_users_list,
            //"ticket_purpose_types" => ticket_purpose_types(),
            "ticket_purpose_types" => purposeTypes(),//MY: Add Comment because make Purpose Value Dynamically
            // "expected_closing_at" => 
            "comments_log" => $comments_log,
        );
        // pre($result);
        return $result;
    }

    public function getUpdatedActivityLog($ticket_id, $created_date, $data)
    {

        $formattedDate_heading = $this->getFormattedDate($created_date)['formattedDate_heading'];

        // $log_result = $this->second_db->select('form_mst_log.*')
        //                     ->from('nebula_form_log form_mst_log')
        //                     ->where('form_mst_log.ticket_id', $ticket_id)
        //                     ->order_by('form_mst_log.created', 'DESC')
        //                     ->get()->result_array();
        // pre($log_result);
        // pre(var_dump($data['activity_user_isChecked']));

        $log_data_result = $this->second_db->select('form_mst_log.created_by')
            ->from('nebula_form_log form_mst_log')
            ->where('form_mst_log.ticket_id', $ticket_id)
            ->group_by('form_mst_log.created_by')
            ->get()->result_array();
        // pre($log_data_result);

        $log_data_result = array_column($log_data_result, 'created_by');
        // pre($log_data_result);

        if (isset($data['unchecked_users']) && !empty($data['unchecked_users'])) {
            $get_user_id = $this->db->select('user.id')
                ->from('tbl_users user')
                ->where_in('user.id', $log_data_result)
                ->where_in('user.type', $data['unchecked_users'])
                // ->where_in('user.status', 'active')
                ->get()->result_array();
            $get_user_id = array_column($get_user_id, 'id');
            // pre($get_user_id);
        }

        $this->second_db->select('form_mst_log.*')
            ->from('nebula_form_log form_mst_log')
            ->where('form_mst_log.ticket_id', $ticket_id);

        if (!empty($get_user_id)) {
            $this->second_db->where_not_in('form_mst_log.created_by', $get_user_id);
        }

        $log_result = $this->second_db->order_by('form_mst_log.created', 'DESC')->get()->result_array();
        // pre($log_result);

        foreach ($log_result as $key => $value) {

            if ($value['status_type'] == 'assign_to') {

                $old_developer_names = (!empty($value['old_data']) ?  $this->getDeveloperNames($value['old_data']) : '');

                $new_developer_names = (!empty($value['new_data']) ?  $this->getDeveloperNames($value['new_data']) : '');

                if (empty($value['old_data']) && empty($value['new_data'])) {
                    $log_result[$key]['updated_string'] = "Developer was removed";
                } elseif (empty($value['old_data']) && !empty($value['new_data'])) {
                    $log_result[$key]['updated_string'] = "Assigned Developer {$new_developer_names}";
                } elseif (!empty($value['old_data']) && empty($value['new_data'])) {
                    $log_result[$key]['updated_string'] = "Removed Developer : {$old_developer_names}";
                } elseif (!empty($value['old_data']) && !empty($value['new_data'])) {
                    $log_result[$key]['updated_string'] = "Developer Changed from {$old_developer_names} to {$new_developer_names}";
                }
            } elseif ($value['status_type'] == 'status') {
                // pre($value['new_data'],0);
                if (!empty($value['old_data']) && !empty($value['new_data'])) {
                    $old_status = ucfirst(str_replace('_', ' ', $value['old_data']));
                    $new_status = ucfirst(str_replace('_', ' ', $value['new_data']));
                    $log_result[$key]['updated_string'] = "Changed Status from {$old_status} to {$new_status}";
                }
            } elseif ($value['status_type'] == 'title') {
                if (!empty($value['old_data']) && !empty($value['new_data'])) {

                    $log_result[$key]['updated_string'] = "Changed Title from {$value['old_data']} to {$value['new_data']}";
                }
            } elseif ($value['status_type'] == 'progress') {
                if (isset($value['old_data']) && isset($value['new_data'])) {

                    $old_data = ($value['old_data'] == 0) ? $value['old_data'] : $value['old_data'] . '%';
                    $log_result[$key]['updated_string'] = "Progess updated from {$old_data} to {$value['new_data']}%";
                }
            } elseif ($value['status_type'] == 'ticket_tags') {

                if (isset($value['old_data']) && isset($value['new_data'])) {

                    $old_tags = explode(',', $value['old_data']);
                    $new_tags = explode(',', $value['new_data']);

                    if (count($old_tags) < count($new_tags)) {

                        // get new added tag
                        $added_tags = array_diff($new_tags, $old_tags);
                        $new_added_tag = reset($added_tags);

                        $log_result[$key]['updated_string'] = "New Tag Added : {$new_added_tag}";
                    } elseif (count($old_tags) > count($new_tags)) {

                        // get removed tag 
                        $added_tags = array_diff($old_tags, $new_tags);
                        $new_added_tag = reset($added_tags);

                        $log_result[$key]['updated_string'] = "Removed Tag : {$new_added_tag}";
                    }
                }
                // elseif(isset($value['old_data']) && !isset($value['new_data'])){
                //     $log_result[$key]['updated_string'] = "";
                // }
                if (empty($value['old_data']) && !empty($value['new_data'])) {

                    $log_result[$key]['updated_string'] = "New Tag Added : {$value['new_data']}";
                }
                if(!empty($value['old_data']) && empty($value['new_data'])){
                    $log_result[$key]['updated_string'] = "Removed Tag : {$value['old_data']}";
                }

            } elseif ($value['status_type'] == 'priority') {
                if (isset($value['old_data']) && isset($value['new_data'])) {

                    $old_data = ucfirst($value['old_data']);
                    $new_data = ucfirst($value['new_data']);

                    $log_result[$key]['updated_string'] = "Changed Priority from {$old_data} to {$new_data}";
                }
            } elseif ($value['status_type'] == 'purpose') {
                if (isset($value['old_data']) && isset($value['new_data'])) {

                    $old_data = $value['old_data'];
                    $new_data = $value['new_data'];

                    //MY: Add Comment because make Purpose Value Dynamically
                    //$getPurposeTypes = ticket_purpose_types();
                    $getPurposeTypes = purposeTypes();
                    foreach ($getPurposeTypes as $k => $v) {
                        if ($k == $old_data) {
                            //MY: Add Comment because make Purpose Value Dynamically
                            $old_data = strtok($v, " ");
                            //$old_data = $v;
                        }
                        if ($k == $new_data) {
                            //MY: Add Comment because make Purpose Value Dynamically
                            $new_data = strtok($v, " ");
                            //$new_data = $v;
                        }
                    }

                    $log_result[$key]['updated_string'] = "Changed Ticket Type from {$old_data} to {$new_data}";
                }
            } elseif ($value['status_type'] == 'notes') {
                if (isset($value['old_data']) && isset($value['new_data'])) {

                    $old_data = "{$value['old_data']}";
                    $new_data = "{$value['new_data']}";

                    $log_result[$key]['updated_string'] = "Changed Description from {$old_data} To {$new_data}";
                }
            }elseif($value['status_type'] == 'comments'){
                if(isset($value['new_data'])){
                    $new_data = "{$value['new_data']}";
                    $log_result[$key]['updated_string'] = "New Comment Added";
                }
            }
            
            $log_result[$key]['created_date'] = $this->getFormattedDate($value['created'])['formattedDate_heading'];
            // $log_result[$key]['created'] = $this->getFormattedDate($value['created'])['formattedDate'];
            $log_result[$key]['created'] = $this->nebula_mapper_model->getDateTimeFormat($value['created']); // to get current date time format from mapper(settings)
            $log_result[$key]['times_ago_created'] = $value['created']; // to get time ago

            // $log_result[$key]['created_by'] = $this->getAssignToName($value['created_by']);

            $log_result[$key]['created_by_name'] = $this->getUserNameByID($value['created_by'])['name'];
            $log_result[$key]['created_by_type'] = ucwords(str_replace('_', ' ', $this->getUserNameByID($value['created_by'])['type']));
        }

        $log_result = helper_array_column_multiple_key($log_result, ["created_date"], true);

        $log_result_string = '';

        foreach ($log_result as $key => $value) {

            // pre($ticket_details['data']['formatted_date_heading']);
            // if($formattedDate_heading != $key){  
            //     $log_result_string .= '<h3 class="viewpage-tabs-activity-title">'. $key .'</h3><div class="viewpage-activity-comment-tab">';
            // } 

            foreach ($value as $k => $v) {

                $timeago_nebula_activity = timeago_project_notes($v["times_ago_created"]);

                $log_result_string .= '<div class="viewpage-activity-profile"><div class="viewpage-activity-profile-img"><img src="' . base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'profile_pic.jpg" alt=""></div><div class="viewpage-activity-profile-title user-text-color">' . $v["created_by_name"] . '<small><span class="badge bg-dark badge-pill ml-2 mr-1">' . $v['created_by_type'] . '</span></small> <span>' . $timeago_nebula_activity . '</span> <span class="ml-auto">Updated on ' . $v["created"] . ' </span></div></div><ul><li>' . $v["updated_string"] . '</li></ul>';
            }
            // $log_result_string .=  '</div>';

        }

        //  Div for created user
        // $log_result_string .= '<div class="viewpage-activity-profile"><div class="viewpage-activity-profile-img"><img src="' . base_url(ADM_THEME_COMMON_NEBULA_IMG) . 'profile_pic.jpg" alt=""></div><div class="viewpage-activity-profile-title user-text-color">' . $data['ticket_created_user_name'] . '<small><span class="badge bg-dark badge-pill ml-2 mr-1">' . $data['ticket_created_user_type'] . '</span></small><span>' . timeago_project_notes($data['ticket_created_user_date']) . '</span><span class="ml-auto">created on ' . $data['ticket_created_user_date'] . '</span></div></div>';


        // pre($log_result_string);
        return json_encode($log_result_string);
    }

    public function updateViewPageChanges($param)
    {
        // pre($param);

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $form_data = $this->getFormData($param['ticket_id']);

        $status_type = '';
        $old_data = '';
        $new_data = '';

        $log_data =  $this->second_db->select('nebula_form_log.*')
            ->from('nebula_form_log')
            ->where('nebula_form_log.ticket_id', $param['ticket_id'])
            ->where('nebula_form_log.is_latest', '1')
            ->get()->result_array();
        // pre($log_data);

        $update_data = [];

        // $update = $this->second_db->where('ticket_id', $param['ticket_id']);
        if (isset($param['title'])) {
            // $this->second_db->update('nebula_form_mst', ['title' => $param['title']]);

            // To set data in $update_data for update
            $update_data['title'] = $param['title'];

            $status_type = 'title';
            $old_data = $form_data['title'];
            $new_data = $param['title'];
        }
        if (isset($param['progress_bar'])) {
            // $this->second_db->update('nebula_form_mst', ['progress' => $param['progress_bar']]);

            // To set data in $update_data for update
            $update_data['progress'] = $param['progress_bar'];

            $status_type = 'progress';
            $old_data = $form_data['progress'];
            $new_data = $param['progress_bar'];
        }
        if (isset($param['tagList'])) {
            $tagList = implode(',', $param['tagList']);

            // To set data in $update_data for update
            $update_data['ticket_tags'] = $tagList;

            $status_type = 'ticket_tags';
            $old_data = $form_data['ticket_tags'];
            $new_data = $tagList;
        }
        if (isset($param['removed_tag'])) {
            $ticket_tags_before_remove = explode(',', $form_data['ticket_tags']);
           
            foreach ($ticket_tags_before_remove as $k => $v) {
                if ($v == $param['removed_tag']) {
                    unset($ticket_tags_before_remove[$k]);
                }
            }

            $ticket_tags_after_remove = array_unique($ticket_tags_before_remove);
            $tagList = implode(',', $ticket_tags_after_remove);

            // To set data in $update_data for update
            $update_data['ticket_tags'] = $tagList;

            $status_type = 'ticket_tags';
            $old_data = $form_data['ticket_tags'];

            if(empty($tagList)){
                $new_data = '1';
            }else{
                $new_data = $tagList;
            }

        }
        if (isset($param['status_type'])) {
            // $this->second_db->update('nebula_form_mst', ['status_type' => $param['status_type'],
            //                                                     'updated' => $this->ist_created_date]);

            // To set data in $update_data for update
            $update_data['status_type'] = $param['status_type'];
            $update_data['updated'] = $this->ist_created_date;

            $status_type = 'status';
            $old_data = $form_data['status_type'];
            $new_data = $param['status_type'];
        }
        if (isset($param['selected_priority'])) {
            // $this->second_db->update('nebula_form_mst', ['priority' => $param['selected_priority']]);

            // To set data in $update_data for update
            $update_data['priority'] = $param['selected_priority'];

            $status_type = 'priority';
            $old_data = $form_data['priority'];
            $new_data = $param['selected_priority'];
        }
        // if(isset($param['updatedDescription'])){
        //     // $this->second_db->update('nebula_form_mst', ['notes' => $param['updatedDescription']]);

        //     // To set data in $update_data for update
        //     $update_data['notes'] = $param['updatedDescription'];

        //     $status_type = 'notes';
        //     $old_data = $form_data['notes'];
        //     $new_data = $param['updatedDescription'];

        // }

        if (isset($param['updatedDescription'])) {
            if ($form_data['notes'] != $param['updatedDescription']) {
                // $this->second_db->update('nebula_form_mst', ['notes' => $param['updatedDescription']]);

                $update_data['notes'] = $param['updatedDescription'];

                $status_type = 'notes';
                $old_data = $form_data['notes'];
                $new_data = $param['updatedDescription'];
            } else {
                $content['status'] = 404;
                $content['message'] = 'Please make changes before update';
                return $content;
            }
        }
        if(isset($param['new_comments'])){
          
            $status_type = 'comments';
            $old_data = '';
            $new_data = 'Comment Added';
        }

        if (!empty($update_data)) {
            // To set data in $update_data for update
            $update = $this->second_db->where('ticket_id', $param['ticket_id'])
                ->update('nebula_form_mst', $update_data);
        }

        // Insert Log
        $update_nebula_log = array(
            "ticket_id" => $param['ticket_id'],
            "form_purpose" => $form_data['purpose'], // get purpose i.e. report_bug/training
            "status_type" => $status_type, // in which column changes
            "old_data" => $old_data, // save old value of $status_type
            "new_data" => $new_data, // save updated value of $status_type
            "is_latest" => '1',
            "created" => $this->ist_created_date,
            "created_by" => getCurrentLoggedInUserID()
        );
        // pre($update_nebula_log);

        // pre($log_data);
        if (!empty($log_data)) {

            foreach ($log_data as $key => $value) {

                if ($value['status_type'] == 'title' || $value['status_type'] == 'progress' || $value['status_type'] == 'ticket_tags' || $value['status_type'] == 'status_type' || $value['status_type'] == 'priority' || $value['status_type'] == 'notes') {
                    $this->second_db->where('ticket_id', $param['ticket_id'])
                        ->where('nebula_form_log.status_type', $value['status_type'])
                        ->where('nebula_form_log.is_latest', '1')
                        ->update('nebula_form_log', ['is_latest' => '0']);
                }

                // elseif ($value['status_type'] == 'progress') {
                //     $this->second_db->where('nebula_form_log.status_type', $value['status_type'])
                //                     ->where('nebula_form_log.is_latest', '1')
                //                     ->update('nebula_form_log', ['is_latest' => '0']);
                // }elseif ($value['status_type'] == 'ticket_tags') {
                //     $this->second_db->where('nebula_form_log.status_type', $value['status_type'])
                //                     ->where('nebula_form_log.is_latest', '1')
                //                     ->update('nebula_form_log', ['is_latest' => '0']);
                // }
            }
        }


        
        if (!empty($status_type) && !empty($new_data)) {

            // if tag count is 1 and remove the 
            if($new_data == '1'){
                $update_nebula_log['new_data'] = '';
            }

            $this->second_db->insert('nebula_form_log', $update_nebula_log);
            $last_insert_id = $this->second_db->insert_id();
        }

        $data['checked_users'] = '';
        $data['unchecked_users'] = '';

        if ((isset($param['checked_users']) && !empty($param['checked_users'])) || (isset($param['unchecked_users']) && !empty($param['unchecked_users']))) {
            $data['checked_users'] = $param['checked_users'];
            $data['unchecked_users'] = $param['unchecked_users'];
        }

        $formattedDate = $this->getFormattedDate($form_data['created'])['formattedDate'];
        $created_by_type = $this->getUserNameByID($form_data['inserted_by'])['type'];
        $created_by_type = ucwords(str_replace('_', ' ', $created_by_type));

        $created_by = $this->getUserNameByID($form_data['inserted_by'])['name'];

        $data['ticket_created_user_type'] = $created_by_type;
        $data['ticket_created_user_date'] = $formattedDate;
        $data['ticket_created_user_name'] = $created_by;

        $log_result_string = $this->getUpdatedActivityLog($param['ticket_id'], $form_data['created'], $data);

        if (!empty($log_result_string) || ($update && $last_insert_id > 0)) {
            $content['status'] = 200;
            $content['message'] = 'Updated Successfully';
            $content['activity_log'] = $log_result_string;

            if (isset($param['selected_priority']) && !empty($param['selected_priority'])) {
                $get_result_new = $this->getTicketData($param['ticket_id']);
                $assigned_ticket_id = $get_result_new['ticket_id'];
                $assigned_user_id = getCurrentLoggedInUserID();
                $assigned_by_user_name = $this->getUserNameByID($assigned_user_id)['name'];

                $data = [
                    'ticket_id' => $assigned_ticket_id,
                    'user_name'  =>  $assigned_by_user_name,
                    'ticket_priority' => $param['selected_priority'],
                ];
                $send_email_result = $this->send_nebula_email_for_priorty_change($data);
            }
        }
        return $content;
    }

    public function get_orion_users()
    {
        $orion_users = $this->db->select('tbl_users.username, tbl_users.type')
            ->from('tbl_users')
            ->where_in('tbl_users.status', 'active')
            ->not_like('tbl_users.name', 'Chirag Thaker')
            ->get()->result_array();
        
        foreach ($orion_users as $user) {
            $type = $user['type'];
            if (!isset($grouped_users[$type])) {
                $grouped_users[$type] = [];
            }
            $grouped_users[$type][] = $user['username']; // Add the username to the respective type group

        }
        $grouped_users['admin'] = array_merge($grouped_users['proposal'], $grouped_users['sub_admin']);
        unset($grouped_users['sub_admin']);
        $grouped_users['proposal'] = array_merge($grouped_users['proposal'], $grouped_users['proposal_tl']);
        unset($grouped_users['proposal_tl']);
        $grouped_users['proposal'] = array_merge($grouped_users['proposal'], $grouped_users['proposal_qc']);
        unset($grouped_users['proposal_qc']);

        $grouped_users['estimator'] = array_merge($grouped_users['estimator'], $grouped_users['estimation_tl']);
        unset($grouped_users['estimation_tl']);
        $grouped_users['pct'] = array_merge($grouped_users['pct'], $grouped_users['pct_tl']);
        unset($grouped_users['pct_tl']);
        $grouped_users['buyer'] = array_merge($grouped_users['buyer'], $grouped_users['buyer_tl']);
        unset($grouped_users['buyer_tl']);
        $grouped_users['marketing'] = array_merge($grouped_users['marketing'], $grouped_users['marketing_manager']);
        unset($grouped_users['marketing_manager']);

        // $grouped_users['Software'] = 'vrushabh';
        if ($grouped_users['SW_ADMIN'] || $grouped_users['SW_QA'] || $grouped_users['SW_DEV']) {
            $grouped_users['Software'] = [];
            $grouped_users['Software'] = array_merge($grouped_users['Software'], $grouped_users['SW_ADMIN']);
            unset($grouped_users['SW_ADMIN']);
            $grouped_users['Software'] = array_merge($grouped_users['Software'], $grouped_users['SW_DEV']);
            unset($grouped_users['SW_DEV']);
            $grouped_users['Software'] = array_merge($grouped_users['Software'], $grouped_users['SW_QA']);
            unset($grouped_users['SW_QA']);
        }
        return $grouped_users;
    }

    public function get_tl_team_users($current_user_type)
    {

        // pre($current_user_type);
        // $current_user_type = 'estimation_tl';

        // $current_user_type = 'estimation_tl';

        $get_role_without_tl = substr($current_user_type, 0, -3);
        // pre($get_role_without_tl);

        if($get_role_without_tl == 'estimation'){
            $get_role_without_tl = 'estimator';
        }



        $users = $this->db->select('tbl_users.username, tbl_users.type')
            ->from('tbl_users')
            ->where_in('tbl_users.status', 'active')
            ->where_in('tbl_users.type', $get_role_without_tl)
            ->not_like('tbl_users.name', 'Chirag Thaker')
            ->get()->result_array();
            pre($users);


            // $users = $this->db->select('tbl_users.username, tbl_users.type')
            //             ->from('tbl_users')
            //             ->where_in('tbl_users.status', 'active')
            //             // ->where_in('tbl_users.type', $get_role_without_tl)
            //             ->not_like('tbl_users.name', 'Chirag Thaker')
            //             ->like('tbl_users.type', '_tl', 'after')  // this checks if 'type' ends with '_tl'
            //             ->get()->result_array();
            // pre($users);






            // $departments = $this->get_departments();

            // $department_tl = null;

            // if ($department_type == 'estimator') {
            //     $department_tl = 'estimation_tl';
            // } else {
            //     foreach ($departments as $department) {
            //         // Priority to '_tl' type, then exact match
            //         if ($department['type'] == $department_type . '_tl') {
            //             $department_tl = $department['type'];
            //             break;
            //         } elseif ($department['type'] == $department_type && !$department_tl) {
            //             // Set department_tl to exact match if '_tl' is not found
            //             $department_tl = $department['type'];
            //         }
            //     }
            // }

            // if (!empty($department_tl)) {
            //     $department_tl = $this->db->select('tbl_users.name, tbl_users.id')
            //         ->from('tbl_users')
            //         ->where('tbl_users.type', $department_tl)
            //         ->where('tbl_users.status', 'active')
            //         ->not_like('tbl_users.name', 'Chirag Thaker')
            //         ->get()->result_array();
            // }

            // return $department_tl;
    }

    public function getUserListNebulaRight(){

        $user_id = $this->second_db->select('nebula_user_rights.user_id')
        ->from('nebula_user_rights')
        ->get()->result_array();
        $option_html="";
        if(!empty($user_id)){
            $user_id = multidimensional_to_single_array($user_id);
            $user_name = $this->db->select('id,username')
            ->from('tbl_users')
            ->where_in("id",$user_id)
            ->get()->result_array();
            foreach($user_name as $key => $value){
                
                $option_html .= "<option value='".$value["id"]."'>".$value["username"]."</option>";
            }
        }
        return $option_html;
    }


    function getOrionUsersList($filters = array()) {

        $likeArr = array();

        $result = array();

        extract($filters);


        if (!empty($search)) {
            $likeArr['u.name'] = $search;
            $likeArr['u.type'] = $search;
            $likeArr['u.email'] = $search;
            $likeArr['u.username'] = $search;
        }


        $this->db->select('u.id,u.type, u.name, u.email ,u.username,u.mobile, u.created, u.status')
        ->from('tbl_users u')
        ->where('u.status', 'active');
        // ->order_by('u.id', 'desc');

        if (!empty($likeArr)) {

            $this->db->group_start()

                    ->like('name', $search)

                    ->or_like('email', $search)

                    ->or_like('username', $search)

                    ->or_like($likeArr)

                    ->group_end();

        }

        $this->db->order_by("u.status")->group_by('u.id');

        $get_all_users = $this->db->limit($limit, $offset)->get()->result_array();
        // pre($get_all_users);

        $this->db->select('COUNT(u.id) AS total')
                ->from('tbl_users u')
                ->where('u.status', 'active');

        if (!empty($likeArr)) {

            $this->db->group_start()

                    ->like('name', $search)

                    ->or_like('email', $search)

                    ->or_like('username', $search)

                    ->or_like($likeArr)

                    ->group_end();

        }

        $totalRec = $this->db->get()->row_array();

        $params = array('url' => base_url($this->ADM_URL . strtolower($this->data['class'])));

        $result['data'] = array();

        foreach ($get_all_users as $i => $user) {

            $params['id'] = $user['id'];

            $extra = array();

            $is_edit = is_access_module()["edit"]();

            $is_view = is_access_module()["view"]();

            $is_delete = is_access_module()["delete"]();

            // $action = $this->generate_actions($params, $is_edit, $is_view, $extra);
            // pre($action);

            $action = '<button class="nebula_user_rights_edit btn btn-link" data-id="'.$user['id'].'"><i class="fa fa-pencil"></i></button>';

            if ($is_edit == FALSE && $is_view == FALSE && empty($extra)){
                $action = '-';
            }

            $result['data'][] = array(

                'id' => ($offset + $i + 1),
                
                'name' => $user['name'],

                'email' =>($user['email'] != '' ? $user['email'] : 'NA'),

                'username' => ($user['username'] != '' ? $user['username'] : 'NA'),

                'role' => ($user['type'] != '' ? $user['type'] : 'NA'),

                'action' => $action

            );
        }

        $result["recordsTotal"] = (int) $totalRec['total'];

        $result["recordsFiltered"] = (int) $totalRec['total'];

        return $result;

    }

    // public function get_nebula_user_rights($user_id){
    //     $result = $this->second_db->select('nebula_user_rights.*')
    //                         ->from('nebula_user_rights')
    //                         ->where('nebula_user_rights.user_id' ,$user_id)
    //                         ->get()->row_array();

    //     // pre($result);

    //     $result['tab_option'] = implode(',', json_decode($result['tab_option']));
    //     $result['ticket_show_hide'] = implode(',', json_decode($result['ticket_show_hide']));
    //     $result['filter_options'] = implode(',', json_decode($result['filter_options']));
    //     $result['ticket_conversions_option'] = implode(',', json_decode($result['ticket_conversions_option']));
    //     $result['post_option'] = implode(',', json_decode($result['post_option']));

    //     return $result;
    // }

    public function nebula_dashboard_stats(){

        $todays_date = $this->ist_created_date;
        $todays_formatted_date = date("Y-m-d", strtotime($todays_date));

        $return_data['all_status'] = $this->getStatusTypes();

        $data['loggedInUserDept'] = $this->getLoggedInUserDepartment(getCurrentLoggedInUserID());
        
        if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) || !in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

            if (in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {
                $data['loggedInUserDept'] = nebula_sw_roles();
            }
        }

        /* START - Recent tickets only */  

        /* END - Recent tickets only */  
 
        /* START - Own/All Department tickets only */      
        
            // if(in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
            //     $data['loggedInUserDept'] = nebula_sw_roles();
            //     // if(in_array(getCurrentLoggedInUserType(), 'SW_DEV')){
            //     //     $data['loggedInUserDept'] = 'SW_DEV';
            //     // }
            // }else{

            //     $data['loggedInUserDept'] = $this->getLoggedInUserDepartment(getCurrentLoggedInUserID());
            // }

            // get departments from master table
            $dept_json = $this->second_db->select('nebula_master.*')
                            ->from('nebula_master')
                            ->get()->result_array();
                            // pre($dept_json);

            $own_department_todays_result = $this->second_db->select('form_mst.*')
                                                            ->from('nebula_form_mst form_mst')
                                                            ->where('form_mst.is_deleted', '0')
                                                            ->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                                                            // ->where('form_mst.created >=', $todays_formatted_date);
                                                            // ->group_start()  // Grouping conditions
                                                            //     ->where('form_mst.created >=', $todays_formatted_date)
                                                            //     ->or_where('form_mst.updated >=', $todays_formatted_date)
                                                            // ->group_end()  // End group
                                                            if (!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {
                                                                // not show ticket purpose is 'Task' for other users expect nebula_sw_roles()
                                                                $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                                                            }
                                                            $own_department_todays_result = $this->second_db->get()->result_array();
                                                            // pre($own_department_todays_result);
                                                            // pre($this->second_db->last_query());

            $return_data['own_dept_loggedInUser_department_ticket_count'] = count($own_department_todays_result);
            // pre($return_data['own_dept_loggedInUser_department_ticket_count']);

            $dept_coulmns = array_column($own_department_todays_result, 'orion_department');

            $depts_count = array_count_values($dept_coulmns);

            foreach ($dept_json as $row) {
                $data = json_decode($row['mst_data'], true);

                if (isset($data['departments'])) {
                    $depts = $data['departments'];

                }
            }

            // if userr is other than SW then unset 
            if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                unset($depts['SW']);
            }

            $all_dept_group = array();
            $all_dept_group = array_keys($depts);

            $final_depts = array();

            foreach ($depts as $dept_group => $roles) {
                $count = 0;
                
                foreach ($roles as $role) {
                    if(in_array($role, nebula_sw_roles())){
                        $role_lower = $role;
                    }else{
                        $role_lower = strtolower($role);
                    }
                    if (isset($depts_count[$role_lower])) {
                        $count += $depts_count[$role_lower];
                    }
                }
                
                $final_depts[$dept_group] = $count;
            }
            
            foreach($all_dept_group as $k => $v){

                foreach($final_depts as $key => $value){
                    if($v == $key && $value == 0){
                        unset($final_depts[$key]);
                        unset($all_dept_group[$k]);
                    }
                }
            }

            if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) || in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                $return_data['all_dept_group_count'] = implode(',', array_values($final_depts));
                $return_data['all_dept_group_names'] = $all_dept_group;
                $return_data['all_dept_group_names'] = implode(',', $all_dept_group);
               
            }else{
                $return_data['all_dept_group_names'] = '';  
                $return_data['all_dept_group_count'] = '';
            }
            
            /* START - All dept */

                $return_data['all_depts'] = $data['loggedInUserDept'];
                // pre($return_data['all_depts']);

                $return_data['all_dept_names'] = array_flip($return_data['all_depts']);
                $return_data['all_dept_names'] = array_keys($return_data['all_dept_names']);
                $return_data['all_dept_names'] = implode(',', $return_data['all_dept_names']);
                // pre($return_data['all_dept_names']);

                $return_data['dept_final_dept_counts'] = array_fill_keys(array_keys(array_flip($return_data['all_depts'])), 0);
                // pre($return_data['dept_final_dept_counts']);

                // Set Each Department Count 
                foreach ($own_department_todays_result as $ticket) {
                    $depts = $ticket['orion_department'];
                    if (isset($return_data['dept_final_dept_counts'][$depts])) {
                        $return_data['dept_final_dept_counts'][$depts]++;
                    }
                }

                $return_data['final_dept_counts_comma'] = implode(',', $return_data['dept_final_dept_counts']);

                // Unset if department count is 0 rettun only whoose count is '>0'
                foreach($return_data['all_depts'] as $k => $v){

                    // pre($return_data['dept_final_dept_counts']);
                    foreach($return_data['dept_final_dept_counts'] as $key => $value){
                        if($v == $key && $value == 0){
                            unset($return_data['dept_final_dept_counts'][$key]);
                            unset($return_data['all_depts'][$k]);
                        }
                    }
                }

                // remove '_' and small to uppercase
                foreach($return_data['all_depts'] as $k => $v){
                    $return_data['all_depts'][$k] = ucwords(str_replace('_', ' ', $v));
                }

                // return only whoose department have tickets
                    $return_data['all_final_dept'] = implode(',', $return_data['all_depts']);
                    $return_data['dept_final_count_values'] = implode(',', array_values($return_data['dept_final_dept_counts']));
               
            /* END - All Dept */

            /* START - for percentage */
                // $return_data['own_dept_all_status_percentage'] = array();
                // foreach ($return_data['own_dept_final_status_counts'] as $status => $count) {
                //     $percentage = ($return_data['own_dept_loggedInUser_department_ticket_count'] > 0) ? ($count / $return_data['own_dept_loggedInUser_department_ticket_count']) * 100 : 0;
                //     $return_data['own_dept_all_status_percentage'][$status] = round($percentage, 2); 
                // }
                // // pre($return_data['own_dept_all_status_percentage']);

                // $return_data['own_dept_all_status_percentage_comma'] = implode(',', $return_data['own_dept_all_status_percentage']);

                // foreach($return_data['all_status'] as $k => $v){

                //     foreach($return_data['own_dept_all_status_percentage'] as $key => $value){
                //         if($k == $key && $value == 0){
                //             unset($return_data['own_dept_all_status_percentage'][$key]);
                //             unset($return_data['all_status'][$k]);
                //         }
                //     }
                // }

                // $return_data['own_dept_all_status_percentage_values'] = implode(',', array_values($return_data['own_dept_all_status_percentage']));
                // $return_data['own_dept_all_status_percentage_values'] = $return_data['own_dept_all_status_percentage_values'].',0,0,0,0,0';
            /* END - for percentage */

        /* END - Own/All Department tickets only */  
 

        /* START - Working for own tickets only */
            $loggedin_user_todays_result = $this->second_db->select('nebula_form_mst.*')
                                            ->from('nebula_form_mst');
                                            if (!in_array(getCurrentLoggedInUserType(), ['SW_ADMIN', 'SW_QA'])) {
                                                $this->second_db->where('inserted_by', getCurrentLoggedInUserID());
                                            }
                                            $this->second_db->where('is_deleted', '0')
                                            ->group_start()  // Grouping conditions
                                                ->where('created >=', $todays_formatted_date)
                                                ->or_where('updated >=', $todays_formatted_date)
                                            ->group_end();  // End group
                                            $loggedin_user_todays_result = $this->second_db->get()->result_array();
                                            // pre($loggedin_user_todays_result);
                                            // pre($this->second_db->last_query());


            $return_data['loggedInUser_ticket_count'] = count($loggedin_user_todays_result);
            // pre($return_data['loggedInUser_ticket_count']);

            $return_data['all_status_names'] = array_flip($return_data['all_status']);
            $return_data['all_status_names'] = array_keys($return_data['all_status_names']);
            $return_data['all_status_names'] = implode(',', $return_data['all_status_names']);

            // Initialize the status counts array with 0 for all statuses
            $return_data['final_status_counts'] = array_fill_keys(array_keys($return_data['all_status']), 0);

            // Loop through the tickets and count statuses
            foreach ($loggedin_user_todays_result as $ticket) {
                $status = $ticket['status_type'];
                if (isset($return_data['final_status_counts'][$status])) {
                    $return_data['final_status_counts'][$status]++;
                }
            }

            // get the all status counts 
            foreach($return_data['all_status'] as $k => $v){

                foreach($return_data['final_status_counts'] as $key => $value){
                    if($k == $key && $value == 0){
                        unset($return_data['final_status_counts'][$key]);
                        unset($return_data['all_status'][$k]);
                    }
                }
            }

            /* START - get percentage wise */
                // $return_data['all_status_percentage'] = array();
                // foreach ($return_data['final_status_counts'] as $status => $count) {
                //     $percentage = ($return_data['loggedInUser_ticket_count'] > 0) ? ($count / $return_data['loggedInUser_ticket_count']) * 100 : 0;
                //     $return_data['all_status_percentage'][$status] = round($percentage, 2); 
                // }

                // $return_data['all_status_percentage_comma'] = implode(',', $return_data['all_status_percentage']);

                // foreach($return_data['all_status'] as $k => $v){

                //     foreach($return_data['all_status_percentage'] as $key => $value){
                //         if($k == $key && $value == 0){
                //             unset($return_data['all_status_percentage'][$key]);
                //             unset($return_data['all_status'][$k]);
                //         }
                //     }
                // }
            /* END - get percentage wise */

            $return_data['all_status'] = implode(',', $return_data['all_status']);
            $return_data['final_status_counts'] = implode(',', $return_data['final_status_counts']);
            // $return_data['all_status_percentage'] = implode(',', $return_data['all_status_percentage']);

            $return_data['all_status_percentage_values'] = implode(',', array_values($return_data['all_status_percentage']));
            $return_data['all_status_percentage_values'] = $return_data['all_status_percentage_values'].',0,0,0,0,0';
            // pre($return_data);

        /* END - Working for own tickets only */


        /* START - for all records */
            
            // $start_date = $data['filter_global']['report_start_date'] . ' 00:00:00';
            // $this->second_db->where('form_mst.created >=', $start_date);

            // $nebula_result = $this->second_db->select('nebula_form_mst.*')
            //                             ->from('nebula_form_mst')
            //                             ->where('is_deleted', '0')
            //                             ->get()->result_array();
            //                             // print_last_query();

            //                             // pre($this->second_db->last_query());
            //                             pre($nebula_result);

            // $all_ticket_count = count($nebula_result);
            // $return_data['all_ticket_count'] = $all_ticket_count;

            // $all_status = $this->getStatusTypes(); // total : 7
            // $return_data['all_status'] = $all_status;
    
            // // Initialize the status counts array with 0 for all statuses
            // $final_status_counts = array_fill_keys(array_keys($all_status), 0);
            
            // // Loop through the tickets and count statuses
            // foreach ($nebula_result as $ticket) {
            //     $status = $ticket['status_type'];
            //     if (isset($final_status_counts[$status])) {
            //         $final_status_counts[$status]++;
            //     }
            // }

            // // pre($final_status_counts);
            // $return_data['final_status_counts'] = $final_status_counts;
        
            // // $total_tickets = count($nebula_result);

            // $all_status_percentage = array();
            // foreach ($final_status_counts as $status => $count) {
            //     $percentage = ($all_ticket_count > 0) ? ($count / $all_ticket_count) * 100 : 0;
            //     $all_status_percentage[$status] = round($percentage, 2); 
            // }

            // // pre($all_status_percentage);
            // $return_data['all_status_percentage'] = $all_status_percentage;
        /* END - for all records */

        return $return_data;

    }


    function getWeekMonthDates($currentDate) {
        // Set the timezone to Asia/Kolkata
        // date_default_timezone_set('Asia/Kolkata');
    
        // // Get the current date
        // $currentDate = new DateTime();

        // Get todays date
        $startOfToday = clone $currentDate;
        $startOfToday->setTime(0, 0, 0);

        $endOfToday = clone $startOfToday;
        $endOfToday->setTime(23, 59, 59);
    
        // Get the start and end dates of this week (Monday to Sunday)
        $startOfWeek = clone $currentDate;
        $startOfWeek->modify('monday this week')->setTime(0, 0, 0); 
        $endOfWeek = clone $startOfWeek;
        $endOfWeek->modify('sunday this week')->setTime(23, 59, 59); 
    
        // Get the start and end dates of this month
        $startOfMonth = clone $currentDate;
        $startOfMonth->modify('first day of this month')->setTime(0, 0, 0);
        $endOfMonth = clone $startOfMonth;
        $endOfMonth->modify('last day of this month')->setTime(23, 59, 59); 
        
        // Get the start and end dates of this year
        $startOfYear = clone $currentDate;
        $startOfYear->modify('first day of January')->setTime(0, 0, 0); 
        $endOfYear = clone $startOfYear;
        $endOfYear->modify('last day of December')->setTime(23, 59, 59);

        // Get the start and end dates of the last day (yesterday)
        $startOfLastDay = clone $currentDate;
        $startOfLastDay->modify('yesterday')->setTime(0, 0, 0); // Start of yesterday
        $endOfLastDay = clone $startOfLastDay;
        $endOfLastDay->setTime(23, 59, 59); // End of yesterday

        // Get the start and end dates of the last week (last Monday to last Sunday)
        $startOfLastWeek = clone $currentDate;
        $startOfLastWeek->modify('monday last week')->setTime(0, 0, 0);
        $endOfLastWeek = clone $startOfLastWeek;
        $endOfLastWeek->modify('next sunday')->setTime(23, 59, 59);

        // Get the start and end dates of the last month
        $startOfLastMonth = clone $currentDate;
        $startOfLastMonth->modify('first day of last month')->setTime(0, 0, 0);
        $endOfLastMonth = clone $startOfLastMonth;
        $endOfLastMonth->modify('last day of this month')->setTime(23, 59, 59); 
            
        // Return an array with the week and month start and end dates
        return [
            'todays_date_start'  => $startOfToday->format('Y-m-d H:i:s'),
            'todays_date_end'    => $endOfToday->format('Y-m-d H:i:s'),
            'this_week_start'    => $startOfWeek->format('Y-m-d H:i:s'),
            'this_week_end'      => $endOfWeek->format('Y-m-d H:i:s'),
            'this_month_start'   => $startOfMonth->format('Y-m-d H:i:s'),
            'this_month_end'     => $endOfMonth->format('Y-m-d H:i:s'),
            'this_year_start'    => $startOfYear->format('Y-m-d H:i:s'),
            'this_year_end'      => $endOfYear->format('Y-m-d H:i:s'),
            'last_day_start'     => $startOfLastDay->format('Y-m-d H:i:s'),
            'last_day_end'       => $endOfLastDay->format('Y-m-d H:i:s'),
            'last_week_start'    => $startOfLastWeek->format('Y-m-d H:i:s'),
            'last_week_end'      => $endOfLastWeek->format('Y-m-d H:i:s'),
            'last_month_start'   => $startOfLastMonth->format('Y-m-d H:i:s'),
            'last_month_end'     => $endOfLastMonth->format('Y-m-d H:i:s'),
        ];
    }

    public function filterTicketsByDate($result, $startDate, $endDate) {
        // Convert the start and end dates to DateTime objects
        $startDate = new DateTime($startDate);
        $endDate = new DateTime($endDate);
        $endDate->setTime(23, 59, 59); // Set end time to the end of the day
    
        // Filter the result array
        $filteredTickets = array_filter($result, function($ticket) use ($startDate, $endDate) {
            // Convert the 'created' date of the ticket to a DateTime object
            $createdDate = new DateTime($ticket['created']);
    
            // Check if the created date is within the given range
            return $createdDate >= $startDate && $createdDate <= $endDate;
        });
    
        return $filteredTickets;
    }

    public function nebula_dashboard_status_stats_filters($param){
        
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $statusCounts = [];

        $data['loggedInUserDept'] = $this->getLoggedInUserDepartment(getCurrentLoggedInUserID());
        
        // When getCurrentLoggedInUserType == Dev OR who have only access their tickets
        if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) || !in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

            if (in_array(getCurrentLoggedInUserType(), nebulaSWADMINQARoles())) {
                $data['loggedInUserDept'] = nebula_sw_roles();
            }
        }
        

        $result = $this->second_db->select('form_mst.ticket_id, form_mst.orion_department, form_mst.status_type, form_mst.created, form_mst.updated')
                        ->from('nebula_form_mst form_mst')
                        ->where('form_mst.is_deleted', '0');
                        
                        // START - Working query
                        // if (!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {
                        //     if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                        //         // not show ticket purpose is 'Task' for other users expect nebula_sw_roles()
                        //         //MY: Add Comment because make Purpose Value Dynamically
                        //         $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                        //         //$this->second_db->where_not_in('form_mst.purpose', ['assign_task']);
                        //     }
                        // }
                        // END - Working query

                        if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                
                            if(in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                                if (getCurrentLoggedInUserType() == 'SW_DEV') {
                                    $data['loggedInUserDept'] = nebula_sw_roles();
                                }
                                $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                            }else{
                                if (getCurrentLoggedInUserType() != 'SW_DEV') {
                                    $this->second_db->where('form_mst.inserted_by', getCurrentLoggedInUserID());
                                }
                            }                    
                        }

                        // not show ticket purpose is 'Task' for other users expect nebula_sw_roles()
                        if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                            $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                        }

                        if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

                            // if user type is other than 'SW' then remove 'SW' users
                            if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                                foreach($data['loggedInUserDept'] as $key => $value){
                                    if(in_array($value, nebula_sw_roles())){
                                        unset($data['loggedInUserDept'][$key]);
                                    }
                                }
                                $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                            }
                        }

                        // to get current assignee developer data (for dev login)
                        if (getCurrentLoggedInUserType() == 'SW_DEV') {
                            if(!in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) && !in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                                    $this->second_db->group_start()
                                        ->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                                        ->or_where('form_mst.inserted_by', getCurrentLoggedInUserID()) // this condition to shows ticket created by loggnedIn developer
                                    ->group_end();
                            }
                        }

                        $result = $this->second_db->get()->result_array();
                       
        if(empty($result)){

            if(empty($statusCounts)){
                $content['status'] = 200;
                $content['message'] = 'Data Not Found';
                $content['data'] = $statusCounts;
            }
            return $content;
        }

        $todays_date = $this->ist_created_date;

        // Convert string to DateTime object
        $todays_date = new DateTime($todays_date);
        
        // To Get Dates
        $final_dates = $this->getWeekMonthDates($todays_date);
     
        $start_date = '';
        $end_date = '';

        if($param['status_stat_filter'] == 'today' || $param['dept_stat_filter'] == 'today'){
            $start_date = $final_dates['todays_date_start'];
            $end_date = $final_dates['todays_date_end'];
        }elseif($param['status_stat_filter'] == 'last_day' || $param['dept_stat_filter'] == 'last_day'){
            $start_date = $final_dates['last_day_start'];
            $end_date = $final_dates['last_day_end'];
        }if($param['status_stat_filter'] == 'this_week' || $param['dept_stat_filter'] == 'this_week'){
            $start_date = $final_dates['this_week_start'];
            $end_date = $final_dates['this_week_end'];
        }elseif($param['status_stat_filter'] == 'last_week' || $param['dept_stat_filter'] == 'last_week'){
            $start_date = $final_dates['last_week_start'];
            $end_date = $final_dates['last_week_end'];
        }elseif($param['status_stat_filter'] == 'this_month' || $param['dept_stat_filter'] == 'this_month'){
            $start_date = $final_dates['this_month_start'];
            $end_date = $final_dates['this_month_end'];
        }elseif($param['status_stat_filter'] == 'last_month' || $param['dept_stat_filter'] == 'last_month'){
            $start_date = $final_dates['last_month_start'];
            $end_date = $final_dates['last_month_end'];
        }elseif($param['status_stat_filter'] == 'this_year' || $param['dept_stat_filter'] == 'this_year'){
            $start_date = $final_dates['this_year_start'];
            $end_date = $final_dates['this_year_end'];
        }

        // To Get result data by start date and end date
        $filteredResult = $this->filterTicketsByDate($result, $start_date, $end_date);

        $statusCounts = [];

        foreach ($filteredResult as $row) {
            // Get the status_type for the current row
            $status = ucwords(str_replace('_', ' ', $row['status_type']));

            // Increment the count for this status_type
            if (isset($statusCounts[$status])) {
                $statusCounts[$status]++;
            } 
            else {
                $statusCounts[$status] = 1;
            }
        }

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        if(empty($statusCounts)){
            $content['status'] = 200;
            $content['message'] = 'Data Not Found';
            $content['data'] = $statusCounts;
        }elseif(!empty($statusCounts)){
            $content['status'] = 200;
            $content['message'] = 'Success';
            $content['data'] = $statusCounts;
        }
        
        return $content;
        
    }

    public function nebula_dashboard_dept_stats_filters($param){

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        $final_depts = array();

        $data['loggedInUserDept'] = $this->getLoggedInUserDepartment(getCurrentLoggedInUserID());
        
        // If user have no access for department chart
        if(!in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) && !in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
            
            if(empty($final_depts)){
                $content['status'] = 200;
                $content['message'] = 'Data Not Found';
                $content['data'] = $final_depts;
            }
            return $content;

        }
        
        // When getCurrentLoggedInUserType == Dev OR who have only access their tickets
        if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) || !in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

            if (in_array(getCurrentLoggedInUserType(), nebulaSWADMINQARoles())) {
                $data['loggedInUserDept'] = nebula_sw_roles();
            }
        }
        
        $result = $this->second_db->select('form_mst.ticket_id, form_mst.orion_department, form_mst.status_type, form_mst.created, form_mst.updated')
                        ->from('nebula_form_mst form_mst')
                        ->where('form_mst.is_deleted', '0');
                        
                        // START - Working QUERY
                        // if (!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())) {
                        //     if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                        //         // not show ticket purpose is 'Task' for other users expect nebula_sw_roles()
                        //         //MY: Add Comment because make Purpose Value Dynamically
                        //         $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                        //         //$this->second_db->where_not_in('form_mst.purpose', ['assign_task']);
                        //     }
                        // }
                        // END - Working QUERY

                        if(!in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                
                            if(in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                                if (getCurrentLoggedInUserType() == 'SW_DEV') {
                                    $data['loggedInUserDept'] = nebula_sw_roles();
                                }
                                $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                            }else{
                                if (getCurrentLoggedInUserType() != 'SW_DEV') {
                                    $this->second_db->where('form_mst.inserted_by', getCurrentLoggedInUserID());
                                }
                            }                    
                        }

                        // not show ticket purpose is 'Task' for other users expect nebula_sw_roles()
                        if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                            $this->second_db->where_not_in('form_mst.purpose', ['task_assign']);
                        }
                        
                        if(in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){

                            // if user type is other than 'SW' then remove 'SW' users
                            if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                                foreach($data['loggedInUserDept'] as $key => $value){
                                    if(in_array($value, nebula_sw_roles())){
                                        unset($data['loggedInUserDept'][$key]);
                                    }
                                }
                                $this->second_db->where_in('form_mst.orion_department', $data['loggedInUserDept']);
                            }
                        }

                        // to get current assignee developer data (for dev login)
                        if (getCurrentLoggedInUserType() == 'SW_DEV') {
                            if(!in_array(own_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"]) && !in_array(all_department_ticket_string(), checkUserPermission(getCurrentLoggedInUserID())["ticket_show_hide"])){
                                    $this->second_db->group_start()
                                        ->where('FIND_IN_SET(' . getCurrentLoggedInUserID() . ',form_mst.trainer_id) > 0') // to show only assigned to loggnedIn developer
                                        ->or_where('form_mst.inserted_by', getCurrentLoggedInUserID()) // this condition to shows ticket created by loggnedIn developer
                                    ->group_end();
                            }
                        }

                        $result = $this->second_db->get()->result_array();
                        
        if(empty($result)){

            if(empty($final_depts)){
                $content['status'] = 200;
                $content['message'] = 'Data Not Found';
                $content['data'] = $final_depts;
            }
            return $content;
        }

        $todays_date = $this->ist_created_date;

        // Convert string to DateTime object
        $todays_date = new DateTime($todays_date);
        
        // To Get Dates
        $final_dates = $this->getWeekMonthDates($todays_date);
     
        $start_date = '';
        $end_date = '';

        // pre($param['dept_stat_filter']);
        if($param['dept_stat_filter'] == 'today'){
            $start_date = $final_dates['todays_date_start'];
            $end_date = $final_dates['todays_date_end'];
        }elseif($param['dept_stat_filter'] == 'last_day'){
            $start_date = $final_dates['last_day_start'];
            $end_date = $final_dates['last_day_end'];
        }if($param['dept_stat_filter'] == 'this_week'){
            $start_date = $final_dates['this_week_start'];
            $end_date = $final_dates['this_week_end'];
        }elseif($param['dept_stat_filter'] == 'last_week'){
            $start_date = $final_dates['last_week_start'];
            $end_date = $final_dates['last_week_end'];
        }elseif($param['dept_stat_filter'] == 'this_month'){
            $start_date = $final_dates['this_month_start'];
            $end_date = $final_dates['this_month_end'];
        }elseif($param['dept_stat_filter'] == 'last_month'){
            $start_date = $final_dates['last_month_start'];
            $end_date = $final_dates['last_month_end'];
        }elseif($param['dept_stat_filter'] == 'this_year'){
            $start_date = $final_dates['this_year_start'];
            $end_date = $final_dates['this_year_end'];
        }

        // To Get result data by start date and end date
        $filteredResult = $this->filterTicketsByDate($result, $start_date, $end_date);

        $dept_json = $this->second_db->select('nebula_master.*')
                            ->from('nebula_master')
                            ->get()->result_array();

        $dept_coulmns = array_column($filteredResult, 'orion_department');

        $depts_count = array_count_values($dept_coulmns);

        foreach ($dept_json as $row) {
            $data = json_decode($row['mst_data'], true);

            if (isset($data['departments'])) {
                $depts = $data['departments'];

            }
        }

        // if userr is other than SW then unset 
        if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
            unset($depts['SW']);
        }

        $all_dept_group = array();
        $all_dept_group = array_keys($depts);

        foreach ($depts as $dept_group => $roles) {
            $count = 0;
            
            foreach ($roles as $role) {
                if(in_array($role, nebula_sw_roles())){
                    $role_lower = $role;
                }else{
                    $role_lower = strtolower($role);
                }
                if (isset($depts_count[$role_lower])) {
                    $count += $depts_count[$role_lower];
                }
            }
            
            $final_depts[$dept_group] = $count;
        }
        
        foreach($all_dept_group as $k => $v){

            foreach($final_depts as $key => $value){
                if($v == $key && $value == 0){
                    unset($final_depts[$key]);
                    unset($all_dept_group[$k]);
                }
            }
        }

        $final_depts;

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];

        if(empty($final_depts)){
            $content['status'] = 200;
            $content['message'] = 'Data Not Found';
            $content['data'] = $final_depts;
        }elseif(!empty($final_depts)){
            $content['status'] = 200;
            $content['message'] = 'Success';
            $content['data'] = $final_depts;
        }
        
        return $content;

    }
}
