<?php
defined('BASEPATH') OR exit('No direct script access allowed');


    function standardizePriorityOption($priority) {
      // Convert to title case and replace spaces with underscores
      $priority = strtolower($priority);
     // $priority = ucwords($priority);  // Make the first letter of each word uppercase
      $priority = str_replace(' ', '_', $priority);  // Replace spaces with underscores
      return $priority;
    }

   function priorityOptions(){
        $CI = &get_ci_instance();

        if (!isset($CI->second_db)) {
                $CI->load->database('second_db', TRUE); // Load second_db as a separate connection
        }
        $prio_name = $CI->second_db->select('priority')
                                    ->from('nebula_priority_table')
                                    ->get()->result_array();
        foreach ($prio_name as $item) {
            // Standardize the priority and set it dynamically
            $priorityKey = standardizePriorityOption($item['priority']);
            $newArray[$priorityKey] = $item['priority'];
        }
        return $newArray;
    }

    function ticket_purpose_types(){
        $ticket_purpose_types = array(
            'report_bug' => 'Bug',
            'feature_request' => 'Feature',
            'training' => 'Training',
            'assign_task' => 'Task'
        );
        return $ticket_purpose_types;
    }

    /**
     *MY: Purpose Type Master Data Get
     */
    function purposeTypes()
    {
        $purposeArray = [];
        $CI = &get_ci_instance();
        if (!isset($CI->second_db)) {
            $CI->load->database('second_db', TRUE);
        }
        $CI->second_db->select('mst_data');
        $CI->second_db->where("JSON_CONTAINS_PATH(mst_data, 'one', '$.purpose')", null, false);
        $query = $CI->second_db->get('nebula_master');
        $getMstData = $query->row_array();
        if ($getMstData) {
            $mstData = $getMstData['mst_data'];
            $getMstArray = json_decode($mstData, true);
            $purposeArray = $getMstArray['purpose'];
        }
        return $purposeArray;
    }

    /**
     * MY:Purpose Type Property Master Data Get
     */
    function purposeTypeProperty()
    {
        $purposeArray = [];
        $CI = &get_ci_instance();
        if (!isset($CI->second_db)) {
            $CI->load->database('second_db', TRUE);
        }
        $CI->second_db->select('mst_data');
        $CI->second_db->where("JSON_CONTAINS_PATH(mst_data, 'one', '$.purpose_property')", null, false);
        $query = $CI->second_db->get('nebula_master');
        $getMstData = $query->row_array();
        if ($getMstData) {
            $mstData = $getMstData['mst_data'];
            $getMstArray = json_decode($mstData, true);
            $purposeArray = $getMstArray['purpose_property'];
        }
        return $purposeArray;
    }

    // this function for to access some functionality to the defined users like: Nebula form : can add tickets by other departments 
    function nebula_functionality_access(){
        $user = ["Shubham Kumbhar"]; // add UserName i.e. name column from tbl_users
        return $user;
    }

    function nebula_userwise_screenshow(){

        $user = ["Vrushabh Gundecha VG","Hignesh Hirani"];
        return $user;

    }

    function nebula_hide_screens(){
        $user = ["Kalpesh Patel"];
        return $user;
    }

    function nebula_check_role(){

        $user = ['SW_ADMIN', 'SW_QA', 'SW_DEV'];
        return $user;

    }

    function nebula_sw_roles(){

        $user = ['SW_ADMIN', 'SW_QA', 'SW_DEV'];
        return $user;

    }

    function nebula_sw_dev_roles(){

        $user = ['SW_DEV'];
        return $user;

    }

    function nebula_sw_admin_role(){

        $user = ['SW_ADMIN'];
        return $user;

    }

    function nebulaSWADMINQARoles(){

        $user = ['SW_ADMIN', 'SW_QA'];
        return $user;

    }

    function orion_department_group(){
        $dept_group = array(
            "PMT" => array("project_manager"),
            "PCT" => array('sales', 'pct_tl', 'pct', 'marketing', 'marketing_manager'),
            "BPT" => array('bpt'),
            "Estimator" => array('estimation_tl', 'estimator', 'isolator', 'product_sp', 'product_engineer'),
            "Proposal" => array('proposal_tl', 'proposal', 'proposal_qc'),
            "Buyer" => array('buyer_tl', 'buyer'),
            "Logistics" => array('logistics'),
            "Legal" => array('legal'),
            "FAT" => array('accounting', 'report'),
            "SW" => array('SW_ADMIN', 'SW_DEV', 'SW_QA')
        );

        return $dept_group;
        
    }

    function getISTTime($created_date){
          
        $createdDate = new DateTime($created_date); // Convert string to DateTime object

        // // Set Timezone (IST/EST)
        $createdDate = $createdDate->setTimezone(new DateTimeZone('Asia/Kolkata'));
        $createdDateFormatted = $createdDate->format('Y-m-d H:i:s');

        return $createdDateFormatted;
    }

    function checkUserPermission($currentLoggedInUserID){
        $CI = &get_ci_instance();

        $data=[];
        $result = $CI->second_db->select('nebula_user_rights.*')
                                    ->from('nebula_user_rights')
                                    ->where('nebula_user_rights.user_id', $currentLoggedInUserID)
                                    ->get()->row_array();

        
        $data['tab_option'] = json_decode($result['tab_option']);
        $data['ticket_show_hide'] = json_decode($result['ticket_show_hide']);
        $data['filter_options'] = json_decode($result['filter_options']);
        $data['post_option'] = json_decode($result['post_option']);
        $data['ticket_conversions_option'] = json_decode($result['ticket_conversions_option']);
        $data['export_option'] = json_decode($result['export_option']);

       return $data;

    }

    function every_tab_string(){
        return "every_tab";
    }

    function all_tab_string(){
        return "all_tab";
    }

    function own_ticket_string(){
        return "own_ticket";
    }

    function own_department_ticket_string(){
        return "own_department_ticket";
    }

    function all_department_ticket_string(){
        return "all_department_ticket";
    }

    function dept_filter_string(){
        return "nebula_dept_filter";
    }

    function ticket_type_filter_string(){
        return "nebula_ticket_type_filter";
    }

    function status_filter_string(){
        return "nebula_status_filter";
    }

    function datewise_filter_string(){
        return "nebula_datewise_filter";
    }

    function nebula_created_updated_filter_string(){
        return "nebula_created_updated_filter";
    }

    function ticket_conversions_type_filter_string(){
        return "ticket_conversions_type_filter";
    }

    function ticket_conversions_priority_filter_string(){
        return "ticket_conversions_priority_filter";
    }

    function ticket_conversions_assign_to_filter_string(){
        return "ticket_conversions_assign_to_filter";
    }

    function ticket_conversions_status_filter_string(){
        return "ticket_conversions_status_filter";
    }

    function nebula_export_excel_filter_string(){
        return "nebula_export_excel_filter";
    }
   
