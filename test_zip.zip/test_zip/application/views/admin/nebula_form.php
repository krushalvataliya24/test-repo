<div class="modal left fade nebula_modal" id="exampleModal"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-header bg-danger">
            <h5 class="modal-title">Nebula Form</h5>
        </div>
        <div class="modal-content">
            <div class="modal-body pt-0"> 
                <form id="nebulaForm" class="nebula-form w-100 pt-2" enctype="multipart/form-data">  
                    <div class="w-100 mb-1">
                        <label for="title">Title<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="title" id="title" placeholder="Type title here" maxlength="200" required>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">              

                            </div>
                            <div class="col-lg-6">  
                                <div class="form-group mt-0">
                                    <label>Orion Department</label>
                                    <?php if(getCurrentLoggedInUserType() == 'SW_ADMIN' || getCurrentLoggedInUserType() == 'SW_QA' || in_array(getCurrentLoggedInUserName(), nebula_functionality_access())){ 
                                                $is_disabled = '';
                                            }else{
                                                $is_disabled = 'disabled';
                                            }
                                    ?>
                                    <select class="form-control" id="orion_department" name="orion_department" required <?= $is_disabled ?>>
                                        <option value="<?= getCurrentLoggedInUserType() ?>"><?= ucfirst(getCurrentLoggedInUserType()) ?></option>
                                        <?php //$nebula_data = getAllDeparmentsNebula(); ?>
                                        <?php //foreach($nebula_data as $key => $value){ ?>
                                            <!-- <option value="<?= $value['type'] ?>"><?= ucfirst($value['type']); ?></option> -->
                                        <?php //} ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">  
                                <div class="form-group mt-0">
                                    <label>Category<span class="text-danger">*</span></label>
                                    <select class="form-control" id="orion_sub_modules" name="orion_sub_modules" required>
                                        <option value="">Select</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">  
                                <div class="form-group mt-0">
                                    <label>Purpose<span class="text-danger">*</span></label>
                                    <select class="form-control" id="purpose" name="purpose" required>
                                        <option value="">Select</option>
                                    </select>
                                </div>
                            </div>
                            <!-- Naman Start -->
                            <div class="col-lg-6"> 
                                <div class="form-group mt-0">
                                    <label>Priority <span class="text-danger">*</span></label>
                                   
                                    
                                    <select class="form-control" id="priority" name="priority" required>
                                       
                                    </select>
                                </div>
                            </div>
                            <!-- Naman End -->
                            <div id="fileModal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <div id="modalContent"></div>
                                </div>
                            </div>
                            <div class="col-lg-12"> 
                                <div class="form-group mt-0">
                                    <label>Description</label>
                                    <textarea rows="3" name="content" id="notes" style="height: 120px; resize: none; overflow-y: auto;"></textarea>
                                    <span id="charCount" class="float-right">Characters: 6000/6000</span>
                                </div>
                            </div>
                            <div class="col-lg-12"> 
                                <div class="form-group">
                                    
                                </div>
                            </div>
                    </div>
                    <?php if($check_access){ ?>
                    <div class="row">
                        <div class="col-lg-12">  
                            <div class="form-group mt-0">
                                <label>Department TL</label>
                                <div class="form-control" id="department_tl" name="department_tl" style="height: 100px; overflow-y: auto;" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">  
                            <div class="form-group mt-0">
                                <label>Software TL</label>
                                <div class="form-control" id="software_tl" name="software_tl" style="height: 100px; overflow-y: auto;" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>

                    <div class="modal-footer flex-wrap">
                        <div class="footer-upload">
                            <div class="upload-file-container" id="upload-file-container">
                                <div class="uploaded-files-list"></div>
                                <div class="form-group mt-0 mb-0">                                    
                                    <div id="drop-area" class="custom-file drop-area mt-0">
                                        <input type="file" class="custom-file-input upload_file d-none" id="upload_file" name="upload_file[]" accept=".xlsx, .xls, .jpg, .jpeg, .png, .doc, .docx, .csv, .tsv, .txt, .rtf, .pdf" multiple>
                                        <label class="" for="upload_file">
                                            <span>Upload</span></label>    
                                    </div>
                                </div>      
                            </div>
                        <div>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn submit_form" data-ticket_id="" style="background-color: #eba322;color: #fff;">Submit</button>
                    </div>
                    
                </form>
            </div>
            
            </div>
            </div>
        </div>
    </div>
</div>



<style>

    #nebulaForm .ck.ck-content {
        max-height: 180px;
        overflow: auto;
        min-height: 180px;
    }
    .ck.ck-balloon-panel {
        z-index: 1050 !important;
    }  /* This Is For The Link Add In The Discription */
    .requisiting-title-box {
        margin-right: -20px;
        margin-left: -20px;
    }
    .requisiting-title {
        /* background-color: #c74d4d; */
        font-size: 22px;
    }
    .ck-editor__editable {
        min-height: 130px;
    }
    .modal-footer.flex-wrap {
        position: fixed;
        width: 100%;
        bottom: 0;
        left: 0;
    }
    #nebulaForm .custom-file label {
        position: absolute;
        width: 560px;
        top: -156px;
        height: 200px;
        z-index: -21;
        left: -391px;
    }
    .uploaded-files-list {
        width: 93%;
        position: absolute;
        bottom: 59px;
        max-height: 238px;
        overflow: auto;
        left: 21px;
    }
    .upload-file-container .custom-file label span {
        background-color: #f1f1f1;
        width: 176px;
        text-align: center;
        padding: 7px;
        border-radius: 0;
        border: 1px solid #ddd;
        position: absolute;
        bottom: 0;
    }
    .footer-upload {
        display: flex;
        justify-content: space-between;
        width: 156px;
        padding: 0;
        margin: 0;
        align-items: flex-end;
    }
    .fileBox .defaultFileIcon {
        width: 50px;
        height: 50px;
        background-color: #f0f0f0;
        text-align: center;
        line-height: 50px;
        font-size: 12px;
        color: #555;
        margin-right: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .uploaded-files-list {
        margin-top: 10px;
    }
    .upload-action-btn button {
        padding: 5px;
    }
    .upload-action-btn button.btn.btn-danger.mr-1 {
        background-color: rgb(255 0 0 / 10%);
        margin-right: 3px !important;
    }
    .fileBox {
    display: flex;
    width: 100%;
    height: 28px;
    border: 1px solid #ccc;
    text-align: center;
    position: relative;
    box-sizing: border-box;
    margin-bottom: 10px;
    align-items: center;
}
button.removeButton {
    padding: 8px;
}
    .fileBox .fileName {
        font-size: 14px;
        padding: 5px;
        word-wrap: break-word;
        flex-grow: 1;
        text-align: left;
    }
    .fileBox .previewImage {
        width: 50px;
        height: 50px;
        object-fit: cover;
        margin-right: 10px;
    }
    .removeButton {
        border : none;
    }
    #fileModal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgb(0, 0, 0);
        background-color: rgba(0, 0, 0, 0.4);
        padding-top: 60px;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }
    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
    #drop-area.dragging {
        background-color: #f0f0f0;
    }
</style>


<script></script>
<script src="<?php echo base_url() . ADM_JS; ?>nebula_form.js?<?php echo filemtime(FCPATH . ADM_JS . 'nebula_form.js'); ?>"></script>
<?php //$this->load->view("admin/nebula_form_js"); ?>


<script>
    // $("#department_tl").select2();
</script>

<style>
    /* .Zebra_DatePicker_Icon_Wrapper:has( .nebula-data){width:100% !important} */
</style>


<script>

nebula_ckeditor("notes");

        

</script>