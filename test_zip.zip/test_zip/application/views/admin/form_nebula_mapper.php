   <!-- /page header -->

   <div class="page-header page-header-light">
    <div class="page-header-content header-elements-md-inline">
       <div class="page-title d-flex">
          <h4><?php echo $headTitle; ?></h4>
       </div>
    </div>
  <div class="bradcrumb-sec"><?php echo $bradcrumb; ?> </div>
 </div>
 
 
 <div class="content">
 
     <!-- Horizontal form options -->
                
     <div class="row">
 
         <div class="col-md-12">

 
                 <form class="form-horizontal" name="frmNebulaModulesMapping" id="frmNebulaModulesMapping" method="post" enctype="multipart/form-data" >
                         <input type="hidden" name="id" value="<?php echo $mapping_data['id']; ?>" />
 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="department"><?php echo $this->lang->line('lbl_department') ?><?php echo MEND_SIGN; ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select department select2" name="department" id="department" required>
                                    <option>-- Select Timezone --</option>
                                    <option value="ist">Indian Standard Time (IST) (UTC +05:30)</option>
                                    <option value="est">Eastern Standard Time (EST) (UTC -05:00)</option>
                                </select>
                            </div>
                         </div>
 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="modules"><?php echo $this->lang->line('lbl_module') ?><?php echo MEND_SIGN; ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select modules select2" name="modules" id="modules" required>
                                    <option>-- Select Date Format --</option>
                                    <option value="d-m-Y"> d-m-Y </option>
                                    <option value="m-d-Y"> m-d-Y </option>
                                    <option value="Y-m-d"> Y-m-d </option>
                                    <option value="d/m/Y"> d/m/Y </option>
                                    <option value="m/d/Y"> m/d/Y </option>
                                    <option value="Y/m/d"> Y/m/d </option>
                                </select>
                            </div>
                         </div>
 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="modules"><?php echo $this->lang->line('lbl_module') ?><?php echo MEND_SIGN; ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select modules select2" name="modules" id="modules" required>
                                    <option>-- Select Holidays --</option>
                                    <option value="d-m-Y"> d-m-Y </option>
                                    <option value="m-d-Y"> m-d-Y </option>
                                    <option value="Y-m-d"> Y-m-d </option>
                                    <option value="d/m/Y"> d/m/Y </option>
                                    <option value="m/d/Y"> m/d/Y </option>
                                    <option value="Y/m/d"> Y/m/d </option>
                                </select>
                            </div>
                         </div>

                         <div class="form-actions">
 
                             <div class="row">
 
                                 <div class="col-lg-6 text-right">
 
                                     <button type="submit" class="btn btn-primary" id="btn-submit-dev"><?php echo $this->lang->line('lbl_submit'); ?></button>
 
                                     <a href="javascript:back_portlet()" class="btn btn-danger btn-edit"><?php echo $this->lang->line('lbl_cancel'); ?></a>
 
                                 </div>
 
                             </div>
 
                         </div>
 
 
 
                     </form>
 
 
             <!-- /basic layout -->
 
         </div>
 
     </div>
 
     <!-- /vertical form options -->
 
 </div>
<script>
    $(document).ready(function () {
        $(".select2").select2();
    });
 </script>