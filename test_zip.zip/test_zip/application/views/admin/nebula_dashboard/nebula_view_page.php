<div class="page-header page-header-light">
  <div class="page-header-content header-elements-md-inline">
    <div class="page-title d-flex">
      <h4>
        <?php echo $headTitle; ?>
      </h4>
    </div>
  </div>
  <div class="bradcrumb-sec">
    <?php echo $bradcrumb; ?>
  </div>
</div>

<!-- include summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote.min.js"></script>


<div class="px-2 log_view_div">
  <div class="d-flex w-100">
    <div class="col-lg-8">
      <div class="header">
        <div class="ticket-log">
          <div class="d-flex align-items-center justify-between w-100 mb-2 nebula-view-page-div">
            <?php if($ticket_details['data']['purpose'] == 'BUG'){
                  $span_color = "text-danger";
              } elseif($ticket_details['data']['purpose'] == 'TRAINING'){
                $span_color = "text-info";
              } elseif($ticket_details['data']['purpose'] == 'FEATURE'){
                $span_color = "text-success";
              }elseif($ticket_details['data']['purpose'] == 'TASK'){
                $span_color = "text-warning";
              }
            ?>

                  <!-- 
                    <?php if(in_array($CurrentLoggedInUserType, ['SW_ADMIN', 'SW_QA'])){?>
                      <span class="change-priority-title ml-2 mr-1">
                          <b><?= $ticket_details['data']['priority'] ?></b>
                      </span>
                      <select id="priority-dropdown" class="ml-2 badge" style="display:none;">
                        <option value="high" style="background-color:#f93f31d1;" data-color="#f93f31d1" <?php echo (strtolower($ticket_details['data']['priority']) == 'high' ? 'selected' : '') ?>  >High</option>
                        <option value="normal" style="background-color:#ffa68a;" data-color="#ffa68a" <?php echo (strtolower($ticket_details['data']['priority']) == 'normal' ? 'selected' : '') ?> >Normal</option>
                        <option value="low" style="background-color:#ffbf37a6;" data-color="#ffbf37a6" <?php echo (strtolower($ticket_details['data']['priority']) == 'low' ? 'selected' : '') ?> >Low</option>
                      </select>
                    <?php } ?> -->

            <h2 class="w-100 mb-0"><span class="<?= $span_color ?> "> <!-- ticket-purpose-type -->
              <?= strtoupper($ticket_details['data']['purpose']) ?>
              </span>

              <!-- <?php if(in_array($CurrentLoggedInUserType, ['SW_ADMIN', 'SW_QA'])){?>

                <select id="ticket-purpose-dropdown" class="ml-2 badge" style="display:none;">
                  <option value="report_bug" style="background-color:#f93f31d1;" data-color="#f93f31d1" <?php echo ($ticket_details['data']['purpose'] == 'BUG' ? 'selected' : '') ?>  >BUG</option>
                  <option value="feature_request" style="background-color:#ffa68a;" data-color="#ffa68a" <?php echo ($ticket_details['data']['purpose'] == 'TRAINING' ? 'selected' : '') ?> >TRAINING</option>
                  <option value="training" style="background-color:#ffbf37a6;" data-color="#ffbf37a6" <?php echo ($ticket_details['data']['purpose'] == 'FEATURE' ? 'selected' : '') ?> >FEATURE</option>
                </select>

              <?php } ?> -->
              
              
              - <span class="page-ticket_id">
                <?= $view_id ?>
              </span> | <input type="text" class="bug-information-title" value="<?= $ticket_details['data']['title'] ?>"  maxlength="200"> </h2>
            <div class="ml-auto d-flex">
              <div class="dropdown-container ticket-view-page-status">
                <?php
                  if (preg_match("/_/", $ticket_details['data']['status_type'])) {
                      $status_type = ucwords(str_replace('_', ' ', $ticket_details['data']['status_type']));
                  }else{
                      $status_type = ucwords($ticket_details['data']['status_type']);
                  }
                ?>
                <h6 class="status_type_title"><?= $status_type ?></h6>
                <?php if(in_array($CurrentLoggedInUserType, ['SW_ADMIN', 'SW_QA', 'SW_DEV'])){ ?>

                  <?php if($CurrentLoggedInUserType == 'SW_DEV'){
                    $ticket_details_all_status_types = $ticket_details['data']['developer_all_status_types'];
                  }else{
                    $ticket_details_all_status_types = $ticket_details['data']['all_status_types'];
                  } ?>

                  <select id="view_page_status" style="display:none;">
                    <?php foreach($ticket_details_all_status_types as $k => $v){ ?>
                      <option value="<?= $k ?>" <?= (strtolower($ticket_details['data']['status_type']) == $k ? 'selected' : '') ?> data-view_page_status="<?= $k ?>" ><?= $v ?></option>

                    <?php } ?>

                  </select>
                <?php } ?>
              </div>

                      <?php if(!in_array($CurrentLoggedInUserType, ['SW_ADMIN', 'SW_QA'])){ ?>
                        <?php if($ticket_details['data']['priority'] == 'High'){
                                $span_priority_color = "badge bg-danger";
                              }elseif($ticket_details['data']['priority'] == 'Normal'){
                                $span_priority_color = "badge bg-warning";
                              } elseif($ticket_details['data']['priority'] == 'Low'){
                                $span_priority_color = "badge bg-info";
                              }
                        ?>
                        <span class="change-priority-dropdown">
                          <span class="ml-2 <?= $span_priority_color ?>">
                            <?= $ticket_details['data']['priority'] ?>
                          </span>
                        </span>
                    <?php } ?>
              
                    <?php if(in_array($CurrentLoggedInUserType, ['SW_ADMIN', 'SW_QA'])){?>
                      
                      <span class="change-priority-title ml-2 mr-1">
                          <b><?= $ticket_details['data']['priority'] ?></b>
                      </span>

                      <select id="priority-dropdown" class="ml-2 badge" style="display:none;">

                      <?php 

                        foreach($priorityOptions as $ppkey => $ppvalue){ 
                          ?>
                          <option value="<?=$ppkey?>" style="background-color:<?= $nebula_priority_colorcode[$ppkey] ?>;" data-color="<?= $nebula_priority_colorcode[$ppkey] ?>" <?php echo (strtolower($ticket_details['data']['priority']) == $ppkey ? 'selected' : '') ?>  ><?= $ppvalue ?></option>
                          <?php
                        }
                      
                      ?>
                      </select>

                                  <?php /*
                                  <select id="priority-dropdown" class="ml-2 badge" style="display:none;">
                                    <option value="high" style="background-color:#f93f31d1;" data-color="#f93f31d1" <?php echo (strtolower($ticket_details['data']['priority']) == 'high' ? 'selected' : '') ?>  >High</option>
                                    <option value="normal" style="background-color:#ffa68a;" data-color="#ffa68a" <?php echo (strtolower($ticket_details['data']['priority']) == 'normal' ? 'selected' : '') ?> >Normal</option>
                                    <option value="low" style="background-color:#ffbf37a6;" data-color="#ffbf37a6" <?php echo (strtolower($ticket_details['data']['priority']) == 'low' ? 'selected' : '') ?> >Low</option>
                      </select> */?>
                                  
                    <?php } ?>
              

            </div>

          </div>
          <div class="row">
              <div class="col-lg-2"><strong>Ticket Created By: </strong><br>
                <?= $ticket_details['data']['created_by'] ?>
              </div>
              <div class="col-lg-3"><strong>Ticket Created At: </strong><br>
                <?= $ticket_details['data']['created_at'] ?>
              </div>
              <div class="col-lg-3"><strong>Last Updated At: </strong><br>
                <?= $ticket_details['data']['updated_at'] ?>
              </div>
              <div class="col-lg-2"><strong>Expected Closing At: </strong><br>
                
              </div>
              <?php $progress_bar_col_class = 'col-lg-1'; ?>
              <?php if(!empty($ticket_details['data']['re_open_at'])){ ?>
                <div class="col-lg-2"><strong>Re-open At: </strong><br>
                  <?php 
                      echo $ticket_details['data']['re_open_at'];
                      $progress_bar_col_class = 'col-lg-2';
                  ?>
                </div>
              <?php } ?>

              <div class="<?= $progress_bar_col_class ?>">
                <div class="d-flex flex-column nebula-view-ticket-progress-bar">
                  <!-- <span><strong>Progress Bar</strong></span> -->
                    <div class="progress-bar" style="height : 20px">
                      <div id="progress_bar_value" style="width: <?= $ticket_details['data']['progress_bar'] ?>%; background-color:#90ee90; height:20px; color:black; text-align:left;">
                        <?= $ticket_details['data']['progress_bar'] ?>
                      </div>
                    </div>
                  <?php if(in_array($CurrentLoggedInUserType, ['SW_ADMIN', 'SW_QA', 'SW_DEV'])){ ?>
                    <input type="number" step="1" name="progress_bar"
                      value="<?php echo $ticket_details['data']['progress_bar']?>" min="0" max="100" class="progress_bar_input"
                      style="display:none;">
                  <?php } ?>
                </div>
              </div>
             
            
              <div class="col-lg-2 mt-2"><strong>Module: </strong><br>
                <?= $ticket_details['data']['orion_department'] ?>
              </div>
              <div class="col-lg-7 mt-2"><strong>Category: </strong><br>
                <?= $ticket_details['data']['orion_module'] ?>
              </div>
              <div class="col-lg-2 mt-2"></div>
              <div class="col-lg-2 mt-2"><strong>User's IP Address: </strong><br>
                <?= $ticket_details['data']['user_ip_address'] ?>
              </div>

                <?php
                      if(empty($ticket_details['data']['ticket_page_URL'])){
                          $ticket_page_URL = 'Not Available';
                      } else {
                        $ticket_page_URL = '<a href="' . $ticket_details['data']['ticket_page_URL'] . '" target="_blank" style="word-break: break-all;">' . $ticket_details['data']['ticket_page_URL'] . '</a>';
                      }
                ?>
              <div class="col-lg-9 mt-2"><strong>Originated Link: </strong><br>
                <?= $ticket_page_URL ?>
              </div>
          </div>

        </div>
      </div>

     
     

        <div class="details">
          <div class="notes-box mt-2 w-100 description-box-ckedidor">
            <form class="form-horizontal" name="nebula_desc_update" id="nebula_desc_update" method="post" action="javascript:void(0)" enctype="multipart/form-data" >
              <h2 id="change-description" style="cursor: pointer;" data-flag="open">DESCRIPTION</h2>
              <!-- Add the 'description-text' ID to the paragraph to target it correctly -->
              <div class="show-description info-row">
                  <p id="description-text-show"><?= $ticket_details['data']['notes'] ?></p>  
                  <p id="description-text" style="display:none;"><?= htmlspecialchars($ticket_details['data']['notes']) ?></p>
              </div>

              <button class="hide-show-text btn btn-primary">Update</button>
              
              <!-- Hidden textarea for editing the description -->
              <div class="add-description form-group mt-0" style="display:none;" id="add-description">
                <!-- <label>Description</label> -->
                <textarea rows="3" name="content" id="notesto" style="height: 120px; resize: none; overflow-y: auto;"></textarea>
                <span id="charCount" class="float-right">Characters: 6000/6000</span>
              </div>
            </form>
            
            <!-- <h2>ATTACHMENTS</h2> -->
            <div class="row-modal-data">
              <?php echo $ticket_details['data']['uploaded_file']; ?>
            </div>
          </div>

       </div>

                      
      <!-- </div> -->
      <div class="row mt-2 align-items-stretch">
        <div class="col-lg-12">
          <div class="notes-box h-100 nebula-ticket-attached-file">
            <h2>COMMENTS</h2>
            <!-- <div style="max-height: 88px;overflow: auto;" id="comment_box_scroll_tab_content"> -->
              <div class="nebula-comment-updated">
                <?php echo $ticket_details['data']['comments_log']; ?>
              </div>  
            <!-- </div> -->
            
              <?php //echo $ticket_details['data']['comments_log']; ?>
           
            <button type="submit" class="btn btn-primary" data-ticket_id="<?= $view_id ?>" id="btn-submit-nebula-comments" style="float: right;margin-top:8px;">Save</button>
            <div class="" style="margin-top:4rem;">
              <form class="form-horizontal" name="nebulaCommnetSave" id="nebulaCommnetSave" method="post" action="javascript:void(0)" enctype="multipart/form-data">
                <div class="row mt-3">
                  <div class="col-lg-12">
                    <textarea name="nebula_view_page_comments" class="nebula_view_page_comments" id="nebula_view_page_comments"></textarea>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>
    <div class="col-lg-4">
      <div class="header">

        <div class="ticket-log">
          <div class="mb-2 d-flex align-items-center w-100">
            <div><strong>Assigned To: </strong><br/>
              
                <?= $ticket_details['data']['assign_to'] ?>
              
            </div>
          </div>
          <div class="mb-2 d-flex align-items-center w-100 flex-wrap ticket-page-tags">
            <label for="tagList" class="add_lbl_tag">Tags :</label>
            <input type="text" id="newTag" style="width:300px;display: none;" />
            <div class="tagList">
              <?php
                $ticket_tags = [];
                if (!empty($ticket_details['data']['ticket_tags'])) {
                  $ticket_tags = explode(',', $ticket_details['data']['ticket_tags']);
                  foreach ($ticket_tags as $tag) { ?>
                      <small>
                          <span class="badge badge-dark mr-1 mb-1">
                              <?= htmlspecialchars($tag) ?>
                              <span class="rmTag" style="cursor: pointer; color: red;">&times;</span>
                          </span>
                      </small>
              <?php } } ?>
            </div>
          </div>
          
        </div>
      </div>
      <ul class="nav nav-tabs nebula-viewpage-tabs">
        <li class="nav-item">
          <a class="nav-link active" data-toggle="tab" href="#home">Activity</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#attachments_list">Attachments</a>
        </li>
      </ul>

      <?php //echo pre($ticket_details['data']['activity_users_list']); ?>
      
      <!-- Tab panes -->
      <div class="tab-content">

        
          

          <!-- START - Created activity -->
            <div class="tab-pane active" id="home">
              <!-- START - User wise activity count -->
              <div class="acticity-users-list mb-1" style="position:relative">
                <ul class="nav nav-tabs note-tab mb-0 checkbox_tabs" role="tablist" style="display: flex !important;">
                  <?php foreach($ticket_details['data']['activity_users_list'] as $user_k => $user_v){ ?>
                    <li class="nav-item mr-2 d-flex align-items-center" style="border: 1px solid #ddd; padding: 3px; border-radius: 8px;"> 
                      <input checked="checked" class="activity-user-checkbox mr-2" type="checkbox" value="<?= $user_k ?>">
                      <b style="font-size: 11px;font-weight: 400;margin-right: 10px"><?php echo ucwords(str_replace('_', ' ', $user_k)); ?></b>
                      <span class="badge badge-info"><?= $user_v ?></span>
                    </li>
                  <?php } ?>
                </ul>
              </div>
              <!-- END - User wise activity count -->
              <div  style="max-height: 457px;overflow: auto;" id="scroll_tab_content">
                <!-- <h3 class="viewpage-tabs-activity-title">
                  <?= $ticket_details['data']['formatted_date_heading'] ?>
                </h3> -->
                <!-- START - Updated activity -->
                <div class="activity_string_tab">

                </div>
                <!-- END - Updated activity -->
                <div class="viewpage-activity-comment-tab ticket-activity-created-log">
                  <div class="viewpage-activity-profile">
                    <div class="viewpage-activity-profile-img"><img
                      src="<?php echo base_url(ADM_THEME_COMMON_NEBULA_IMG) ?>profile_pic.jpg" alt="">
                    </div>
                    <div class="viewpage-activity-profile-title user-text-color">
                      <?= $ticket_details['data']['created_by'] ?><small><span class="badge bg-dark badge-pill ml-2 mr-1"><?= $ticket_details['data']['created_by_type'] ?></span></small>
                      <span> <?= timeago_project_notes($ticket_details['data']['formatted_date']) ?> </span>
                      <span class="ml-auto">Created on <?= $ticket_details['data']['formatted_date'] ?>
                      </span>
                    </div>
                  </div>
                  <!-- <div class="activity-created-log">

                  </div> -->
                </div>
              </div>
            </div>
          <!-- END - Created activity -->

          <!-- START - Attachments Tab -->
            <div class="tab-pane row-modal-data" id="attachments_list"><?php echo $ticket_details['data']['uploaded_file']; ?></div>
          <!-- END - Attachments Tab -->
      </div>



    </div>
  </div>

</div>

</div>

</div>

<!-- Light Box Code Start -->
<div id="myModal" class="light-modal-cls">
  <span class="close-light-box cursor-light-box" onclick="closeModal()">&times;</span>
  <div class="light-box-modal-content">

<?php 
    if (!empty($ticket_details['data']['uploaded_file_path'])) {
      $imageNo = 1;
      $modalImageCount = count($ticket_details['data']['uploaded_file_path']);
      foreach ($ticket_details['data']['uploaded_file_path'] as $imageKey => $imageValue) {
?>        
    <div class="mySlides-light-box">
      <div class="numbertext-light-box"> <?= $imageNo; ?>/ <?= $modalImageCount; ?></div>
      <img src="<?= $imageValue; ?>" style="width:100%">
    </div>
<?php
      $imageNo++;
    }
  } 
?>
    
    <a class="prev-light-box" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next-light-box" onclick="plusSlides(1)">&#10095;</a>

    <div class="caption-container">
      <p id="caption"></p>
    </div>

<?php 
  if (!empty($ticket_details['data']['uploaded_file_path'])) {
    $imageNum = 1;
    $modalImageCount = count($ticket_details['data']['uploaded_file_path']);
    foreach ($ticket_details['data']['uploaded_file_path'] as $imageKey => $imageValue) {
?>
    <div class="column-modal-data">
      <img class="demo-light cursor-light-box" src="<?= $imageValue; ?>" style="width:100%" onclick="currentSlide(<?= $imageNum ?>)">
    </div>
    
<?php
      $imageNum++;
    }
  }
?>
  </div>
</div>
<!-- Light Box Code End -->

<!-- <div class="nebula-footer">Footer</div> -->
<div class="nebula-footer text-left"><?= $todays_ticket_count ?></div>
<style>

  .acticity-users-list ,.checkbox_tabs, .pb-3, .py-3 {
      padding-bottom: 0.80rem!important;
  }

  .show-description.info-row {
      max-height: 301px;
      overflow: auto;
  }

  /*------------------------------------------------------- START - Comment Area ------------------------------------------------------------*/
  .comment-text-box {
    width: calc(100% - 71px);
  }
  .line-date {
    text-align: center;
    position: relative;
    z-index: 9;
    font-size: 14px;
  }
  .line-date:before {
      content: "";
      width: 100%;
      background-color: #cccccc;
      height: 1px;
      display: block;
      position: relative;
      top: 11px;
      z-index: -2;
  }
  .line-date span {
      background-color: #f7f8fa;
      padding: 0 12px;
  }
  .comment-box {
      display: flex;
      align-items: flex-start;
      width: 100%;
  }
  .comment-profile {
      width: 25px;
      height: 25px;
      border: 1px solid #ddd;
      border-radius: 50%;
      overflow: hidden;
      margin-right: 10px;
  }
  .comment-profile img {
      width: 100%;
  }
  .commente-name {
      font-weight: 600;
      /* font-size: 15px; */
      font-size: .8125rem;
      color: #175a8e;
  }
  .commente-name:hover {
    color: #175a8e;
    text-decoration: underline;
  }
  .commente-name span {
      font-weight: 300;
      font-size: 11px;
      margin-left: 15px;
      color: #6a6a6a;
      float: right;
      text-align: right;

  }
  .commente-comment {
      margin-top: 5px;
      font-size: 14px;
      color: #333;
  }
  /*------------------------------------------------------- END - Comment Area ------------------------------------------------------------*/

  /*------------------------------------------------------- START - Activity User ------------------------------------------------------------*/
  /* .user-text-color:hover, .user-text-color:active {
        color: #175a8e;
        text-decoration: underline;
    } */
  /*------------------------------------------------------- END - Activity User ------------------------------------------------------------*/
  .nebula-footer {
    background-color: #f7f8fa;
    padding: 10px 20px;
    position: fixed;
    bottom: 0;
    width: 100%;
    border-top: 1px solid #ddd;
  }

  #priority-dropdown {
    /* position: absolute;
    top: 0;
    right: 0;
    margin-top: 10px;
    margin-left: 100px; */
  }

  /*-------------------------------------------------------START ADD REMOVE TAG CSS ------------------------------------------------------------*/
    .ticket-page-tags .tagList {
      list-style: none;
      padding: 0 0 0;
      margin: 8px 0 0;
      width: 100%;
    }
    .ticket-page-tags .tagList li {
        background-color: #141414;
        color: #fff;
        padding: 2px 7px;
        border-radius: 15px;
        margin-right: 5px;
        margin-bottom: 3px;
    }
  /*-------------------------------------------------------END ADD REMOVE TAG CSS ------------------------------------------------------------*/

  .viewpage-activity-comment-tab li {
    margin-top: 10px;
    /* padding-left: 34px; */
    font-size: 15px;
  }

  .viewpage-activity-profile {
    display: flex;
    align-items: center;
  }

  .viewpage-activity-profile-img {
    width: 25px;
    height: 25px;
    border: 1px solid #ddd;
    border-radius: 50%;
    overflow: hidden;
  }

  .viewpage-activity-profile-img img {
    width: 100%;
  }

  .viewpage-activity-comment-tab {
    margin-bottom: 15px;
  }
 
  .viewpage-activity-profile-title {
    margin-left: 10px;
    font-size: .8125rem;
    font-weight: 500;
    color: #175a8e;
    /* text-decoration: underline; */
    display: flex;
    align-items: center;
    width: 100%;
  }

  .viewpage-activity-profile-title:hover {
    color: #175a8e;
    text-decoration: underline;
  }

  .viewpage-activity-profile-title span {
    display: block;
    font-size: 11px;
    font-weight: 300;
    color: #333;
  }

  h3.viewpage-tabs-activity-title {
    font-size: 16px;
    border-bottom: 1px solid #afafaf;
  }

  .nav-tabs.nebula-viewpage-tabs .nav-item.show .nav-link,
  .nav-tabs.nebula-viewpage-tabs .nav-link.active {
    border-bottom: 2px solid #333;
    border-top: 0;
    border-left: 0;
    border-right: 0;
  }

  .tag-input-container {

    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;

  }

  input.bug-information-title {
    width: 78%;
    border: none;
  }

  #tag-input {
    width: 100%;
    padding: 8px;
    border: none;
    outline: none;
    margin-bottom: 10px;
    border: 1px solid #ddd;
  }

  #tags-list {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    max-height: 75px;
    overflow: auto;
  }

  .tag {
    /* background-color: #1e72c8;
    color: #fff;
    padding: 3px 10px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    font-size: 12px;
    cursor: default;
    transition: background-color 0.3s ease; */
    display: inline-block;
    background-color: #faea0c;
    padding: 0 .4em .15em;
    border-radius: .25rem;
    margin-bottom: 0.4em;
  }

  .tag:hover {
    background-color: #e0e0e0;
  }

  .remove-tag {
    margin-left: 8px;
    cursor: pointer;
    font-size: 14px;
    color: #fff;
    font-weight: bold;
    transition: color 0.3s ease;
  }

  .remove-tag:hover {
    color: #ff5c5c;
  }

  span.attachment-icon {
    background-color: #f1f1f1;
    text-align: center;
    padding: 3px 7px;
    color: #333 !important;
    font-size: 13px !important;
    border-radius: 3px;
    border: 1px solid #ddd;
  }

  .badge {
    font-size: 90% !important;
  }

  .comment-logs {
    padding: 10px 10px;
    height: calc(100vh - 397px);
    overflow: auto;
  }

  /* .tickit-dropdown {
    border: 1px solid #ddd;
    padding: 3px 10px;
    margin-left: 10px;
    background-color: #f1f1f1;
    color: #616161;
  } */

  .comment-logs ul li {
    display: flex;
    margin-bottom: 20px;
  }

  .profile-img {
    width: 20px;
    height: 20px;
    border: 1px solid #ddd;
    border-radius: 50%;
    display: inline-block;
    overflow: hidden;
    margin-right: 10px;
  }

  .title-comment {
    color: #575757;
  }

  .profile-img img {
    height: 100%;
  }

  .commentert-comment {
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.3);
    padding: 9px;
    border-radius: 10px;
    margin-top: 10px;
  }

  .title-comment span:before {
    content: "\f017";
    font: normal normal normal 14px / 1 FontAwesome;
    padding-right: 6px;
    margin-left: 10px;
    color: #004aff;
  }

  .comment-logs ul {
    list-style: none;
    padding: 0;
  }

  .activity-box {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px;
    width: 100%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
  }

  .nebula-comment {
    height: calc(100vh - 192px);
    overflow: auto;
  }

  .activity-box textarea {
    border: none;
    resize: none;
    width: 100%;
    height: 50px;
    padding: 10px;
    font-size: 16px;
    outline: none;
  }

  .attachment-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 10px;
  }

  .attachment {
    display: flex;
    align-items: center;
    background: #f1f1f1;
    border: 1px solid #ddd;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 14px;
  }

  .attachment img {
    width: 20px;
    height: 20px;
    margin-right: 5px;
  }

  .attachment button {
    border: none;
    background: none;
    color: #888;
    font-size: 16px;
    cursor: pointer;
  }

  .attachment button:hover {
    color: #000;
  }

  .actions {
    display: flex;
    align-items: center;
    margin-top: 10px;
  }

  .actions .publish-button {
    background: #007bff;
    color: #fff;
    border: none;
    padding: 4px 8px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
  }

  .actions .publish-button:hover {
    background: #0056b3;
  }

  .actions .attachment-icon {
    cursor: pointer;
    color: #007bff;
    font-size: 18px;
  }

  .actions .attachment-icon:hover {
    color: #0056b3;
  }

  .ticket-log h1.w-100 {
    font-weight: 500;
  }

  .ticket-log {
    border: 1px solid #ddd;
    box-shadow: 0 0 2px rgba(0, 0, 0, 0.3);
    padding: 10px;
    width: 100%;
    display: flex;
    flex-wrap: wrap;
  }

  .ticket-log p {
    width: 21%;
    color: #4e4e4e;
  }

  .ticket-log p strong {
    display: block;
    font-weight: 500;
    color: #000;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 20px;
  }

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
  }

  .header h2 {
    margin: 0;
    font-size: 1.5em;
  }

  .progress {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .progress-bar {
    width: 100px;
    height: 6px;
    background-color: #e0e0e0;
    border-radius: 3px;
    position: relative;
    overflow: hidden;
  }

  .progress-bar span {
    display: block;
    height: 100%;
    width: 15%;
    /* Adjust to reflect progress percentage */
    background-color: #007bff;
  }

  .details-box,
  .notes-box {

    background-color: #f7f8fa;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 15px;
  }

  .details-box h3,
  .notes-box h3 {
    margin-top: 0;
    font-size: 1.1em;
    color: #555;
  }

  .details-box ul,
  .notes-box ol {
    margin: 0;
    padding-left: 18px;
  }

  .details-box li,
  .notes-box li {
    font-size: 0.9em;
    margin-bottom: 5px;
  }

  .info-row {
    margin-bottom: 10px;
  }

  .info-row span {
    display: block;
    font-size: 0.9em;
    color: #555;
  }

  .info-row strong {
    font-size: 1em;
    color: #333;
  }

  .progress-box {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 15px;
    margin-top: 20px;
  }

  .progress-box h3 {
    margin: 0 0 10px 0;
    font-size: 1.1em;
    color: #555;
  }

  .progress-box ul {
    padding-left: 18px;
  }

  .progress-box li {
    font-size: 0.9em;
  }

  /*---------------change view_page_status------------------------*/
  .dropdown-container {
    position: relative;
    width: 143px;
  }

  .dropdown-container select {
    width: 100%;
    padding: 3px 10px;
    font-size: 13px;
    color: #333;
    background-color: #f1f1f1;
    border: 1px solid #ddd;
    border-radius: 3px;
    appearance: none;
    outline: none;
    cursor: pointer;
    transition: all 0.3s ease;
  }

  /* select:focus {
            border-color: #007BFF;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
            background-color: #e6f7ff; /* Light blue background on focus 
        } 
        */

  .dropdown-container::before {
    content: "▼";
    position: absolute;
    right: 7px;
    top: 6px;
    font-size: 11px;
    color: #888;
    pointer-events: none;
    transition: all 0.3s ease;
  }

  /* .dropdown-container select:focus + .dropdown-container::before {
      color: #007BFF;
  } */

  /* Option background colors, without changing on select */
  .dropdown-container option[data-view_page_status="active"] {
    background-color: #d4edda;
    /* Light green for active */
    color: #155724;
    /* Dark green text */
  }

  .dropdown-container option[data-view_page_status="inactive"] {
    background-color: #f8d7da;
    /* Light red for inactive */
    color: #721c24;
    /* Dark red text */
  }

  .dropdown-container option[data-view_page_status="pending"] {
    background-color: #fff3cd;
    /* Light yellow for pending */
    color: #856404;
    /* Dark yellow text */
  }

  /* Hover effect on options */
  .dropdown-container option[data-view_page_status="active"]:hover {
    background-color: #28a745;
    color: white;
  }

  .dropdown-container option[data-view_page_status="inactive"]:hover {
    background-color: #dc3545;
    color: white;
  }

  .dropdown-container option[data-view_page_status="pending"]:hover {
    background-color: #ffc107;
    color: white;
  }

  /* .dropdown-container::before {
          display: none;
      } */
  /* Optional: Hide the dropdown arrow on mobile */
  @media (max-width: 600px) {}

  .dropdown-container select option {
    color: #333;
    background-color: #fff;
  }

  .daterangepicker-body {
      display: inline-block;
      background: #fff;
      padding: 15px;
      border-radius: 3px;
  }
  /* .ck.ck-reset.ck-editor.ck-rounded-corners {
    display: none;
  } */
  .add-description .ck.ck-reset.ck-editor.ck-rounded-corners:last-of-type {
      display: block;
  }
  button.hide-show-text {
      position: absolute;
      z-index: 9;
      right: 16px;
      margin-top: 1px;
      padding: 8px;
  }
  .details-box, .notes-box{
    position: relative;
  }


  /*Light Box Code START */
  .row-modal-data > .column-modal-data {
    padding: 0 8px;
  }

  .row-modal-data:after {
    content: "";
    display: table;
    clear: both;
  }

  .column-modal-data {
    float: left;
    width: 120px;
    overflow: hidden;
    cursor: pointer;
    border: 1px solid #bfbfbf;
    margin-right: 10px;
    box-shadow: 0 0 2px rgba(0,0,0,0.3);
}

.not-column-modal-data {
  float: left;
  width: 120px;
  overflow: hidden;
  border: 1px solid #bfbfbf;
  margin-right: 10px;
  box-shadow: 0 0 2px rgba(0,0,0,0.3);
}
.column-modal-data img {
    overflow: hidden;
    object-fit: scale-down;
}
.row-modal-data ul {
    padding: 0;
}

  /* The Modal (background) */
  .light-modal-cls {
    display: none;
    position: fixed;
    z-index: 1;
    padding-top: 100px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.8);
  }

  /* Modal Content */
  .light-box-modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    /* width: 40%; */
    height: 60%;
    max-width: 1200px;
  }

  /* The Close Button */
  .close-light-box {
    color: white;
    position: absolute;
    top: 33px;
    right: 25px;
    font-size: 35px;
    font-weight: bold;
  }

  .close-light-box:hover,
  .close-light-box:focus {
    color: #999;
    text-decoration: none;
    cursor: pointer;
  }

  .mySlides-light-box {
    display: none;
  }

  .cursor-light-box {
    cursor: pointer;
  }

  /* Next & previous buttons */
  .prev-light-box,
  .next-light-box {
    cursor: pointer;
    position: absolute;
    top: 50%;
    width: auto;
    padding: 16px;
    margin-top: -50px;
    color: white;
    font-weight: bold;
    font-size: 20px;
    transition: 0.6s ease;
    border-radius: 0 3px 3px 0;
    user-select: none;
    -webkit-user-select: none;
  }

  /* Position the "next button" to the right */
  .next-light-box {
    right: 0;
    border-radius: 3px 0 0 3px;
  }

  /* On hover, add a black background color with a little bit see-through */
  .prev-light-box:hover,
  .next-light-box:hover {
    background-color: rgba(0, 0, 0, 0.8);
  }

  /* Number text (1/3 etc) */
  .numbertext-light-box {
    color: #f2f2f2;
    font-size: 12px;
    padding: 8px 12px;
    position: absolute;
    top: 0;
  }

  img {
    margin-bottom: -4px;
  }

  .caption-container {
    text-align: center;
    background-color: black;
    padding: 2px 16px;
    color: white;
  }

  .demo-light {
    opacity: 0.6;
  }

  .active-light-box,
  .demo-light:hover {
    opacity: 1;
  }

  img.hover-shadow-light {
    transition: 0.3s;
  }

  .hover-shadow-light:hover {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }

  /*Light Box Code END */
</style>




<script>

  $(document).ready(function () {

    const ticket_id = $('.page-ticket_id').text().trim();

    var change_view_page_data = "";
    
    var updated_activity_string = '<?php echo addslashes(json_decode($ticket_details["data"]["activity_log"]))?>';
    
    //  console.log("activity is " + updated_activity_string);return;
    
    $('#scroll_tab_content .activity_string_tab').html(updated_activity_string);

    // var ticket_created_activity_log = '<?php echo json_decode($ticket_details["data"]["activity_ticket_created_log"])?>';
    // $('.ticket-activity-created-log .activity-created-log').html(ticket_created_activity_log);

    /*-------------------------------------------- START - Activity Users Filter --------------------------------------------*/
    
      $('.checkbox_tabs .activity-user-checkbox').on('change', function() {
        var activity_user_value = $(this).val(); // Get the user key (value of checkbox)
        
        var checked_users = [];
        var unchecked_users = [];

        // Loop through all checkboxes to separate checked and unchecked users
        $('.activity-user-checkbox').each(function() {
            var user_value = $(this).val(); // Get the user key (value of checkbox)
            
            if ($(this).prop('checked')) {
                checked_users.push(user_value); // Add to checked users
            } else {
                unchecked_users.push(user_value); // Add to unchecked users
            }
        });

        // Prepare the data to be sent
        var change_view_page_data = {
            ticket_id: ticket_id,
            checked_users: checked_users, // List of checked users
            unchecked_users: unchecked_users, // List of unchecked users
            activity_filter : 'activity_filter',
        };

        view_page_data_change(change_view_page_data);

      });
    
    /*-------------------------------------------- END - Activity Users Filter --------------------------------------------*/


    /*-------------------------------------------- START - Description Update --------------------------------------------*/
      let editorInstance;  
      var currentDescription = '';
      const maxChars = 6000;
      const charCountElement = document.getElementById('charCount');
      
      var SelectedUser = $('#view_page_status').val();
      var status_type = $('.status_type_title').text().trim();
      var updatedDescription = '';
      if( status_type == 'Open' || SelectedUser == 'open')
      { 
        $(document).on('click', '#change-description', function()  {

              var ticktStatus = $(".ticket-view-page-status #view_page_status").val();
              if(ticktStatus!=undefined && ticktStatus!="open"){
                return false;
              }


              var dec_status = $(this).attr("data-flag");
              
              if(dec_status=="open"){
                $(".hide-show-text").show();
                $('.show-description').css('display', 'none');
                $('.add-description').css('display', 'block');

                if($('#description-text').length>0){
                  currentDescription = $('#description-text').text().trim();  
                }
               
                // if (!editorInstance) {
                //   editorInstance = nebula_ckeditor("notesto",currentDescription);
                // }

                if($('#add-description .ck-editor').length==0){
                  editorInstance= nebula_ckeditor("notesto",currentDescription);
                }

                $('#add-description').css('display', 'block'); 

            

                $(this).attr("data-flag","hide");

              }else{

                $(".hide-show-text").hide();
                $('.show-description').css('display', 'block');
                $('.add-description').css('display', 'none');
                $('#add-description').css('display', 'none'); 

                $(this).attr("data-flag","open");

              }
          });
      }
      function updateDescription() 
      { 
          updatedDescription = editorInstance.getData(); 
          // currentDescription = editorInstance.getData();
          if(currentDescription != updatedDescription){ 
           
            change_view_page_data = {
              ticket_id: ticket_id,
              updatedDescription: updatedDescription,  
            };
            currentDescription = updatedDescription; 
            view_page_data_change(change_view_page_data);
            return true;
          }
          return false;
      }
      $(".hide-show-text").hide();
      

      function updateDescriptionABC(){

        var desc = $(".add-description  .ck-blurred").text();

        change_view_page_data = {
          ticket_id: ticket_id,
          updatedDescription: desc,  
        };

        view_page_data_change(change_view_page_data);

        $('.show-description').html(desc);  
        $(".hide-show-text").css('display', 'none'); 
        $('#add-description').css('display', 'none'); 
        $('.show-description').css('display', 'block'); 
      }

      $(document).on('submit', '#nebula_desc_update', function(e)  {
        e.stopImmediatePropagation();

        updateDescriptionABC();

        

      });


      $(document).on('click', '.hide-show-text1', function(e)  {
          e.stopImmediatePropagation();
          if (!$(this).closest('.details #add-description').length) {
               

                if (!editorInstance) {                
                  const prevDescription = $('#description-text').text().trim();
                  editorInstance = nebula_ckeditor("notesto", prevDescription);
                }
          
                if (editorInstance) 
                {
                  if(updateDescription()){
                    $('.show-description').html(updatedDescription);  
                    //$(".hide-show-text").css('display', 'none'); 
                  }
                }
                $(".hide-show-text").css('display', 'none'); 
              $('#add-description').css('display', 'none'); 
              $('.show-description').css('display', 'block');
          }
      });

    /*-------------------------------------------- END - Description Update --------------------------------------------*/

    /*-------------------------------------------- START - Nebula Comment Box --------------------------------------------*/
      
      summernote_function('#nebula_view_page_comments');
      // nebula_ckeditor("nebula_view_page_comments");

      $('#btn-submit-nebula-comments').click(function() {

        var comment_ticket_id = $("#btn-submit-nebula-comments").attr("data-ticket_id");

        var new_comments = $('#nebula_view_page_comments').val();
       
        change_view_page_data = {
          ticket_id: comment_ticket_id,
          new_comments: new_comments,  
        };
        // console.log("data is : " + change_view_page_data);

        $.ajax({
          url: ADMIN_URL + 'Nebula_dashboard/updateViewPageComments',
          method: 'POST',
          data: change_view_page_data,
          beforeSend: addOverlay,
          success: function (r) {
        
            var res = JSON.parse(r);
          
            if (res.status == '200') {

              sTitle = '';
              sType = getStatusText(res.status);
              sText = res.message;
              sAddClass = res.addclass;
              Custom.myNotification(sType, sText);
              
              // var activity_log = JSON.parse(res.activity_log);
              // $('#scroll_tab_content .activity_string_tab').html(activity_log);

              // summernote_function('.nebula_view_page_comments');

              // if(res.comments_log){
              //   var comments_log = JSON.stringify(res.comments_log);
              //   console.log("cmtt log : " + comments_log);
              //   // $(".nebula-comment-updated").html('');
              //   // $(".nebula-comment-updated").html(comments_log);
              //   // $('#scroll_tab_content .nebula-comment-updated').html(comments_log);
              // }
              
              location.reload();
              
              var scroll=$('.comment_box_scroll_tab_content');
              scroll.animate({scrollTop: scroll.prop("scrollHeight")});


              
            } else {
              sTitle = '';
              sType = getStatusText(res.status);
              sText = res.message;
              sAddClass = res.addclass;
              Custom.myNotification(sType, sText);
              return false;
            }
          },
          complete: removeOverlay,
          error: function (xhr, status, error) {
            // Handle error
            console.error("Error While Submitting View Page Data", error);
            removeOverlay();  // Remove the loading overlay
          }
        });

      });


    /*-------------------------------------------- END - Nebula Comment Box --------------------------------------------*/


    /*-------------------------------------------- START - Priority --------------------------------------------*/

      $('.change-priority-title').click(function() {
        $('.change-priority-title').css('display', 'none');
        $('#priority-dropdown').css('display', 'block');
        var color = $('#priority-dropdown option:selected').data('color');
        $('#priority-dropdown').css('background-color',color);
      });
      
      var prev_priority = <?php echo $ticket_details['data']['progress_bar']; ?>; 

      $('#priority-dropdown').change(function() { 
        var color = $('#priority-dropdown option:selected').data('color');
        var selected_priority = $('#priority-dropdown option:selected').val();

        if(prev_priority != selected_priority){ // if previous and current value same then not able call ajax
          change_view_page_data = {
            ticket_id: ticket_id,
            selected_priority: selected_priority,  // Only send the integer value
          };
  
          prev_priority = selected_priority; // update prev_priority to new value
          view_page_data_change(change_view_page_data);
        }
        $('#priority-dropdown').css('background-color',color);
      });

    /*-------------------------------------------- END - Priority --------------------------------------------*/

    /*-------------------------------------------- START - Purpose --------------------------------------------*/

      $('.ticket-purpose-type').click(function() {
        $('.ticket-purpose-type').css('display', 'none');
        $('#ticket-purpose-dropdown').css('display', 'block');
        var color = $('#ticket-purpose-dropdown option:selected').data('color');
        $('#ticket-purpose-dropdown').css('background-color',color);
      });

      $('#ticket-purpose-dropdown').change(function() {
        var color = $('#ticket-purpose-dropdown option:selected').data('color');
        var selected_priority = $('#ticket-purpose-dropdown option:selected').val();

        if(prev_priority != selected_priority){ // if previous and current value same then not able call ajax
          change_view_page_data = {
            ticket_id: ticket_id,
            selected_priority: selected_priority,  // Only send the integer value
          };

          prev_priority = selected_priority; // update prev_priority to new value
          // view_page_data_change(change_view_page_data);
        }
        $('#priority-dropdown').css('background-color',color);
      });

    /*-------------------------------------------- START - Purpose --------------------------------------------*/
    
    /*-------------------------------------------- START - Status Type --------------------------------------------*/
    
      const excludedStatuses = ['SW_ADMIN', 'SW_QA'];  // Example array of statuses
      const currentUserType = '<?php echo $CurrentLoggedInUserType?>';
      
      if (currentUserType === 'SW_ADMIN' || currentUserType === 'SW_QA' || currentUserType === 'SW_DEV') {
        $('.status_type_title').click(function () {
          $(this).css("display", "none");
          $('.ticket-view-page-status #view_page_status').css("display", "inline-block");
          const selectElement = document.getElementById('view_page_status');
          const event = new Event('change');  // Create a new 'change' event
          selectElement.dispatchEvent(event);
        });
      }

    /*-------------------------------------------- END - Status Type --------------------------------------------*/


    /*-------------------------------------------- START - Progress Bar --------------------------------------------*/

      // Handle progress bar click to show input field

      var prev_progrss_val = <?php echo $ticket_details['data']['progress_bar']; ?>; 

      if (currentUserType === 'SW_ADMIN' || currentUserType === 'SW_QA' || currentUserType === 'SW_DEV') {
      
        $('.nebula-view-ticket-progress-bar .progress-bar').click(function () {
          $(this).closest('.progress').hide(); // Hide the progress bar
          $('.nebula-view-ticket-progress-bar .progress-bar').css("display", "none");
          $('.nebula-view-ticket-progress-bar .progress_bar_input').show().focus(); // Show and focus the input field
          $('.nebula-view-ticket-progress-bar .progress_bar_input').css("display", "inline-block");
        });

        $('.nebula-view-ticket-progress-bar .progress_bar_input').focusout(function () {
          let progressval = $(this).val();

          // Ensure value is between 0 and 100
          if (progressval < 0) progressval = 0;
          if (progressval > 100) progressval = 100;

          // Round to nearest integer to avoid decimals
          progressval = Math.floor(progressval);  // Use Math.floor to convert to integer (you can also use Math.round())

          $('.nebula-view-ticket-progress-bar .progress-bar').css("display", "inline-block"); // show progress bar 

          // Update progress bar
          $('.progress-bar #progress_bar_value').css('width', progressval + '%');
          $('.progress-bar #progress_bar_value').text(progressval + '%');

          // Show progress bar and hide input field
          $('.nebula-view-ticket-progress-bar .progress_bar_input').show();
          $(this).hide();

          // Optionally send updated progress to the server
          // var ticket_id = $('.page-ticket_id').text();

          if(prev_progrss_val != progressval){ // if previous and current value same then not able call ajax
            change_view_page_data = {
              ticket_id: ticket_id,
              progress_bar: progressval,  // Only send the integer value
            };
    
            prev_progrss_val = progressval; // update prev_progrss_val to new value
            view_page_data_change(change_view_page_data);
          }

        });

      }

    /*-------------------------------------------- END - Progress Bar --------------------------------------------*/

    /*-------------------------------------------- START - Title --------------------------------------------*/

      var prev_title = <?php echo json_encode($ticket_details['data']['title']); ?>;
      
     $('.nebula-view-page-div .bug-information-title').on('focusout', function () {
       
        var title = $(this).val();

        if(prev_title !== title){ // if previous and current value same then not able call ajax
          change_view_page_data = {
            ticket_id: ticket_id,
            title: title,
          };

          prev_title = title // update prev_title to new value
          view_page_data_change(change_view_page_data);
          
        }

      });

    /*-------------------------------------------- END - Title --------------------------------------------*/

    
    /*-------------------------------------------- START - Progress --------------------------------------------*/

      var prev_status_type = <?php echo json_encode($ticket_details['data']['status_type']); ?>;
      
      $(document).on("change", ".ticket-view-page-status #view_page_status", function () {
       
         var status_type = $(this).val();
 
         if(prev_status_type !== status_type){ // if previous and current value same then not able call ajax
          if(status_type == 'closed' || status_type == 'open'){
            prev_progrss_val = (status_type == 'closed') ? 100 : 0;
              
            change_view_page_data = {
              ticket_id: ticket_id,
              status_type: status_type,
              progress_bar: prev_progrss_val,  // Only send the integer value
            };

            // Update progress bar
            $('.progress-bar #progress_bar_value').css('width', prev_progrss_val + '%');
            $('.progress-bar #progress_bar_value').text(prev_progrss_val + '%');

          }else{    
            change_view_page_data = {
              ticket_id: ticket_id,
              status_type: status_type
            };
          }
           prev_status_type = status_type // update prev_title to new value
           view_page_data_change(change_view_page_data);
         }
 
       });
 
    /*-------------------------------------------- END - Progress --------------------------------------------*/
 
    /*-------------------------------------------------------START ADD REMOVE TAG ------------------------------------------------------------*/

      var tagList = <?php echo json_encode($ticket_tags); ?> || []; // Safely fallback to an empty array if the PHP variable is null or undefined
      
      var $tagList = $(".ticket-page-tags .tagList");
      var $newTag = $("#newTag");

      // Initial render
      tagList_render();

      // Render the tag list
      function tagList_render() {
          $tagList.empty();
          if(tagList && Array.isArray(tagList)) {
              tagList.map(function (_tag) {
                  var temp = '<small><span class="badge badge-dark mr-1 mb-1">' + _tag + 
                  '<span class="rmTag ml-1" style="cursor: pointer; color: white;" data-tag_badge="'+_tag+'"> X </span>' + 
                  '</span></small>';
                  $tagList.append(temp);
              });
          }
      }

      // Add a new tag
      function addTag(tag) {
          tag = tag.trim();
          if (tag && !tagList.includes(`#${tag}`)) { // Check if tag is not already in the list
              tagList.push(`#${tag}`);
              tagList_render();

              var change_view_page_data = {
                  ticket_id: ticket_id,
                  tagList: tagList,
              };
              view_page_data_change(change_view_page_data);
          }
      }

      // Handle paste event to add multiple tags
      $newTag.on('paste', function (e) {
          setTimeout(() => {
              var pastedData = $newTag.val().trim();
              if (pastedData) {
                  const tags = pastedData
                      .split(',')
                      .map(tag => `#${tag.trim()}`)
                      .filter(tag => tag !== '#');
                  // Only add unique tags
                  tags.forEach(tag => {
                      if (!tagList.includes(tag)) {
                          tagList.push(tag);
                      }
                  });
                  tagList_render();
                  $newTag.val(''); // Clear input
              }
          }, 0);
      });

      // Handle keydown event to add a tag when Enter or comma is pressed
      $newTag.on('keydown', function (e) {
          if (['Enter', ','].includes(e.key)) {
              e.preventDefault();
              var newTag = $(this).val();
              addTag(newTag);
              $(this).val('');
          }
      });

      // Remove tag only if input is focused
      $tagList.on("click", ".rmTag", function () {
          $(this).parent().remove();

          var removed_tag = $(this).data('tag_badge');

          // Update tag list in database
          var change_view_page_data = {
              ticket_id: ticket_id,
              removed_tag: removed_tag,
          };
          view_page_data_change(change_view_page_data);
      });

      $(document).on("click", ".ticket-page-tags .add_lbl_tag", function () {
          $newTag.show().focus();
      });

      // $(document).on("mouseenter", ".ticket-page-tags .tagList", function () {
      //     $('.rmTag').css('display', 'inline-block');
      // });

      // $(document).on("mouseleave", ".ticket-page-tags .tagList", function () {
      //     $('.rmTag').css('display', 'none');
      // });

      $(document).on("blur", "#newTag", function () {
          $newTag.hide();
      });

    /*------------------------------------------------------- END - ADD REMOVE TAG ------------------------------------------------------------*/

  });


function summernote_function(selector){

  $(selector).summernote("reset");
 
  $(selector).summernote({
    callbacks: {
    onImageUpload: function(files) {
      // upload image to server and create imgNode...
      $summernote.summernote('insertNode', imgNode);
    }
  }

  });

  


}

 


  function view_page_data_change(data) {
    // updatedDescription = editorInstance.getData();

    $.ajax({
      url: ADMIN_URL + 'Nebula_dashboard/updateViewPageChanges',
      method: 'POST',
      data: data,
      beforeSend: addOverlay,
      success: function (r) {
     
        var res = JSON.parse(r);
       
        if (res.status == '200') {

          if(data.activity_filter !== 'activity_filter'){
            sTitle = '';
            sType = getStatusText(res.status);
            sText = res.message;
            sAddClass = res.addclass;
            Custom.myNotification(sType, sText);
          }
          
          var activity_log = JSON.parse(res.activity_log);
          $('#scroll_tab_content .activity_string_tab').html(activity_log);

          // var updatedDescription = res.updated_desc;
          // console.log('Updated Description:', updatedDescription);

          // console.log(res);
          // console.log(updated_description);
          // var updated_desc = JSON.parse(res.updated_description);
         
         
          $('.show-description').html();

          location.reload();

          // for when update data then  auto scroll to bottom side
          // var tabContent = document.getElementById('scroll_tab_content');
          // tabContent.scrollTop = tabContent.scrollHeight;
          
        } else {
          sTitle = '';
          sType = getStatusText(res.status);
          sText = res.message;
          sAddClass = res.addclass;
          Custom.myNotification(sType, sText);
          return false;
        }
      },
      complete: removeOverlay,
      error: function (xhr, status, error) {
        // Handle error
        console.error("Error While Submitting View Page Data", error);
        removeOverlay();  // Remove the loading overlay
      }
    });
  }

  // document.querySelectorAll('.nebula-ticket-attached-file .file-link').forEach(function (link) {
  //   link.addEventListener('click', function (event) {
  //     event.preventDefault();
  //     const fileUrl = link.href;
  //     const baseUrl = window.location.origin;

  //     // Open the file in a new tab without changing the current page's URL
  //     const newTab = window.open(fileUrl, '_blank');
  //     if (newTab) {
  //       newTab.focus();
  //     }

  //     // Optionally, you can navigate to the base URL in the current tab (if needed):
  //     // window.location.href = baseUrl; // Uncomment this if you want to redirect the current tab to the base URL after clicking.
  //   });
  // });

  function handleFileUpload(event) {
    const file = event.target.files[0];
    if (file) {
      const attachmentContainer = document.getElementById('attachmentContainer');

      // Create a new attachment element
      const attachment = document.createElement('div');
      attachment.classList.add('attachment');
      attachment.innerHTML = `
        
        <span>${file.name}</span>
        <button onclick="this.parentElement.remove()">✕</button>
      `;
      // <img src="https://cdn-icons-png.flaticon.com/512/337/337946.png" alt="PDF Icon">

      // Append the attachment to the container
      attachmentContainer.appendChild(attachment);

      // Clear the file input value so the same file can be reselected if needed
      event.target.value = "";
    }
  }
  
  const selectElement = document.getElementById('view_page_status');

  selectElement.addEventListener('change', function () {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const selectedColor = selectedOption.getAttribute('data-view_page_status');

    // Change background color, border color, and font color based on the selected view_page_status
    if (selectedColor === 'assigned') {
      selectElement.style.backgroundColor = '#fff9f2'; // Light red background for Inactive
      selectElement.style.borderColor = '#d17c0f'; // Red border for Inactive
      selectElement.style.color = '#d17c0f'; // Dark red text color
    } else if (selectedColor === 'in_progress') {
      selectElement.style.backgroundColor = '#e1ecff'; // Light yellow background for Pending
      selectElement.style.borderColor = '#1c5ecb'; // Yellow border for Pending
      selectElement.style.color = '#1c5ecb'; // Dark yellow text color
    } else if (selectedColor === 'on_hold') {
      selectElement.style.backgroundColor = '#ffecee'; // Light yellow background for Pending
      selectElement.style.borderColor = '#f73f50'; // Yellow border for Pending
      selectElement.style.color = '#f73f50'; // Dark yellow text color
    } else if (selectedColor === 're_open') {
      selectElement.style.backgroundColor = '#fbf5f9'; // Light yellow background for Pending
      selectElement.style.borderColor = '#b02381'; // Yellow border for Pending
      selectElement.style.color = '#b02381'; // Dark yellow text color
    } else if (selectedColor === 'not_a_bug') {
      selectElement.style.backgroundColor = '#4e4949bf'; // Light yellow background for Pending
      selectElement.style.borderColor = '#ffffff'; // Yellow border for Pending
      selectElement.style.color = '#ffffff'; // Dark yellow text color
    } else if (selectedColor === 'closed') {
      selectElement.style.backgroundColor = '#f6fdf9'; // Light yellow background for Pending
      selectElement.style.borderColor = '#22c56c'; // Yellow border for Pending
      selectElement.style.color = '#22c56c'; // Dark yellow text color
    }
    else if (selectedColor === 'open') {
      selectElement.style.backgroundColor = '#f1f1f1'; // Light yellow background for Pending
      selectElement.style.borderColor = '#333'; // Yellow border for Pending
      selectElement.style.color = '#333'; // Dark yellow text color
    }
  });

  /*-------------------------------------------------------END ADD REMOVE TAG -------------------------------------------------------*/

  /*----- Light Box Code Start----------*/
  function openModal() {
    document.getElementById("myModal").style.display = "block";
  }

  function closeModal() {
    document.getElementById("myModal").style.display = "none";
  }

  var slideIndex = 1;
  showSlides(slideIndex);

  function plusSlides(n) {
    showSlides(slideIndex += n);
  }

  function currentSlide(n) {
    showSlides(slideIndex = n);
  }

  function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides-light-box");
    var dots = document.getElementsByClassName("demo-light");
    var captionText = document.getElementById("caption");
    if (n > slides.length) {slideIndex = 1}
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active-light-box", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active-light-box";
    captionText.innerHTML = dots[slideIndex-1].alt;
  }


  /*----------Light Box Code End---------*/

</script>