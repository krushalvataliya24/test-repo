<section class="portlet-toggler">
    <!-- Modal -->
    <div class="page-header page-header-light">
        <div class="page-header-content header-elements-md-inline">
            <div class="page-title d-flex">
                <h4><?php echo $headTitle; ?></h4>
            </div>
        </div>
        <div class="bradcrumb-sec"><?php echo $bradcrumb; ?> </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>

    <div class="content">
        <!-- START - Serach Filters and Settings -->
        <div class="global-search-container mb-1" id="vn-info">
            <div class="row">
                <div class="col-lg-8">
                    <div class="d-flex align-items-start list-page-filters">
                        <!-- Set Permission for deaprtment filter -->
                        <?php if(in_array(dept_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["filter_options"])){ ?>
                        <div class="col-lg-2 pl-0 pr-1">
                            <select id="department_filter_value" class="department_filter form-control select2 col-lg-2 mr-1" name="nebula_filter_department[]" multiple>
                                <?php foreach ($departments as $key => $value) { ?>
                                    <option class="list_department_filter" value="<?= $value['type'] ?>">
                                    <?= ucfirst($value['type']) ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <?php } ?>

                        <!-- Set Permission for ticket type filter -->
                        <?php if(in_array(ticket_type_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["filter_options"])){ ?>
                            <select id="type_filter_value" class=" sorting-btn form-control mr-1" style="width:11%"><option value="" selected>Select Type</option>
                                <?php
                                    //MY: Add Comment because make Purpose Value Dynamically
                                    $purposeTypeArray = purposeTypes();
                                    if(!in_array(getCurrentLoggedInUserType(), nebula_sw_roles())){
                                        unset($purposeTypeArray['task_assign']);
                                    }
                                    
                                    if ($purposeTypeArray) {
                                        foreach ($purposeTypeArray as $purposeKey => $purposeValue) {
                                            // if ($purposeKey == 'task_assign') {
                                            //     if (in_array(getCurrentLoggedInUserType(), ['SW_ADMIN', 'SW_QA'])) {
                                            //     } else {
                                            //         continue;
                                            //     } 
                                            // }
                                            echo '<option class="list_filter" value="'.$purposeKey.'">'. strtok($purposeValue, " ").'</option>';
                                        }
                                    }
                                ?>
                            </select>
                        <?php } ?>

                        <!-- Set Permission for status wise filter -->
                        <?php if(in_array(status_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["filter_options"])){ ?> 
                                <div class="pl-0 pr-1" style="width:11%">
                                    <select id="nebula_status_filter_list" class=" sorting-btn form-control select2 col-lg-2 mr-1" name="nebula_status_filter_list[]" multiple>
                                        <?php foreach($get_all_status_types as $status_key => $status_value){ ?>
                                        <option class="list_status_filter" value="<?= $status_key ?>"><?= $status_value ?>
                                        </option>
                                        <?php } ?>
                                    </select>
                                </div>
                        <?php } ?>

                        <!-- Set Permission for Created_at & Updated_at filter -->
                        <?php if(in_array(nebula_created_updated_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["filter_options"])){ ?>
                            <select id="nebula_select_date_wise_filter_value" class=" sorting-btn form-control mr-1" style="width:13%">
                                <option value="" selected>Select Date Filter</option>
                                <option class="nebula_list_date_filter" value="created_at">Created At</option>
                                <option class="nebula_list_date_filter" value="updated_at">Updated At</option>
                            </select>
                        <?php } ?>

                        <!-- Set Permission for date wise filter -->
                        <?php if(in_array(datewise_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["filter_options"])){ ?>
                            <input type="text" id="nebula_daterange" name="nebula_daterange" class="form-control col-lg-2 mr-1" placeholder="Select Start & End date" />
                        <?php } ?>

                        <button class="btn btn-success px-2 nebula_filter_search"><img
                                src="<?php echo base_url(ADM_THEME_COMMON_NEBULA_IMG) ?>search.svg" title="Search" alt="" width="20">
                        </button>
                        <button class="btn btn-primary px-2 ml-1" id="clear_nebula_filters" title="Clear Filters">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABX0lEQVR4nO2VTUoDQRCFG7NSDHiBrBVBgswpjAq5hkYwegJFcKGLHERI9hFduhDPICj4g/hDFPyHT0peoB3i0DMdcGNtevrVq/e6Z7p6nPuPPMGQwv2ZgQXQEW/vGwgI46qmE0KuAI8qWAzgz4lrNZXQFTVVdAaMZ/DGgFNxm0HiKiwBJyrcyeDtimPcUrCBihPgE/gAZgfkZ4B3cZJc4p5ISys89lcIjABHyrUKiUuoDJxLqOHhK8IsVy5sILG6xHoe1hNWjxL3BH80kKbtoYj/YtC27+D1QRe4A+6BfcNcpMGExo2MG2OzsEGqg9/UmNfALbAKvChXcxEGXcHrmk8DVT0vK3cQY/Ag+MaazsMngYv+/ZTLQDEqzD4oGpOUwWX6aOcxqAqz02KxpvlUfyfAknKHQQZusGlNIq/q7Cu9rgbwrNxCYQOZbKV258d2lLhnMm+nRT+cJ3st/sq/AF2r8CJYQvhYAAAAAElFTkSuQmCC"
                                alt="clear-filters" width="20">
                        </button>
                    </div>
                </div>
                <div class="col-lg-4">

                    <?php if(in_array(getCurrentLoggedInUserType(), nebula_sw_admin_role())) {  ?>

                        <!-- Hide Nebula settings from users -->
                        <?php if(!in_array(getCurrentLoggedInUserName(),nebula_hide_screens())) {  ?>
                            <button type="button" class="btn btn-primary mr-2 float-right btn-small" onclick="window.location.href='<?php echo base_url(); ?>Nebula_mapper';" style="text-align: right; display: block;">Nebula Settings</button>

                            <div class="orion-user-list float-right">
                                <select id="orion-user-select" class="form-control">
                                    <option value="" selected>Select User</option>
                                    <?php foreach($orion_users as $role => $usernames){ ?>
                                    <optgroup label="<?= ucwords(str_replace('_', ' ', $role)) ?>">
                                        <?php foreach($usernames as $k => $username){ ?>
                                        <option value="<?= $username ?>"><?= $username ?></option>
                                        <?php } ?>
                                    </optgroup>
                                    <?php } ?>
                                </select>
                            </div>

                        <?php } ?>
                    <?php }  ?>

                </div>
            </div>
        </div>
        <!-- END - Serach Filters and Settings -->

        <div class="d-flex w-100">
            <div class="w-100">
                 <!-- Tabs -->
                <ul class="nav nav-tabs w-100">
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link active nebula_dashboard_chart_a"
                            href="#nebula_dashboard_datatable">Dashboard <span class="badge bg-secondary"></span></a>
                    </li>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#open_datatable">Open <span
                                class="badge bg-info open_get_count"></span></a>
                    </li>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#assigned_datatable">Assigned <span
                                class="badge bg-primary assigned_get_count"></span></a>
                    </li>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#on_hold_datatable">On Hold <span
                                class="badge bg-danger on_hold_get_count"></span></a>
                    </li>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#in_progress_datatable">In Progress <span
                                class="badge bg-warning in_progress_get_count"></span></a>
                    </li>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#closed_datatable">Closed <span
                                class="badge bg-success closed_get_count"></span></a>
                    </li>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#not_a_bug_datatable">Not A Bug <span
                                class="badge bg-secondary not_a_bug_get_count"></span></a>
                    </li>
                    <?php if(in_array(all_tab_string(), checkUserPermission(getCurrentLoggedInUserID())["tab_option"])) {  ?>
                    <li class="nav-item">
                        <a data-toggle="tab" class="nav-link" href="#all_type_datatable"> All <span
                                class="badge bg-dark all_type_get_count"></span></a>
                    </li>
                    <?php } ?>
                </ul>
                <div class="tab-content position-relative">
                    <?php if(in_array(all_tab_string(), checkUserPermission(getCurrentLoggedInUserID())["tab_option"])) {  ?>
                    <div class="tab-pane px-2" id="all_type_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table" id="show_list_table_all_type_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <?php } ?>

                    <div class="tab-pane active px-2 nebula_dashboard_chart" id="nebula_dashboard_datatable">
                        <div class="row">
                            <div class="col-lg-3">
                                <div class="nebula-dashboard-card-box">
                                    <div class="d-flex nebula_status">
                                        <h5>Tickets by Status</h5>
                                        <select id="nebula_dashboard_status_filter" class="form-control mr-1 ml-auto" style="width:21%">
                                            <option class="nebula_dashboard_status_filter_options" value="today" style="color:#22c56c">Today</option>
                                            <option class="nebula_dashboard_status_filter_options" value="last_day" style="color:#d17c0f">Last Day</option>
                                            <option class="nebula_dashboard_status_filter_options" value="this_week" style="color:#f73f50">This Week</option>
                                            <option class="nebula_dashboard_status_filter_options" value="last_week" style="color:#0504fb">Last Week</option>
                                            <option class="nebula_dashboard_status_filter_options" value="this_month" selected style="color:#646100">This Month</option>
                                            <option class="nebula_dashboard_status_filter_options" value="last_month" style="color:#460517">Last Month</option>
                                            <option class="nebula_dashboard_status_filter_options" value="this_year" style="color:#0fada5">This Year</option>
                                        </select>
                                    </div>
                                    
                                    <div class="chart-container" style="position: relative; height:40vh; width:48vw">
                                        <canvas id="nebula_own_ticket_myPieChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="nebula-dashboard-card-box-own-dept">
                                    <div class="d-flex nebula_dept">
                                        <h5>Tickets by Departments</h5>
                                        <select id="nebula_dashboard_dept_filter" class="form-control mr-1 ml-auto" style="width:21%">
                                            <option class="nebula_dashboard_dept_filter_options" value="today" style="color:#22c56c">Today</option>
                                            <option class="nebula_dashboard_dept_filter_options" value="last_day" style="color:#d17c0f">Last Day</option>
                                            <option class="nebula_dashboard_dept_filter_options" value="this_week" style="color:#f73f50">This Week</option>
                                            <option class="nebula_dashboard_dept_filter_options" value="last_week" style="color:#0504fb">Last Week</option>
                                            <option class="nebula_dashboard_dept_filter_options" value="this_month" selected style="color:#646100">This Month</option>
                                            <option class="nebula_dashboard_dept_filter_options" value="last_month" style="color:#460517">Last Month</option>
                                            <option class="nebula_dashboard_dept_filter_options" value="this_year" style="color:#0fada5">This Year</option>
                                        </select>

                                    </div>
                                    <div class="chart-container" style="position: relative; height:40vh; width:48vw">
                                        <canvas id="own_dept_myPieChart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="nebula-dashboard-card-box">
                                    <h5>Recent Tickets</h5>
                                    <div class="nebula-buglist-table">
                                        <table class="table table-bordered orion-table show_list_table111" id="nebula_dashboard_datatable_recent" cellspacing="0" width="100%">
                                            <thead style="position:sticky;top:0;z-index:9">
                                                <tr style="background-color:#555;color:#fff">
                                                    <?php  foreach($header_data_recent as $key => $value){ ?>
                                                    <th><?= $value ?></th>
                                                    <?php } ?>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane  px-2" id="open_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table" id="show_list_table_open_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane px-2" id="assigned_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table"
                                id="show_list_table_assigned_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane px-2" id="on_hold_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table" id="show_list_table_on_hold_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane px-2" id="in_progress_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table" id="show_list_table_in_progress_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane px-2" id="closed_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table" id="show_list_table_closed_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane px-2" id="not_a_bug_datatable">
                        <div class="nebula-buglist-table">
                            <table class="table table-bordered orion-table show_list_table" id="show_list_table_not_a_bug_datatable" cellspacing="0" width="100%">
                                <thead style="position:sticky;top:0;z-index:9">
                                    <tr style="background-color:#555;color:#fff">
                                        <?php foreach($table_heading as $key => $value){ ?>
                                        <th><?= $value ?></th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class=" panel panel-body portlet-toggler pageform" style="display:none;">

</div>

<div class="nebula-footer text-left"><?= $todays_ticket_count ?></div>
<?php
 $ticket_purpose_types = purposeTypes();
 $ticketPurposeProperty = purposeTypeProperty();
?>



<style>
    .nebula-dashboard-card-box,
    .nebula-dashboard-card-box-own-dept {
        border: 1px solid #efefef;
        box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.1);
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    .orion-user-list.float-right {
        width: 300px;
        margin-right: 10px;
    }

    .orion-user-list #orion-user-select {
        width: 277px;
    }

    .list-page-filters #department_filter_value {
        min-width: 191px !important;
    }

    #nebula_daterange {
        min-width: 200px !important;
        text-align: center !important;
    }

    .nebula-buglist-table .datatable-scroll-wrap {
        max-height: 530px;
    }

    .nebula-footer {
        background-color: #f7f8fa;
        padding: 10px 20px;
        position: fixed;
        bottom: 0;
        width: 100%;
        border-top: 1px solid #ddd;
    }

    .btn-small {
        padding: 2px 5px;
    }

    .global-nebula-filters {
        display: flex;
        position: absolute;
        right: 389px;
        margin-top: -6px;
        z-index: 9;
        background-color: #f1f1f1;
        padding: 5px;
        border: 1px solid #ddd;
    }

    .global-nebula-filters input.form-control {
        width: 227px;
        margin-right: 5px;
    }

    button.btn.sorting-btn {

        border: 1px solid #d0d0d0;
        padding: 6px 11px;
        top: 1px;
        z-index: 9;
        background-color: #fff;
        color: #333;
    }

    button.btn.sorting-btn img {
        width: 18px;
    }

    /* button.btn.sorting-btn.dropdown-toggle::after{display: none;} */

    button.btn.department_filter {

        border: 1px solid #d0d0d0;
        padding: 6px 11px;
        top: 1px;
        z-index: 9;
        background-color: #fff;
        color: #333;
    }

    button.btn.department_filter img {
        width: 18px;
    }

    /* button.btn.department_filter.dropdown-toggle::after{display: none;} */

    .department_filter+.dropdown-menu.show {
        height: 216px;
        overflow: auto;
    }

    .nebula-buglist-table .orion-table {
        width: auto
    }

    .dataTables_length span {
        display: none;
    }

    .datatable-header {
        display: flex;
        align-items: center;
        float: right;
        border: none;
        padding: 0;
    }

    .dataTables_filter span {
        display: none;
    }

    .datatable-header .dt-buttons {
        margin-bottom: 10px;
        padding-top: 0;
        order: 4;
        margin-left: 4px;
    }

    .nebula-buglist-table .orion-table th,
    .nebula-buglist-table .orion-table td {
        padding: 2px 5px;
        word-break: break-all;
    }

    .select2-selection--multiple .select2-selection__choice {
        padding: 2px 5px;
        font-size: smaller;
        background-color: #324148;
    }

    #nebula_dashboard_status_filter{
        background-color: #ffffff;
        color: #646100;
        border-color: #646100;
        font-size: 12px;
        padding: 0;
        height: 26px; 
    }
    #nebula_dashboard_dept_filter{
        background-color: #ffffff;
        color: #646100;
        border-color: #646100;
        font-size: 12px;
        padding: 0;
        height: 26px;
    }

</style>

<script>

    var ticket_purpose_types = '<?php echo json_encode($ticket_purpose_types, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>';
    var ticketPurposeProperty = '<?php echo json_encode($ticketPurposeProperty, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>';

    var nebula_dashboard_list_oTable = {};
    var nebula_dashboard_list_oTable_recent = {};
    var nebula_dashboard_list_activeTab = 'open_datatable';

    $('.orion-user-list #orion-user-select').select2();

    $('.list-page-filters #department_filter_value').select2({
        placeholder: "Select Department", // Placeholder text
    });

    $('.list-page-filters #nebula_status_filter_list').select2({
        placeholder: "Select Status", // Placeholder text
    });


    var ticket_purpose_types = '<?php echo json_encode($ticket_purpose_types, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>';
    var ticketPurposeProperty = '<?php echo json_encode($ticketPurposeProperty, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>';
    
    // var nebula_show_list_oTable = {};
    // var nebula_dashboard_show_list_oTable_recent = {};
    // var nebula_show_list_activeTab = 'open_datatable';

    var status_dashboard_data = '<?php echo json_encode($nebula_dashboard_filter_data['data']); ?>';

    if (Object.keys(status_dashboard_data).length > 0) {
        if (typeof status_dashboard_data === "string") {
            status_dashboard_data = JSON.parse(status_dashboard_data);
        }
    }
    // console.log("status_dashboard_data : " + status_dashboard_data);
    
    pieChartTicketByStatus(status_dashboard_data);

    var dept_dashboard_data = '<?php echo json_encode($nebula_dept_dashboard_filter_data['data']); ?>';
    if (Object.keys(dept_dashboard_data).length > 0) {
        if (typeof dept_dashboard_data === "string") {
            dept_dashboard_data = JSON.parse(dept_dashboard_data);
        }
    }
    
    pieChartTicketByDept(dept_dashboard_data);

    $(document).on('change', '.nebula_dept #nebula_dashboard_dept_filter', function(e){
        
        e.preventDefault();
        var stat_filter = $(this).val();

        addOverlay();

        $.ajax({
            url: 'Nebula_dashboard/nebula_dashboard_dept_stats_filters',
            method: 'POST',
            dataType: "json",
            data: { dept_stat_filter : stat_filter},
            beforeSend: addOverlay,
            success: function(r) {
                if (r.status == 200) {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    // Custom.myNotification(sType, sText);
                    // pieChartTicketByStatus(r.data);
                    // console.log("r.data : "  + r.data);
                    pieChartTicketByDept(r.data);

                    $('#nebula_dashboard_dept_filter').each(function() {
                        var chart_status = $(this).val();

                        if (chart_status == 'today') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#22c56c',
                                'border-color': '#22c56c'
                            });
                        } else if (chart_status == 'last_day') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#d17c0f',
                                'border-color': '#d17c0f'
                            });
                        } else if (chart_status == 'this_week') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#f73f50',
                                'border-color': '#f73f50'
                            });
                        }else if (chart_status == 'last_week') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#0504fb',
                                'border-color': '#0504fb'
                            });
                        }else if (chart_status == 'this_month') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#646100',
                                'border-color': '#646100'
                            });
                        }else if (chart_status == 'last_month') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#460517',
                                'border-color': '#460517'
                            });
                        }else if (chart_status == 'this_year') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#0fada5',
                                'border-color': '#0fada5'
                            });
                        }
                    });

                } else {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);
                }
            },
            complete: removeOverlay,
            error: function(xhr, status, error) {
                console.error("Error submitting form:", error);
                removeOverlay(); // Remove the loading overlay
            }
        });

        removeOverlay(); // Remove the loading overlay after the request

    });

    $(document).on('change', '.nebula_status #nebula_dashboard_status_filter', function(e){
        e.preventDefault();
        var stat_filter = $(this).val();

        addOverlay();

        $.ajax({
            url: 'Nebula_dashboard/nebula_dashboard_status_stats_filters',
            method: 'POST',
            dataType: "json",
            data: { status_stat_filter : stat_filter},
            beforeSend: addOverlay,
            success: function(r) {
                if (r.status == 200) {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    // Custom.myNotification(sType, sText);
                    pieChartTicketByStatus(r.data);

                    $('#nebula_dashboard_status_filter').each(function() {
                        var chart_status = $(this).val();

                        if (chart_status == 'today') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#22c56c',
                                'border-color': '#22c56c'
                            });
                        } else if (chart_status == 'last_day') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#d17c0f',
                                'border-color': '#d17c0f'
                            });
                        } else if (chart_status == 'this_week') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#f73f50',
                                'border-color': '#f73f50'
                            });
                        }else if (chart_status == 'last_week') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#0504fb',
                                'border-color': '#0504fb'
                            });
                        }else if (chart_status == 'this_month') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#646100',
                                'border-color': '#646100'
                            });
                        }else if (chart_status == 'last_month') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#460517',
                                'border-color': '#460517'
                            });
                        }else if (chart_status == 'this_year') {
                            $(this).css({
                                'background-color': '#ffffff',
                                'color': '#0fada5',
                                'border-color': '#0fada5'
                            });
                        }
                    });

                } else {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);
                }
            },
            complete: removeOverlay,
            error: function(xhr, status, error) {
                console.error("Error submitting form:", error);
                removeOverlay(); // Remove the loading overlay
            }
        });

        removeOverlay(); // Remove the loading overlay after the request

    });

    $(document).on('change', '.show_list_table #list_assign_to', function(e) {
        e.preventDefault();

        var assign_to_ids = $(this).val();
        //  alert(assign_to_ids);  

        var ticket_id = $(this).data('ticket_id');

        var data = {
            assign_to_ids: assign_to_ids,
            ticket_id: ticket_id
        };

        addOverlay();

        $.ajax({
            url: 'Nebula_dashboard/updateTrainer',
            method: 'POST',
            dataType: "json",
            data: data,
            beforeSend: addOverlay,
            success: function(r) {
                if (r.status == 200) {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);

                    if (nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab]) {
                        nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab].draw();
                    }
                } else {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);
                }
            },
            complete: removeOverlay,
            error: function(xhr, status, error) {
                // Handle error
                console.error("Error submitting form:", error);
                removeOverlay(); // Remove the loading overlay
            }
        });

        removeOverlay(); // Remove the loading overlay after the request
    });

    $(document).on('change', '.show_list_table .status_type', function(e) {
        e.preventDefault();

        var status_stage = $(this).val();
        var color_code = $(this).children('.' + status_stage).data('color_code');
        $(this).css('background-color', color_code);
        var status_id = $(this).data('status_id');

        var ticket_id = $(this).data('ticket_id');

        var data = {
            status_stage: status_stage,
            ticket_id: ticket_id
        };

        addOverlay();
        $.ajax({
            url: 'Nebula_dashboard/updateStatus',
            method: 'POST',
            dataType: "json",
            data: data,
            beforeSend: addOverlay,
            success: function(r) {
                if (r.status == 200) {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);
                    if (nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab]) {
                        nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab]
                            .draw(); // Redraw the DataTable of the active tab
                    }
                    return false;
                } else {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);

                }
            },
            complete: removeOverlay,
            error: function(xhr, status, error) {
                console.error("Error While Updating Status", error);
                // removeOverlay();
            },
        });
        removeOverlay();
    });

    $(document).on('change', '.show_list_table .change-ticket-priority', function(e) {
        e.preventDefault();

        var ticket_priority = $(this).val();
        // alert(ticket_priority); return;

        var color_code = $(this).children('.' + ticket_priority).data('color_code');
        $(this).css('background-color', color_code);

        var ticket_id = $(this).data('ticket_id');

        var data = {
            ticket_priority: ticket_priority,
            ticket_id: ticket_id
        };

        updateListPageDropdown(data);
    });

    $(document).on('change', '.show_list_table .change-ticket-purpose', function(e) {
        e.preventDefault();

        var ticket_purpose = $(this).val();
        // alert(ticket_purpose); return;

        var color_code = $(this).children('.' + ticket_purpose).data('color_code');
        $(this).css('background-color', color_code);

        var ticket_id = $(this).data('ticket_id');

        var data = {
            ticket_purpose: ticket_purpose,
            ticket_id: ticket_id
        };

        updateListPageDropdown(data);
    });

    $(document).on('click', '.admin_list_remove_tag .rmTag', function(e) {
        e.preventDefault();

        var tag = $(this).closest('.admin_list_remove_tag'); // Find the tag wrapper
        var tagValue = $(this).data('tag_badge'); // Get the tag text value

        tag.remove(); // remove tag from DOM

        var ticket_id = tag.data('tag_ticket_id');

        var data = {
            removed_tag: tagValue,
            ticket_id: ticket_id
        };

        updateListPageDropdown(data);
    });
    
    function updateListPageDropdown(data) {
        addOverlay();
        $.ajax({
            url: 'Nebula_dashboard/updateListPageDropdown',
            method: 'POST',
            dataType: "json",
            data: data,
            beforeSend: addOverlay,
            success: function(r) {
                if (r.status == 200) {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);
                    if (nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab]) {
                        nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab].draw(); // Redraw the DataTable of the active tab
                    }
                    return false;
                } else {
                    sTitle = '';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType, sText);

                }
            },
            complete: removeOverlay,
            error: function(xhr, status, error) {
                console.error("Error While Updating Status", error);
                // removeOverlay();
            },
        });
        removeOverlay();
    }

    function pieChartTicketByDept(pie_chart_count_arr){

        var con_pie_chart_count_arr = [];

        // Loop through the object and store key-value pairs in the format "key => value"
        $.each(pie_chart_count_arr, function(key, value) {
            con_pie_chart_count_arr.push(key + " => " + value);
        });
        // console.log(con_pie_chart_count_arr);

        let statusArray = [];
        let countArray = [];

        con_pie_chart_count_arr = con_pie_chart_count_arr.filter(function(item) {
            // Extract the key and value from the string
            var parts = item.split(' => ');
            var key = parts[0];
            var value = parts[1];

            // Keep item if value is not "0" and key is not "all_type"
            return value != '0' && key != 'all_type';
        });

        con_pie_chart_count_arr = con_pie_chart_count_arr.filter(function(item) {
            // Extract the key and value from the string
            var parts = item.split(' => ');
            var key = parts[0];
            var value = parts[1];
            
            // Replace underscores with spaces and capitalize the first letter of each word
            key = key.replace(/_/g, ' ') // Replace underscores with spaces
                    .replace(/\b\w/g, function(char) { return char.toUpperCase(); }); // Capitalize the first letter of each word
            
            statusArray.push(key);
            countArray.push(value);

        });

        // console.log("statusArray dept : " + statusArray);
        // console.log("countArray dept : " + countArray);

        // START - Own/All Department Tickets

        // var own_dept_chart_label = '<?php echo $nebula_dashboard_data["all_final_dept"]; ?>';
        var own_dept_chart_label = '<?php echo $nebula_dashboard_data["all_dept_group_names"]; ?>';
        // console.log("labels : " + own_dept_chart_label);
        own_dept_chart_label = statusArray;

        // var own_dept_chart_count = '<?php echo $nebula_dashboard_data["dept_final_count_values"]; ?>';
        var own_dept_chart_count = '<?php echo $nebula_dashboard_data["all_dept_group_count"]; ?>';
        // console.log("labels : " + own_dept_chart_count);
        own_dept_chart_count = countArray;

        if (own_dept_chart_label.length == 0 && own_dept_chart_count.length == 0) {

            document.querySelector('.nebula-dashboard-card-box-own-dept').innerHTML =
                // '<h5>Tickets by Departments</h5><p style="text-align:center; color:red; font-size:18px;">Not available</p>';
                '<div class="d-flex nebula_dept"><h5>Tickets by Departments</h5><select id="nebula_dashboard_dept_filter" class="form-control mr-1 ml-auto" style="width:21%"><option class="nebula_dashboard_dept_filter_options" value="today" style="color:#22c56c">Today</option><option class="nebula_dashboard_dept_filter_options" value="last_day" style="color:#d17c0f">Last Day</option><option class="nebula_dashboard_dept_filter_options" value="this_week" style="color:#f73f50">This Week</option><option class="nebula_dashboard_dept_filter_options" value="last_week" style="color:#0504fb">Last Week</option><option class="nebula_dashboard_dept_filter_options" value="this_month" selected style="color:#646100">This Month</option><option class="nebula_dashboard_dept_filter_options" value="last_month" style="color:#460517">Last Month</option><option class="nebula_dashboard_dept_filter_options" value="this_year" style="color:#0fada5">This Year</option></select></div><p id="not_available_dept" style="text-align:center; color:red; font-size:18px; display:none;">Not available</p><div class="chart-container" style="position: relative; height:40vh; width:48vw"><canvas id="own_dept_myPieChart"></canvas></div>';
            
            $('#not_available_dept').show();
            $('#own_dept_myPieChart').hide();
        } else {
            
            $('#not_available_dept').hide();
            $('#own_dept_myPieChart').show();

            // own_dept_chart_label = own_dept_chart_label.split(',');
            // own_dept_chart_count = own_dept_chart_count.split(',');

            // If data is available, create the chart
            // Check if a chart exists and destroy it if necessary
            // Ensure the chart is an instance of Chart before trying to destroy it
            if (window.own_dept_myPieChart instanceof Chart) {
                window.own_dept_myPieChart.destroy(); // Destroy the previous chart
            }

            // Get the context of the canvas element
            var ctx = document.getElementById('own_dept_myPieChart').getContext('2d');

            // Create a new Pie chart
            window.own_dept_myPieChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: own_dept_chart_label,
                    datasets: [{
                        data: own_dept_chart_count,
                        backgroundColor: ['#00bcd4', '#8338ec', '#777777', '#ff7043', '#4caf50', '#0f5f78', '#f53aff', '#890000', '#1b8dff', 'f44336', 'FFD700'],
                        hoverBackgroundColor: ['#00bcd4', '#8338ec', '#777777', '#ff7043', '#4caf50', '#0f5f78', '#f53aff', '#890000', '#1b8dff', 'f44336', 'FFD700'],
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'left',
                            labels: {
                                usePointStyle: true, // Makes the legend items round
                                pointStyle: 'circle', // Round style for the legend
                                generateLabels: (chart) => {
                                    const datasets = chart.data.datasets;
                                    return datasets[0].data.map((data, i) => ({
                                        text: `${chart.data.labels[i]}   ${data}`,
                                        fillStyle: datasets[0].backgroundColor[i],
                                    }))
                                }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                // label: function(tooltipItem) {
                                //     var total = tooltipItem.dataset.data.reduce((sum, value) => sum + value, 0);
                                //     var percentage = ((tooltipItem.raw / total) * 100).toFixed(2) + '%';
                                //     return tooltipItem.label + ': ' + tooltipItem.raw + ' (' + percentage + ')';
                                // }
                            }
                        }
                    }
                }
            });
        }
        // END - Own/All Department Tickets
    }

    function pieChartTicketByStatus(pie_chart_count_arr) {

        var con_pie_chart_count_arr = [];

        // Loop through the object and store key-value pairs in the format "key => value"
        $.each(pie_chart_count_arr, function(key, value) {
            con_pie_chart_count_arr.push(key + " => " + value);
        });
        // console.log(con_pie_chart_count_arr);

        let statusArray = [];
        let countArray = [];

        con_pie_chart_count_arr = con_pie_chart_count_arr.filter(function(item) {
            // Extract the key and value from the string
            var parts = item.split(' => ');
            var key = parts[0];
            var value = parts[1];



            // Keep item if value is not "0" and key is not "all_type"
            return value != '0' && key != 'all_type';
        });


        con_pie_chart_count_arr = con_pie_chart_count_arr.filter(function(item) {
            // Extract the key and value from the string
            var parts = item.split(' => ');
            var key = parts[0];
            var value = parts[1];
            
            // Replace underscores with spaces and capitalize the first letter of each word
            key = key.replace(/_/g, ' ') // Replace underscores with spaces
                    .replace(/\b\w/g, function(char) { return char.toUpperCase(); }); // Capitalize the first letter of each word
            
            statusArray.push(key);
            countArray.push(value);

        });


        // START - Own Tickets
        var chart_label = '<?php echo $nebula_dashboard_data["all_status"]; ?>';
        //  console.log("chart_label : " + chart_label);
        //  var chart_label = pie_chart_count_arr;
        chart_label = statusArray;

        var own_chart_percentage = '<?php echo $nebula_dashboard_data["final_status_counts"]; ?>';
        // console.log("own_chart_percentage : " + own_chart_percentage);
        // var own_chart_percentage = '<?php echo $nebula_dashboard_data["all_status_percentage"]; ?>';
        own_chart_percentage = countArray;




        // console.log("statusArray : " + statusArray);
        // console.log("countArray : " + countArray);


        if (chart_label.length == 0 && own_chart_percentage.length == 0) {

            document.querySelector('.nebula-dashboard-card-box').innerHTML =
                // '<h5>Tickets by Status</h5><p style="text-align:center; color:red; font-size:18px;">Not available</p>';

                '<div class="d-flex nebula_status"><h5>Tickets by Status</h5><select id="nebula_dashboard_status_filter" class="form-control mr-1 ml-auto" style="width:21%"><option class="nebula_dashboard_status_filter_options" value="today" style="color:#22c56c">Today</option><option class="nebula_dashboard_status_filter_options" value="last_day" style="color:#d17c0f">Last Day</option><option class="nebula_dashboard_status_filter_options" value="this_week" style="color:#f73f50">This Week</option><option class="nebula_dashboard_status_filter_options" value="last_week" style="color:#0504fb">Last Week</option><option class="nebula_dashboard_status_filter_options" value="this_month" selected style="color:#646100">This Month</option><option class="nebula_dashboard_status_filter_options" value="last_month" style="color:#460517">Last Month</option><option class="nebula_dashboard_status_filter_options" value="this_year" style="color:#0fada5">This Year</option></select></div><p id="not_available" style="text-align:center; color:red; font-size:18px; display:none;">Not available</p><div class="chart-container" style="position: relative; height:40vh; width:48vw;"><canvas id="nebula_own_ticket_myPieChart"></canvas></div>';

            $('#not_available').show();
            $('#nebula_own_ticket_myPieChart').hide();
                
        } else {
                
            $('#not_available').hide();
            $('#nebula_own_ticket_myPieChart').show();

            // chart_label = chart_label.split(',');
            // own_chart_percentage = own_chart_percentage.split(',');

            // If data is available, create the chart
            // Check if a chart exists and destroy it if necessary
            // Ensure the chart is an instance of Chart before trying to destroy it
            if (window.nebula_own_ticket_myPieChart instanceof Chart) {
                window.nebula_own_ticket_myPieChart.destroy(); // Destroy the previous chart
            }

            var ctx1 = document.getElementById('nebula_own_ticket_myPieChart').getContext('2d');

            // Create a new pie chart
            window.nebula_own_ticket_myPieChart = new Chart(ctx1, {
                type: 'pie', // polarArea
                data: {
                    labels: chart_label,
                    datasets: [{
                        data: own_chart_percentage,
                        backgroundColor: ['#00bcd4', '#8338ec', '#777777', '#ff7043', '#4caf50', '#0f5f78', '#f53aff', '#890000', '#1b8dff', 'f44336', 'FFD700'],
                        hoverBackgroundColor: ['#00bcd4', '#8338ec', '#777777', '#ff7043', '#4caf50', '#0f5f78', '#f53aff', '#890000', '#1b8dff', 'f44336', 'FFD700']
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'left',
                            labels: {
                                usePointStyle: true,
                                pointStyle: 'circle',
                                generateLabels: (chart) => {
                                    const datasets = chart.data.datasets;
                                    return datasets[0].data.map((data, i) => ({
                                        text: `${chart.data.labels[i]}   ${data}`,
                                        fillStyle: datasets[0].backgroundColor[i],
                                    }))
                                }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                // label: function(tooltipItem) {
                                //     var total = tooltipItem.dataset.data.reduce((sum, value) => sum + value, 0);
                                //     var percentage = ((tooltipItem.raw / total) * 100).toFixed(2) + '%';
                                //     return tooltipItem.label + ': ' + tooltipItem.raw + ' (' + percentage + ')';
                                // }
                            }
                        }
                    }
                }
            });

        }
        // END - Own Tickets

    }

    function initDataTableRecent(tabId) {

        addOverlay();
        // Destroy the previous DataTable instance if it exists
        if ($.fn.dataTable.isDataTable('#' + tabId)) {
            $('#' + tabId).DataTable().clear().destroy();
            console.log('Existing DataTable destroyed');
        }
        nebula_dashboard_list_oTable_recent[tabId] = $('#' + tabId).DataTable({
            "responsive": false,
            "processing": true,
            "serverSide": true,
            "order": [],
            "searching": true,
            "bLengthChange": false,
            // "autoWidth": true,
            "iDisplayLength": 5,
            "ajax": {
                "url": ADMIN_URL + "Nebula_dashboard/show_list_ajax",
                "data": function(d) {
                    // Add tab ID as a parameter to the AJAX request
                    d.tab_id = tabId; // Send current tab ID to URL
                }
            },
            "columns": [
                { "data": "action", searchable: false, sortable: false, "width": "1%"},
                { "data": "ticket_id", searchable: true, sortable: true, "width": "2%"},
                { "data": "purpose", searchable: true, sortable: true, "width": "2%"},
                { "data": "priority", searchable: false, sortable: true, "width": "2%"},
                { "data": "title", searchable: true, sortable: true, "width": "3%"},
                { "data": "created_by", searchable: false, sortable: true, "width": "3%"}
            ],
            columnDefs: [{
                "targets": "_all"
            }],
            buttons: [],
            // Add the 'dom' option to display only the table
            //"dom": 'ft'
            drawCallback: function(settings) {

                $('.change-ticket-priority').each(function() {
                    var priority_stage = $(this).val();
                    if (priority_stage == 'low') {
                        $(this).css({
                            'background-color': '#f6fdf9',
                            'color': '#22c56c',
                            'border-color': '#22c56c'
                        });
                    } else if (priority_stage == 'normal') {
                        $(this).css({
                            'background-color': '#fff9f2',
                            'color': '#d17c0f',
                            'border-color': '#d17c0f'
                        });
                    } else if (priority_stage == 'high') {
                        $(this).css({
                            'background-color': '#fff7f8',
                            'color': '#f73f50',
                            'border-color': '#f73f50'
                        });
                    }
                });

                //MY: Add Comment because make Purpose Value Dynamically
                $('.change-ticket-purpose').each(function() {
                    var purpose_stage = $(this).val();
                    var element = $(this); // Store reference to the current element
                    if (Object.keys(ticket_purpose_types).length > 0) {
                        if (typeof ticket_purpose_types === "string") {
                            ticket_purpose_types = JSON.parse(ticket_purpose_types);
                        }
                        if (typeof ticketPurposeProperty === "string") {
                            ticketPurposeProperty = JSON.parse(ticketPurposeProperty);
                        }
                        $.each(ticket_purpose_types, function(keyType, valueType) {
                            if (purpose_stage == keyType) {
                                element.css(ticketPurposeProperty[keyType]);
                            }
                        });
                    }
                });
                /* if (purpose_stage == 'bug_report') {
                    $(this).css({
                        'background-color': '#fff7f8',
                        'color': '#f73f50',
                        'border-color': '#f73f50'
                    });
                } else if (purpose_stage == 'feature_request') {
                    $(this).css({
                        'background-color': '#fff9f2',
                        'color': '#d17c0f',
                        'border-color': '#d17c0f'
                    });
                } else if (purpose_stage == 'training_request') {
                    $(this).css({
                        'background-color': '#f6fdf9',
                        'color': '#22c56c',
                        'border-color': '#22c56c'
                    });
                } else if (purpose_stage == 'task_assign') {
                    $(this).css({
                        'background-color': '#f0f2fe',
                        'color': '#0504fb',
                        'border-color': '#0504fb'
                    });
                } */
            }
        });
        removeOverlay();
    }

    $(document).ready(function() {

        var pie_chart_count_arr = [];
        var is_export = '<?php echo $is_export_excel; ?>';

        /* START - Set export excel button */
            var buttonsConfig = [
                {
                    extend: 'colvis',
                    columns: ':not(.noVis):not(:first-child):not(:nth-child(2))',
                    text: '<i class="fa-th-list"></i>',
                    titleAttr: 'Column visibility selector',
                    popoverTitle: 'Column visibility selector'
                }
            ];

            // Conditionally add the export button if `is_export` is not an empty string
            if ($.trim(is_export) !== '') {
                buttonsConfig.push({
                    extend: 'excelHtml5',  // Use 'excelHtml5' for more control over export
                    text: '<i class="fa fa-file-excel-o"></i>',
                    className: 'btn btn-success',
                    filename: 'nebula_report',  // Set the export file name
                    exportOptions: {
                        columns: function(idx, data, node) {
                            return idx !== 0 && $(node).css('display') !== 'none';  // Include only visible columns excluding the first one
                        },
                        format: {
                            body: function(data, row, column, node) {
                                // Custom body format for dropdowns or badges
                                var select = $(node).find('select.custom-select.trainer.list_assign_to_cls');
                                if (select.length) {
                                    var selectedOptions = select.find('option:selected').map(function() {
                                        return $(this).text().trim();
                                    }).get().join(', '); // Join selected options with a comma
                                    return selectedOptions; // Return extracted text or original data
                                }
                                var select = $(node).find('select');
                                if (select.length) {
                                    var selectedOption = select.find('option:selected');
                                    return selectedOption.text(); // Export the text of the selected option
                                }
                                var spans = $(node).find('span.badge');
                                if (spans.length) {
                                    return spans.map(function() {
                                        return $(this).clone().children().remove().end().text().trim();
                                    }).get().join(', ');
                                }
                                return data; // Export normally if not a dropdown
                            }
                        },
                    }
                });
            }
        /* END - Set export excel button */

        initDataTableRecent('nebula_dashboard_datatable_recent');

        // var nebula_dashboard_list_activeTab = 'open_datatable';
        var selectedFilterType = '';
        var selecteddepartmentFilter = '';
        localStorage.setItem("filtertype", '');
        localStorage.setItem("departmentFilter", '');

        var selectedOrionUser = '';

        var filter_global = {
            selectedDepartment: '',
            selectedType: '',
            selectedStatus: '',
            selectedCreatedUpdated: '',
            report_start_date: '',
            report_end_date: ''
        };

        initDataTable('open_datatable', filter_global, selectedOrionUser);

        $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
            nebula_dashboard_list_activeTab = $(e.target).attr('href').substring(1);
            if (!nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab]) {

                initDataTable(nebula_dashboard_list_activeTab, filter_global, selectedOrionUser);
            } else {
                nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab].ajax
                    .reload(); // If the DataTable is already initialized, reload the data
            }
        });

        $(document).on('click', '.nebula_filter_search', function(e) {
            e.preventDefault();

            var selectedDepartment = $('.list-page-filters #department_filter_value').val() || '';
            var selectedType = $('#type_filter_value').val() || '';
            var selectedStatus = $('.list-page-filters #nebula_status_filter_list').val() || '';
            var selectedCreatedUpdated = $('#nebula_select_date_wise_filter_value').val() || '';

            var report_start_end_date = $('#nebula_daterange').val() || '';
            var dateParts = report_start_end_date.split(' to ');

            // Assign the parts to two separate variables
            var report_start_date = dateParts[0];
            var report_end_date = dateParts[1];

            filter_global.selectedDepartment = selectedDepartment;
            filter_global.selectedType = selectedType;
            filter_global.selectedStatus = selectedStatus;
            filter_global.selectedCreatedUpdated = selectedCreatedUpdated;

            filter_global.report_start_date = report_start_date;
            filter_global.report_end_date = report_end_date;

            if (nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab]) {
                initDataTable(nebula_dashboard_list_activeTab, filter_global, selectedOrionUser);
            }
        });

        $('#clear_nebula_filters').on('click', function() {
            
            $('#type_filter_value').prop('selectedIndex', 0); // Reset to the first option

            $('#nebula_select_date_wise_filter_value').prop('selectedIndex', 0);

            $('.list-page-filters #department_filter_value').val(''); // Clears all selected options
            $('.list-page-filters #department_filter_value').trigger(
                'change'); // Triggers change event to update the select2 dropdown

            $('.list-page-filters #nebula_status_filter_list').val(''); // Clears all selected options
            $('.list-page-filters #nebula_status_filter_list').trigger(
                'change'); // Triggers change event to update the select2 dropdown

            $('#nebula_daterange').val(''); // Reset to balnk

            // Reset the filter_global object to its initial state
            filter_global.selectedDepartment = '';
            filter_global.selectedType = '';
            filter_global.selectedStatus = '';
            filter_global.selectedCreatedUpdated = '';
            filter_global.report_start_end_date = '';

            nebula_dashboard_list_oTable[nebula_dashboard_list_activeTab].ajax.reload();

        });

        $(document).on('change', '.orion-user-list #orion-user-select', function(e) {
            selectedOrionUser = $(this).val();
            // alert(selectedOrionUser);
            initDataTable(nebula_dashboard_list_activeTab, filter_global, selectedOrionUser);

        });

        function initDataTable(tabId, filter_global, selectedOrionUser) {

            addOverlay();
            // Destroy the previous DataTable instance if it exists
            if ($.fn.dataTable.isDataTable('#' + tabId + ' .show_list_table')) {
                $('#' + tabId + ' .show_list_table').DataTable().clear().destroy();
                console.log('Existing DataTable destroyed');
            }
            nebula_dashboard_list_oTable[tabId] = $('#' + tabId + ' .show_list_table').DataTable({
                "responsive": false,
                "processing": true,
                "serverSide": true,
                "order": [],
                "iDisplayLength": 50,
                "lengthMenu": [50, 100, 200, 300, 500, 'All'],
                "ajax": {
                    "url": ADMIN_URL + "Nebula_dashboard/show_list_ajax",
                    "data": function(d) {
                        // Add tab ID as a parameter to the AJAX request
                        d.tab_id = tabId; // Send current tab ID to URL 
                        d.filter_type = filter_global;
                        d.selectedOrionUser = selectedOrionUser;
                    }
                },
                "columns": [
                    {"data": "action", searchable: false, sortable: false, "width": "3%" },
                    {"data": "ticket_id", searchable: true, sortable: true, "width": "6%" },
                    {"data": "purpose", searchable: true, sortable: true, "width": "6%" },
                    {"data": "priority", searchable:  false, sortable: true, "width": "6%" },
                    // {"data": "notes", searchable: true, sortable: true, "width": "10%"},
                    {"data": "title", searchable: true, sortable: true, "width": "12%" },
                    {"data": "orion_department", searchable: false, sortable: true, "width": "9%" },
                    {"data": "orion_module", searchable: false, sortable: true, "width": "12%" },
                    // {"data": "sw_tl_id", searchable: false, sortable: true, "width": "5%"},
                    {"data": "trainer_id", searchable: true, sortable: true, "width": "8%" },
                    {"data": "status_type", searchable: false, sortable: true, "width": "7%" },
                    {"data": "ticket_tags", searchable: false, sortable: true, "width": "10%" },
                    {"data": "created", searchable: false, sortable: true, "width": "8%" },
                    {"data": "updated", searchable: false, sortable: true, "width": "8%" },
                    {"data": "created_by", searchable: false, sortable: true, "width": "7%" },
                ],
                columnDefs: [{
                        "defaultContent": "-",
                        "targets": "_all"
                    },
                    {
                        "targets": [11], // Columns with indexes 11 will be hidden by default
                        "visible": false // Hide these columns initially
                    }
                ],
                "buttons": buttonsConfig,
                drawCallback: function(settings) {

                    $('.status_type').each(function() {
                        var status_stage = $(this).val();
                        if (status_stage == 'open') {
                            $(this).css({
                                'background-color': '#f1f1f1',
                                'color': '#333',
                                'border-color': '#333'
                            });
                        } else if (status_stage == 'assigned') {
                            $(this).css({
                                'background-color': '#fff9f2',
                                'color': '#d17c0f',
                                'border-color': '#d17c0f'
                            });
                        } else if (status_stage == 'closed') {
                            $(this).css({
                                'background-color': '#f6fdf9',
                                'color': '#22c56c',
                                'border-color': '#22c56c'
                            });
                        } else if (status_stage == 're_open') {
                            $(this).css({
                                'background-color': '#fbf5f9',
                                'color': '#b02381',
                                'border-color': '#b02381'
                            });
                        } else if (status_stage == 'in_progress') {
                            $(this).css({
                                'background-color': '#f6f9ff',
                                'color': '#1c5ecb',
                                'border-color': '#1c5ecb'
                            });
                        } else if (status_stage == 'on_hold') {
                            $(this).css({
                                'background-color': '#fff7f8',
                                'color': '#f73f50',
                                'border-color': '#f73f50'
                            });
                        } else {
                            $(this).css({
                                'background-color': '#9a90d3',
                                'color': '#ffffff',
                                'border-color': '#ffffff'
                            });
                        }
                    });

                    $('.change-ticket-priority').each(function() {
                        var priority_stage = $(this).val();
                        if (priority_stage == 'low') {
                            $(this).css({
                                'background-color': '#f6fdf9',
                                'color': '#22c56c',
                                'border-color': '#22c56c'
                            });
                        } else if (priority_stage == 'normal') {
                            $(this).css({
                                'background-color': '#fff9f2',
                                'color': '#d17c0f',
                                'border-color': '#d17c0f'
                            });
                        } else if (priority_stage == 'high') {
                            $(this).css({
                                'background-color': '#fff7f8',
                                'color': '#f73f50',
                                'border-color': '#f73f50'
                            });
                        }
                    });

                    //MY: Add Comment because make Purpose Value Dynamically
                    $('.change-ticket-purpose').each(function() {
                        var purpose_stage = $(this).val();
                        var element = $(this); // Store reference to the current element
                        if (Object.keys(ticket_purpose_types).length > 0) {
                            if (typeof ticket_purpose_types === "string") {
                                ticket_purpose_types = JSON.parse(ticket_purpose_types);
                            }
                            if (typeof ticketPurposeProperty === "string") {
                                ticketPurposeProperty = JSON.parse(ticketPurposeProperty);
                            }

                            $.each(ticket_purpose_types, function(keyType, valueType) {
                                if (purpose_stage == keyType) {
                                    element.css(ticketPurposeProperty[keyType]);
                                }
                            });
                        }
                    });
                    /* $('.change-ticket-purpose').each(function() {
                        var purpose_stage = $(this).val();
                        if (purpose_stage == 'bug_report') {
                            $(this).css({
                                'background-color': '#fff7f8',
                                'color': '#f73f50',
                                'border-color': '#f73f50'
                            });
                        } else if (purpose_stage == 'feature_request') {
                            $(this).css({
                                'background-color': '#fff9f2',
                                'color': '#d17c0f',
                                'border-color': '#d17c0f'
                            });
                        } else if (purpose_stage == 'training_request') {
                            $(this).css({
                                'background-color': '#f6fdf9',
                                'color': '#22c56c',
                                'border-color': '#22c56c'
                            });
                        } else if (purpose_stage == 'task_assign') {
                            $(this).css({
                                'background-color': '#f0f2fe',
                                'color': '#0504fb',
                                'border-color': '#0504fb'
                            });
                        }
                    }); */

                    localStorage.removeItem("filtertype");
                    select2refresh("list_assign_to_cls");

                    /* START - To return all tabs count */
                    var responseData = JSON.stringify(settings.json.get_all_tab_count, null, 2);
                    // console.log("settings " + responseData);
                    pie_chart_count_arr = responseData;
                    // pieChartTicketByStatus(settings.json.get_all_tab_count);
                    // console.log("parsedData : " + responseData);

                    // Parse the JSON string into an object
                    var parsedData = JSON.parse(responseData);

                    $.each(parsedData, function(key, value) {
                        // Get the count from parsedData using the key
                        var count = value;
                        // Update the HTML of elements with the corresponding class
                        $('.' + key + '_get_count').html(value);
                    });
                    /* END - To return all tabs count */
                }
            });
            removeOverlay();
        }
    });

    
function select2refresh(type = "") {

$("." + type + "").select2({
    multiple: true,
    closeOnSelect: true,
    placeholder: "Assign To",
    allowClear: false,
});
}

$(document).ready(function() {

// $('#nebula_daterange').daterangepicker({
//     autoApply: true,
//     singleDatePicker: false,
//     startDate: new Date(),
//     showDropdowns: false,
//     // timePicker: false,
//     // timePicker24Hour: false,
//     // timePickerIncrement: 10,
//     autoUpdateInput: true,
//     locale: {
//         format: 'YYYY-MM-DD',
//         separator: ' to ',
//     },
// });
// $('.daterangepicker-body h3').remove();

$('#nebula_daterange').daterangepicker({

    autoApply: true, // Automatically apply the date range
    opens: 'center', // Position the calendar at the center
    autoUpdateInput: false, // Prevent default date selection
    locale: {
        cancelLabel: 'Clear',
        format: 'YYYY-MM-DD', // Format of the date
        separator: ' to ', // Separator between start and end date
    },

}, function(start, end, label) {
    // console.log("label is : " + label);
  
    var startDate = start.format('YYYY-MM-DD'); // Format the start date
    var endDate = end.format('YYYY-MM-DD'); // Format the end date
    // console.log("Selected date range: " + startDate + " to " + endDate);
    $('#nebula_daterange').val(startDate + ' to ' + endDate);
});
// $('#nebula_daterange').val('');
// $('#nebula_daterange').datepicker('setDate', null);
$('.daterangepicker-body h3').remove();

});



</script>


