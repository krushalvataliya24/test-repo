<!-- /page header -->
<!-- Bootstrap Colorpicker CSS -->
<link rel="stylesheet" href="<?php echo base_url(ADM_CSS . 'nebula/bootstrap-colorpicker.min.css'); ?>">

<div class="page-header page-header-light">
  <div class="page-header-content header-elements-md-inline">
    <div class="page-title d-flex">
      <h4><?php echo $headTitle; ?></h4>
    </div>
  </div>
  <div class="bradcrumb-sec"><?php echo $bradcrumb; ?> </div>
</div>


<div class="content">

  <div class="row mb-10">
    <div class="col-2 custom-tab">
      <ul class="nav flex-column nav-pills neb-setting-tab" id="tabMenu" role="tablist">
        <li class="nav-item">
          <a class="nav-link nb" id="timezone-tab" data-toggle="pill" href="#timezone" role="tab" aria-controls="timezone" aria-selected="true"><i class="fa fa-calendar"></i> Timezone</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nb" id="working-hrs-tab" data-toggle="pill" href="#working-hrs" role="tab" aria-controls="working-hrs" aria-selected="false"><i class="fa fa-suitcase"></i> Working Hours</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nb" id="holiday-settings-tab" data-toggle="pill" href="#holiday-settings" role="tab" aria-controls="holiday-settings" aria-selected="false"><i class="fa fa-sun-o"></i> Holiday Settings</a>
        </li>
        <li class="nav-item">
          <a class="nav-link nb" id="module-mapping-tab" data-toggle="pill" href="#module-mapping" role="tab" aria-controls="module-mapping" aria-selected="false"><i class="fa fa-user"></i> Module Mapping</a>
        </li>
        <!-- Naman Start -->
        <li class="nav-item">
          <a class="nav-link nb" id="module-priority-tab" data-toggle="pill" href="#module-priority" role="tab" aria-controls="module-priority" aria-selected="false"><i class="fa fa-user"></i> Master
          </a>
        </li>
        <!-- Naman End -->

        <li class="nav-item">
          <a class="nav-link nb" id="module-userright-tab" data-toggle="pill" href="#module-userright" role="tab" aria-controls="module-userright" aria-selected="false"><i class="fa fa-user"></i> Nebula User Rights
          </a>
        </li>

      </ul>
    </div>
    <div class="col-10">
      <div class="tab-content" id="tabContent">
        <!-- Timezone, Date, Time -->
        <div class="tab-pane fade show " id="timezone" role="tabpanel" aria-labelledby="timezone-tab">
          <h5>Timezone, Date, Time</h5>
          <form class="form-horizontal" name="frmNebulaMapperTimezoneDateTime" id="frmNebulaMapperTimezoneDateTime" method="post" enctype="multipart/form-data">

            <input type="hidden" name="id" value="<?php echo $mapping_data['id']; ?>" />

            <div class="form-group row">

              <label class="col-md-2 control-label" for="nebula_time_zone"><?php echo $this->lang->line('lbl_nebula_time_zone') ?><?php echo MEND_SIGN; ?> : </label>

              <div class="form-group col-lg-4">
                <select class="custom-select nebula_time_zone select2" name="nebula_time_zone" id="nebula_time_zone" required>
                  <option>-- Select Timezone --</option>
                  <?php foreach ($getTimezones as $timezone_k => $timezone_v) { ?>
                    <option value="<?= $timezone_k ?>" <?php echo ($timezone_k == $getTimezoneDateTime['timezone']) ? 'selected' : ''; ?>><?= $timezone_v ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

            <div class="form-group row">

              <label class="col-md-2 control-label" for="nebula_date_formatter"><?php echo $this->lang->line('lbl_nebula_date_formatter') ?><?php echo MEND_SIGN; ?> : </label>

              <div class="form-group col-lg-4">
                <select class="custom-select nebula_date_formatter select2" name="nebula_date_formatter" id="nebula_date_formatter" required>
                  <option>-- Select Date Format --</option>
                  <?php foreach ($getDateFormat as $dateformat_k => $dateformat_v) { ?>
                    <option value="<?= $dateformat_k ?>" <?php echo ($dateformat_k == $getTimezoneDateTime['date_format']) ? 'selected' : ''; ?>><?= $dateformat_v ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

            <div class="form-group row">

              <label class="col-md-2 control-label" for="nebula_time_formatter"><?php echo $this->lang->line('lbl_nebula_time_formatter') ?><?php echo MEND_SIGN; ?> : </label>

              <div class="form-group col-lg-4">
                <select class="custom-select nebula_time_formatter select2" name="nebula_time_formatter" id="nebula_time_formatter" required>
                  <option>-- Select Time Format --</option>
                  <?php foreach ($getTimeFormat as $timeformat_k => $timeformat_v) { ?>
                    <option value="<?= $timeformat_k ?>" <?php echo ($timeformat_k == $getTimezoneDateTime['time_format']) ? 'selected' : ''; ?>><?= $timeformat_v ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

            <div class="form-actions">
              <div class="row">
                <div class="col-lg-6 text-right">
                  <button type="submit" class="btn btn-primary" id="btn-submit-dev"><?php echo $this->lang->line('nebula_lbl_save'); ?></button>
                </div>
              </div>
            </div>
          </form>

        </div>
        <!-- Working Hours -->
        <div class="tab-pane fade mb-5" id="working-hrs" role="tabpanel" aria-labelledby="working-hrs-tab">
          <h5>Working Hours</h5>
          <form class="form-horizontal" name="frmNebulaMapperWorkingHrs" id="frmNebulaMapperWorkingHrs" method="post" enctype="multipart/form-data">



            <!-- Monday -->
            <div class="form-group row align-items-center weekday-time" data-day="monday">
              <label class="col-1 col-form-label">Monday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data)) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['monday']) && $working_hrs_data['monday']['weekday_status'] == 'open') {
                    $get_status = 'Open';
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['monday']['start_time'];
                    $end_time = $working_hrs_data['monday']['end_time'];
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['monday']) && $working_hrs_data['monday']['weekday_status'] == 'closed') {
                    $is_checked = '';
                    $start_time = $working_hrs_data['monday']['start_time'];
                    $end_time = $working_hrs_data['monday']['end_time'];
                    $is_disabled = 'disabled';
                    $get_status = 'Closed';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> monday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="monday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center time-fields">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="monday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <!-- Tuesday -->
            <div class="form-group row align-items-center weekday-time" data-day="tuesday">
              <label class="col-1 col-form-label">Tuesday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data)) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['tuesday']) && $working_hrs_data['tuesday']['weekday_status'] == 'open') {
                    $get_status = 'Open';
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['tuesday']['start_time'];
                    $end_time = $working_hrs_data['tuesday']['end_time'];
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['tuesday']) && $working_hrs_data['tuesday']['weekday_status'] == 'closed') {
                    $get_status = 'Closed';
                    $is_checked = '';
                    $start_time = $working_hrs_data['tuesday']['start_time'];
                    $end_time = $working_hrs_data['tuesday']['end_time'];
                    $is_disabled = 'disabled';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> tuesday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="tuesday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="tuesday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <!-- Wednesday -->
            <div class="form-group row align-items-center weekday-time" data-day="wednesday">
              <label class="col-1 col-form-label">Wednesday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data)) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['wednesday']) && $working_hrs_data['wednesday']['weekday_status'] == 'open') {
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['wednesday']['start_time'];
                    $end_time = $working_hrs_data['wednesday']['end_time'];
                    $get_status = 'Open';
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['wednesday']) && $working_hrs_data['wednesday']['weekday_status'] == 'closed') {
                    $is_checked = '';
                    $start_time = $working_hrs_data['wednesday']['start_time'];
                    $end_time = $working_hrs_data['wednesday']['end_time'];
                    $get_status = 'Closed';
                    $is_disabled = 'disabled';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> wednesday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="wednesday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="wednesday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <!-- Thursday -->
            <div class="form-group row align-items-center weekday-time" data-day="thursday">
              <label class="col-1 col-form-label">Thursday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data)) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['thursday']) && $working_hrs_data['thursday']['weekday_status'] == 'open') {
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['thursday']['start_time'];
                    $end_time = $working_hrs_data['thursday']['end_time'];
                    $get_status = 'Open';
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['thursday']) && $working_hrs_data['thursday']['weekday_status'] == 'closed') {
                    $is_checked = '';
                    $start_time = $working_hrs_data['thursday']['start_time'];
                    $end_time = $working_hrs_data['thursday']['end_time'];
                    $get_status = 'Closed';
                    $is_disabled = 'disabled';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> thursday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="thursday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="thursday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <!-- Friday -->
            <div class="form-group row align-items-center weekday-time" data-day="friday">
              <label class="col-1 col-form-label">Friday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data)) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['friday']) && $working_hrs_data['friday']['weekday_status'] == 'open') {
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['friday']['start_time'];
                    $end_time = $working_hrs_data['friday']['end_time'];
                    $get_status = 'Open';
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['friday']) && $working_hrs_data['friday']['weekday_status'] == 'closed') {
                    $is_checked = '';
                    $start_time = $working_hrs_data['friday']['start_time'];
                    $end_time = $working_hrs_data['friday']['end_time'];
                    $get_status = 'Closed';
                    $is_disabled = 'disabled';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> friday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="friday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="friday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <!-- Saturday -->
            <div class="form-group row align-items-center weekday-time" data-day="saturday">
              <label class="col-1 col-form-label">Saturday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data['saturday'])) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['saturday']) && $working_hrs_data['saturday']['weekday_status'] == 'open') {
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['saturday']['start_time'];
                    $end_time = $working_hrs_data['saturday']['end_time'];
                    $get_status = 'Open';
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['saturday']) && $working_hrs_data['saturday']['weekday_status'] == 'closed') {
                    $is_checked = '';
                    $start_time = $working_hrs_data['saturday']['start_time'];
                    $end_time = $working_hrs_data['saturday']['end_time'];
                    $get_status = 'Closed';
                    $is_disabled = 'disabled';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> saturday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="saturday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="saturday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <!-- Sunday -->
            <div class="form-group row align-items-center weekday-time" data-day="sunday">
              <label class="col-1 col-form-label">Sunday</label>
              <div class="col-1">
                <label class="switch">
                  <?php
                  if (empty($working_hrs_data['sunday'])) {
                    $is_checked = 'checked';
                    $is_disabled = '';
                    $get_status = 'Open';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['sunday']) && $working_hrs_data['sunday']['weekday_status'] == 'open') {
                    $get_status = 'Open';
                    $is_checked = 'checked';
                    $start_time = $working_hrs_data['sunday']['start_time'];
                    $end_time = $working_hrs_data['sunday']['end_time'];
                    $is_disabled = '';
                    $is_text_muted = 'text-primary';
                  } elseif (!empty($working_hrs_data['sunday']) && $working_hrs_data['sunday']['weekday_status'] == 'closed') {
                    $is_checked = '';
                    $start_time = $working_hrs_data['sunday']['start_time'];
                    $end_time = $working_hrs_data['sunday']['end_time'];
                    $is_disabled = 'disabled';
                    $get_status = 'Closed';
                    $is_text_muted = 'text-muted';
                  }
                  ?>
                  <input type="checkbox" <?= $is_checked ?>>
                  <span class="slider"></span>
                </label>
              </div>
              <div class="col-1 status-text <?= $is_text_muted ?> sunday_status"><?= $get_status ?></div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="sunday_start_time" value="<?= $start_time ?>" placeholder="11:00 AM" <?= $is_disabled ?>>
              </div>
              <div class="col-1 text-center time-fields">-</div>
              <div class="col-1 time-fields">
                <input type="text" class="form-control time-input" id="sunday_end_time" value="<?= $end_time ?>" placeholder="12:00 AM" <?= $is_disabled ?>>
              </div>
            </div>

            <div class="row mt-4">
              <div class="col-6 text-right">
                <!-- <button type="submit" class="btn btn-primary">Save</button> -->
                <button type="submit" class="btn btn-primary" id="btn-submit-dev"><?php echo $this->lang->line('nebula_lbl_save'); ?></button>
              </div>
            </div>
          </form>
        </div>
        <!-- Holiday Settings -->
        <div class="tab-pane fade" id="holiday-settings" role="tabpanel" aria-labelledby="holiday-settings-tab">
          <h5>Holiday Settings</h5>


          <form class="form-horizontal holiday_config_form_cls" id="holiday_config_form" method="post" action="javascript:void(0)" enctype="multipart/form-data">
            <div class="row align-items-end">
              <div class="col-lg-3">
                <label for="name">Date:<?php echo MEND_SIGN; ?> </label>
                <input type="text" name="column_qto_date_filter_nebula" id="column_qto_date_filter_nebula" value="" class="form-control column_date_filter_nebula_cls w-100">
              </div>

              <div class="col-lg-3">
                <div class="form-group m-0">
                  <label for="name">Holiday Markup:</label>
                  <div class="">
                    <input type="text" name="holiday_markup" id="holiday_markup" class="form-control holiday_markup_cls" placeholder="Please Enter Holiday Markup"></input>
                  </div>
                </div>
              </div>
              <div class="col-lg-3">
                <div class="form-group m-0">
                  <label for="name">Holiday</label>
                  <div class="">
                    <select class="form-control" name="country" id="country">
                      <option value="">--Select Holiday--</option>
                      <option value="india">Indian Holiday</option>
                      <option value="usa">US Holiday</option>
                    </select>
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-primary" id="btn-submit-dev" style="float:right;"><?php echo $this->lang->line('lbl_save'); ?></button>

            </div>

            <div class="row mt-2">
              <div class="col-md-6 holiday-settings">
                <ul class="nav nav-tabs w-100">
                  <li class="nav-item">
                    <a data-toggle="tab" class="nav-link active" href="#all_weekend_holiday_datatable"> All <span class="badge bg-dark all_weekend_and_holiday_get_count"></span></a>
                  </li>
                  <li class="nav-item">
                    <a data-toggle="tab" class="nav-link" href="#weekend_datatable">Weekend <span class="badge bg-success weekend_holiday_get_count"></span></a>
                  </li>
                  <li class="nav-item">
                    <a data-toggle="tab" class="nav-link" href="#all_holiday_datatable">Holiday <span class="badge bg-info all_holiday_get_count"></span></a>
                  </li>
                </ul>
                <!-- <select id="holiday_filter_value" class=" sorting-btn form-control col-lg-2 mr-1">
                    <option value="" selected>Select Holiday</option>
                    <option class="holiday_list_filter" value="india">India</option>
                    <option class="holiday_list_filter" value="us">US</option>
                    <option class="holiday_list_filter" value="both">Both</option>
                </select> -->

                <div class="tab-pane active px-2" id="all_weekend_holiday_datatable">
                  <div class="nebula-holiday-settings-table">
                    <table class="table table-bordered holiday_mapper_tbl" id="show_list_table_all_weekend_holiday_datatable" cellspacing="0" width="100%">
                      <thead style="position:sticky;top:0;z-index:9">
                        <tr style="background-color:#555;color:#fff">
                          <th width="5%">Date</th>
                          <th width="5%">Markup</th>
                          <th width="5%">Holiday</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
                </div>

              </div>
            </div>
          </form>

        </div>
        <div class="tab-pane fade" id="module-mapping" role="tabpanel" aria-labelledby="module-mapping-tab">
          <h5>Module Mapping</h5>
          <p>Not available now</p>

          <!-------------------------------------- START ADD BUTTON OF MODULE MAPPING ---------------------------------------------->



          <!-------------------------------------- END ADD BUTTON OF MODULE MAPPING ---------------------------------------------->


          <!-------------------------------------- START LIST OF MODULE MAPPING ----------------------------------------------------->



          <!-------------------------------------- END LIST OF MODULE MAPPING ----------------------------------------------------->

          <!-------------------------------------- START MODULE MAPPING FORM ------------------------------------------------------>



          <!-------------------------------------- END MODULE MAPPING FORM ----------------------------------------------------------------------->

        </div>
        <!-- priorty -->
        <div class="tab-pane fade" id="module-priority" role="tabpanel" aria-labelledby="module-priority-tab">
          <div class="d-flex w-100">
              <div class="w-100">
                  <ul class="nav nav-tabs w-100">
                      <li class="nav-item">
                          <a data-toggle="tab" class="nav-link nebula_dashboard_chart_a" id="prtTab"
                              href="#nebula_priority_master">Priority <span class="badge bg-secondary"></span>
                          </a>
                      </li>
                      <li class="nav-item">
                          <a data-toggle="tab" class="nav-link purpose_dashboard_a" href="#nebula_purpose_master">Purpose 
                            <span class="badge bg-info open_get_count"></span>
                          </a>
                      </li>
                      <?php /* ?><li class="nav-item">
                          <a data-toggle="tab" class="nav-link" href="#nebula_department_master">Department <span
                                  class="badge bg-primary assigned_get_count"></span></a>
                      </li><?php */ ?>
                  </ul>
                  <!-- Tab panes -->

                  <div class="tab-content position-relative">
                    <div class="tab-pane active px-2 nebula_dashboard_chart" id="nebula_priority_master">
                        <form class="form-horizontal priority_form_cls" id="priority_form" method="post" action="javascript:void(0)" enctype="multipart/form-data">
                          <h5>Priority Master</h5>
                          <div class="col-lg-3">
                            <div class="form-group m-0">
                              <label for="priority">Priority:</label>
                              <div>
                                <input type="text" name="priority" id="priority_setting" class="form-control priority_cls" placeholder="Please Enter Priority" required>
                              </div>
                            </div>
                          </div>
                          <br>
                          <button type="submit" class="btn btn-primary primority-master-saved" id="btn-submit-dev" style="float:left;"><?php echo $this->lang->line('lbl_save'); ?></button>
                        </form>
                        <br>
                        <div id="priority-table-container" class="mt-4">
                              <table class="table-data1 table-bordered mt-2 modu_priority_tbl">
                                <thead style="background-color:#555;color:#fff">
                                  <tr>
                                    <th>Priority</th>
                                    <th>Created On</th>
                                    <th>Action</th>
                                  </tr>
                                </thead>
                                <tbody>
                                <?php if (!empty($get_all_priorities)) { ?>
                                  
                                  <?php foreach ($get_all_priorities as $priority_k => $priority_v) :  ?>
                                    <tr>
                                      <td class="priority-cell"><?= $priority_v['priority']; ?></td>
                                      <td><?= $priority_v['created']; ?></td>
                                      <td>
                                        <button class="edit-button btn btn-primary btn-small" data-id="<?= $priority_v['id']; ?>" data-priority="<?= $priority_v['priority']; ?>">
                                          <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                        </button>
                                        <button class="delete-button btn btn-danger btn-small" data-id="<?= $priority_v['id']; ?>">
                                          <i class="fa fa-trash-o" aria-hidden="true"></i>
                                        </button>
                                      </td>
                                    </tr>
                                  <?php endforeach; ?>
                                <?php } ?>
                            </tbody>
                          </table>
                      </div>

                    </div>
                    <div class="tab-pane  px-2" id="nebula_purpose_master">
                      <form class="form-horizontal purpose_form_cls" id="purpose_form" method="post" action="javascript:void(0)" enctype="multipart/form-data">
                        <h5>Purpose Master</h5>
                        
                          <div class="row">
                            <div class="col-lg-2">
                              <div class="form-group mt-2 m-0">
                                <label for="purpose">Purpose:</label>
                                <div>
                                  <input type="text" name="purpose" id="purpose_setting" class="form-control purpose_cls" placeholder="Please Enter Purpose" required>
                                </div>
                              </div>
                            </div>
                            <div class="col-lg-2">
                              <div class="form-group mt-2 mb-0">
                                <label for="background_color">Background Color:</label>
                              </div>
                              <div class="input-group color-picker-component">
                                  <input type="text" name="background_color" id="background_color" class="form-control color-text-cls" placeholder="Please Enter Background Color" required>
                                  <div class="input-group-append">
                                      <span class="input-group-text"><i></i></span>
                                  </div>
                              </div>
                            </div>
                            <div class="col-lg-2">
                              <div class="form-group mt-2 mb-0">
                                <label for="font_color">Font Color:</label>
                              </div>
                              <div class="input-group color-picker-component">
                                  <input type="text" name="font_color" id="font_color" class="form-control color-text-cls" placeholder="Please Enter Font Color" required>
                                  <div class="input-group-append">
                                      <span class="input-group-text"><i></i></span>
                                  </div>
                              </div>
                            </div>
                            <div class="col-lg-2">
                              <div class="form-group mt-2 mb-0">
                                <label for="border_color">Border Color:</label>
                              </div>
                              <div class="input-group color-picker-component">
                                <input type="text" name="border_color" id="border_color" class="form-control color-text-cls" placeholder="Please Enter Border Color" required>
                                <div class="input-group-append">
                                    <span class="input-group-text"><i></i></span>
                                </div>
                              </div>
                            </div>
                          </div>
                        <br>
                        <button type="submit" class="btn btn-primary" id="btn-submit-purpose" style="float:left;"><?php echo $this->lang->line('lbl_save'); ?></button>
                      </form>
                      <br>
                      <div id="purpose-table-container" class="mt-4">
                        <table class="table-data1 table-bordered mt-2 modu_priority_tbl" style="width: 68%;">
                          <thead style="background-color:#555;color:#fff">
                            <tr>
                              <th>Purpose</th>
                              <th>Background Color</th>
                              <th>Font Color</th>
                              <th>Border Color</th>
                              <th>Created On</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                              if (!empty($get_all_purpose)) {
                                $getPurposeData = json_decode($get_all_purpose['mst_data'], true);
                                $getPurposePropertyData = json_decode($get_all_purpose_property['mst_data'], true);
                                if (!empty($getPurposeData['purpose'])) {
                                  $getPurposePropertyData = $getPurposePropertyData['purpose_property'];
                                  foreach ($getPurposeData['purpose'] as $key => $purposeVal) {
                                    $backgroundColor = $fontColor = $borderColor = "";
                                    if ($getPurposePropertyData) {
                                        $backgroundColor = $getPurposePropertyData[$key]['background-color'];
                                        $fontColor = $getPurposePropertyData[$key]['color'];
                                        $borderColor = $getPurposePropertyData[$key]['border-color'];
                                    }
                            ?>
                                <tr>
                                  <td><?=$purposeVal;?></td>
                                  <td class="pur-back-color text-center"><?=$backgroundColor;?><div class="input-group-append justify-content-center"><span class="input-group-text" style="background-color: <?=$backgroundColor;?>"><i></i></span></div></td>
                                  <td class="pur-font-color text-center"><?=$fontColor;?><div class="input-group-append justify-content-center"><span class="input-group-text" style="background-color: <?=$fontColor;?> "><i></i></span></div></td>
                                  <td  class="pur-border-color text-center"><?=$borderColor;?><div class="input-group-append justify-content-center"><span class="input-group-text" style="background-color:<?=$borderColor;?>"><i></i></span></div></td>
                                  <td><?=$get_all_purpose['created'];?></td>
                                  <td>
                                      <button class="edit-button-purpose edit-purpose-btn btn btn-primary btn-small" data-id="<?= $get_all_purpose['id']; ?>" data-purpose="<?= $purposeVal; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                      <button class="delete-button-purpose btn btn-danger btn-small" data-purpose="<?= $purposeVal; ?>" data-id="<?= $get_all_purpose['id']; ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                                  </td>
                                </tr>
                        <?php
                                  }
                                } else {
                                  echo "<tr style='text-align: center;'><td colspan='6'>Data not found</td></tr>"; 
                                }
                              } else {
                                echo "<tr style='text-align: center;'><td colspan='6'>Data not found</td></tr>"; 
                              }?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="tab-pane px-2" id="nebula_department_master">
                        Department Master
                    </div>
                  </div>
              </div>
          </div>
        </div>

        <!-- Nebula User Rights  -->
        <div class="tab-pane fade" id="module-userright" role="tabpanel" aria-labelledby="module-userright-tab">

          <form class="form-horizontal" name="frmNebulaUserRights" id="frmNebulaUserRights" method="post" enctype="multipart/form-data">

            <div class="form-group row">
              <label class="col-md-2 control-label" for="nebula_selected_user">Select User <?php echo MEND_SIGN; ?>: </label>
              <div class="form-group col-lg-4">
                <select class="custom-select nebula_selected_user select2" name="nebula_selected_user" id="nebula_selected_user" required>
                  <option>-- Select User --</option>
                  
                    <?php echo $nebual_user_right_list; ?>

                </select>
              </div>
            </div>
            
            <div class="form-group row">
                <label class="col-md-2 control-label" for="nebula_selected_tab">Select Tab: </label>
                <div class="form-group col-lg-4">
                    <label class="checkbox-inline"><input type="checkbox" value="every_tab" id="every_tab" name="tab_option[]">Every Tab</label>
                    <label class="checkbox-inline"><input type="checkbox" value="all_tab" id="all_tab" name="tab_option[]">All Tab</label>
                </div>
            </div>

            <div class="form-group row" id="nebula_user_rights_ticket">
                <label class="col-md-2 control-label" for="nebula_selected_ticket">Select Ticket: </label>
                <div class="form-group col-lg-4">
                    <label class="checkbox-inline"><input type="checkbox" value="own_ticket" id="own_ticket" name="ticket_option[]">Own Ticket</label>
                    <label class="checkbox-inline"><input type="checkbox" value="own_department_ticket" id="own_department_ticket" name="ticket_option[]">Own Department Ticket</label>
                    <label class="checkbox-inline"><input type="checkbox" value="all_department_ticket" id="all_department_ticket" name="ticket_option[]">All Department Ticket</label>
                </div>
            </div>

            <div class="form-group row" id="nebula_user_rights_filters">
                <label class="col-md-2 control-label" for="nebula_selected_filters">Select Filters: </label>
                <div class="form-group col-lg-4">
                    <label class="checkbox-inline"><input type="checkbox" value="nebula_dept_filter" id="nebula_dept_filter" name="filter_option[]">Department</label>
                    <label class="checkbox-inline"><input type="checkbox" value="nebula_ticket_type_filter" id="nebula_ticket_type_filter" name="filter_option[]">Ticket Type</label>
                    <label class="checkbox-inline"><input type="checkbox" value="nebula_status_filter" id="nebula_status_filter" name="filter_option[]">Status</label>
                    <label class="checkbox-inline"><input type="checkbox" value="nebula_created_updated_filter" id="nebula_created_updated_filter" name="filter_option[]">Created/Updated</label>
                    <label class="checkbox-inline"><input type="checkbox" value="nebula_datewise_filter" id="nebula_datewise_filter" name="filter_option[]">Date</label>
                </div>
            </div>

            <!-- Export excel option -->
            <div class="form-group row" id="nebula_user_rights_export_rights">
                <label class="col-md-2 control-label" for="nebula_selected_exports">Export Option: </label>
                <div class="form-group col-lg-4">
                  <label class="checkbox-inline"><input type="checkbox" value="nebula_export_excel_filter" id="nebula_export_excel_filter" name="export_option[]">Export Excel</label>
                </div>
            </div>

            <!-- dashborad_list_columns -->
            <div class="form-group row" id="nebula_user_rights_ticket_conversions">
                <label class="col-md-2 control-label" for="nebula_selected_conversions">Ticket Conversions: </label>
                <div class="form-group col-lg-4">
                    <label class="checkbox-inline"><input type="checkbox" value="ticket_conversions_type_filter" id="ticket_conversions_type_filter" name="ticket_conversions_option[]">Ticket Type</label>
                    <label class="checkbox-inline"><input type="checkbox" value="ticket_conversions_priority_filter" id="ticket_conversions_priority_filter" name="ticket_conversions_option[]">Ticket Priority</label>
                    <label class="checkbox-inline"><input type="checkbox" value="ticket_conversions_assign_to_filter" id="ticket_conversions_assign_to_filter" name="ticket_conversions_option[]">Assign To</label>
                    <label class="checkbox-inline"><input type="checkbox" value="ticket_conversions_status_filter" id="ticket_conversions_status_filter" name="ticket_conversions_option[]">Ticket Status</label>
                </div>
            </div>

            <!-- <div class="form-group row">
                <label class="col-md-2 control-label" for="nebula_selected_post">Select Post: </label>
                <div class="form-group col-lg-4">
                    <label class="checkbox-inline"><input type="checkbox" value="bug" id="bug_post" name="post_option[]">Bug</label>
                    <label class="checkbox-inline"><input type="checkbox" value="training" id="training_post" name="post_option[]">Training</label>
                    <label class="checkbox-inline"><input type="checkbox" value="feature" id="feature_post" name="post_option[]">Feature</label>
                </div>
            </div> -->

            <div class="form-actions">
              <div class="row">
                <div class="col-lg-6 text-right">
                  <button type="submit" class="btn btn-primary" id="btn-submit-dev"><?php echo $this->lang->line('nebula_lbl_save'); ?></button>
                </div>
              </div>
            </div>
          </form>

          <div class="col-lg-12 nebula_users_list">
            <table class="table admin-list-table" id="listNebulaUsers" width="100%">
              <thead>
                <tr>
                  <th><?php echo $this->lang->line('lbl_sr_no') ?></th>
                  <th><?php echo $this->lang->line('lbl_user_name') ?></th>
                  <th><?php echo $this->lang->line('lbl_user_email') ?></th>
                  <th><?php echo $this->lang->line('lbl_username') ?></th>
                  <th><?php echo $this->lang->line('lbl_user_role') ?></th>
                  <th width="1%" style="width:auto !important; max-width: 1%;"><?php echo $this->lang->line('lbl_operation') ?></th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>


      </div>
    </div>
    <!-- <div class="nebula-footer text-left">Footer</div> -->
    <div class="nebula-footer text-left"><?= $todays_ticket_count ?></div>


    <div class="modal fade" id="modal_purpose" tabindex="-1" role="dialog" aria-labelledby="modalPurposeTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                
                <!-- Modal Header -->
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalPurposeTitle">Edit Purpose</h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                
                <!-- Modal Body -->
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="modal_purpose_text">Purpose</label>
                            <input type="text" class="form-control" name="modal_purpose_text" id="modal_purpose_text" placeholder="Enter purpose">
                        </div>

                        <div class="form-group">
                            <label for="modal_background_color">Background Color</label>
                            <div class="input-group color-picker-component">
                              <input type="text" class="form-control color-text-cls" name="modal_background_color" id="modal_background_color" placeholder="Enter background color">
                              <div class="input-group-append">
                                  <span class="input-group-text"><i></i></span>
                              </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="modal_font_color">Font Color</label>
                            <div class="input-group color-picker-component">
                              <input type="text" class="form-control color-text-cls" name="modal_font_color" id="modal_font_color" placeholder="Enter font color">
                              <div class="input-group-append">
                                  <span class="input-group-text"><i></i></span>
                              </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="modal_border_color">Border Color</label>
                            <div class="input-group color-picker-component">
                            <input type="text" class="form-control color-text-cls" name="modal_border_color" id="modal_border_color" placeholder="Enter border color">
                              <div class="input-group-append">
                                  <span class="input-group-text"><i></i></span>
                              </div>
                            </div>
                        </div>
                    </form>
                </div>
                
                <!-- Modal Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="edit_modal_purpose">Save</button>
                </div>

            </div>
        </div>
    </div>


    <!-- /vertical form options -->

  </div>

  <?php //get_script_tag('nebula_modules_mapping.js'); 
  ?>
<!-- Bootstrap Colorpicker JS -->
<script src="<?= base_url('themes/admin/scripts/nebula/bootstrap-colorpicker.min.js'); ?>"></script>
  <script>
    
   
// Saurabh session reset for active Tab
    $(document).ready(function() {
    // Check if the page was reloaded (not a new page load)
    if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
        sessionStorage.clear();
    } else {
      $('#prtTab').addClass('active show');
      $('.nebula_dashboard_chart ').addClass('active show');
    }
});

    var oTable = {};
    var activeTab = 'all_weekend_holiday_datatable';

    function holiday_mapper_datatbl(tabId, holiday_filter_val) {

      if ($.fn.dataTable.isDataTable('#show_list_table_all_weekend_holiday_datatable')) {
        $('#show_list_table_all_weekend_holiday_datatable').DataTable().clear().destroy();
        console.log('Existing DataTable destroyed');
      }

      //oTable[tabId] = $('#' + tabId + ' .holiday_mapper_tbl').DataTable({
      oTable = $('#show_list_table_all_weekend_holiday_datatable').DataTable({
        // "dom": 'lrtip', 
        "processing": true,
        "serverSide": true,
        "order": [],
        "pageLength": 10,
        "ajax": {
          "url": ADMIN_URL + "Nebula_mapper/lists_holiday_mapper/",
          "data": function(d) {
            d.tab_id = tabId;
            d.holiday_filter_val = holiday_filter_val;
          }
        },
        "columns": [{
            "data": "date",
            searchable: false,
            sortable: false
          },
          // {"data": "day",searchable: false, sortable: false},
          {
            "data": "holiday_markup",
            searchable: false,
            sortable: false
          },
          {
            "data": "country",
            searchable: false,
            sortable: false
          },
        ],
        "columnDefs": [{
          "defaultContent": "-",
          "targets": "_all"
        }],
        drawCallback: function(oSettings) {

          /* START - To return all tabs count */
          var responseData = oSettings.json.getHolidayTabCount;

          var parsedData = typeof responseData === 'string' ? JSON.parse(responseData) : responseData;

          $.each(parsedData, function(key, value) {
            // Get the count from parsedData using the key
            var count = value;
            console.log("keys : " + key + ", " + "values : " + value);
            // Update the HTML of elements with the corresponding class
            $('.' + key + '_get_count').html(value);
          });
          /* END - To return all tabs count */

        }
      });

      // Custom CSS for borders
      $('.holiday_mapper_tbl').css({
        'border': '1px solid #ccc',
      });

      $('.holiday_mapper_tbl th, .holiday_mapper_tbl td').css({
        'border': '1px solid #ddd',
      });

    }

    $(document).ready(function() {


      var holiday_filter_val = '';



      $('.holiday-settings #holiday_filter_value').change(function() {

        var filter_value = $(this).val();
        holiday_filter_val = filter_value;
        holiday_mapper_datatbl(activeTab, holiday_filter_val);
      });



      holiday_mapper_datatbl('all_weekend_holiday_datatable', holiday_filter_val);

      $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        activeTab = $(e.target).attr('href').substring(1);

        console.log("change tab : " + activeTab);
        if (!oTable[activeTab]) {

          holiday_mapper_datatbl(activeTab, holiday_filter_val);
        } else {
          oTable[activeTab].ajax.reload(); // If the DataTable is already initialized, reload the data
        }
      });

    });

    $(document).on('submit', '#holiday-settings .holiday_config_form_cls', function(e) {

      e.preventDefault();
      var formData = new FormData($('#holiday-settings .holiday_config_form_cls')[0]);

      var selectedDate = $('input.column_date_filter_nebula_cls').data('date'); // Get the selected date
      var selectedDay = $('input.column_date_filter_nebula_cls').data('day'); // Get the stored day
      var holiday_markup = $(".holiday_config_form_cls #holiday_markup").val();

      if (selectedDate == undefined) {
        sTitle = '';
        sType = getStatusText(404);
        sText = "Please select Date";
        Custom.myNotification(sType, sText);
        return false;
      }


      // Append extra data to the FormData object
      formData.append('date', selectedDate);
      formData.append('day', selectedDay);
      formData.append('holiday_markup', holiday_markup);

      addOverlay();
      $.ajax({
        type: 'post',
        data: formData,
        url: ADMIN_URL + 'Nebula_mapper/holiday_configuration_submit',
        dataType: "json",
        processData: false,
        contentType: false,
        success: function(r) {
          if (r.status == 200) {
            sTitle = '';
            sType = getStatusText(r.status);
            sText = r.message;
            Custom.myNotification(sType, sText);
            // Reset the text box and date picker after success
            $('input.column_date_filter_nebula_cls').val(''); // Clear the value
            $('input.column_date_filter_nebula_cls').data('day', ''); // Reset the stored day
            $('input.column_date_filter_nebula_cls').data('date', ''); // Reset the stored date
            $('input.holiday_markup_cls').val(''); // Clear the value
            window.location.href = ADMIN_URL + "Nebula_mapper";
            holiday_mapper_datatbl();
          } else {
            sTitle = '';
            sType = getStatusText(r.status);
            sText = r.message;
            Custom.myNotification(sType, sText);
          }
        },
        complete: removeOverlay
      });
    });

    $('input.column_date_filter_nebula_cls').Zebra_DatePicker({
      format: 'm/d/Y',
      direction: 'next',
      onSelect: function(date) {
        var dateObj = new Date(date);
        var options = {
          weekday: 'long'
        };
        var dayOfWeek = dateObj.toLocaleDateString('en-US', options); // Get the day of the week
        $(this).val(dayOfWeek + ', ' + date); // Display day + date
        $(this).data('day', dayOfWeek);
        $(this).data('date', date);
      }
    });

    $(document).ready(function() {
      $(".select2").select2();
    });



    $(document).ready(function() {
        $('#priority_form').on('submit', function(e) {
          e.preventDefault();
          var priority = $('#priority_setting').val();
          var formData = {
            priority: priority
          };
          addOverlay();
          $.ajax({
            url: ADMIN_URL + 'Nebula_mapper/priority_submit',
            method: 'POST',
            data: formData,
            dataType: "json",
            success: function(r) {

              $('#priority_setting').val('');
              if (r.status == 200) {
                sType = getStatusText(r.status);
                sText = r.message;
                Custom.myNotification(sType, sText);

                // Store the active classes in sessionStorage after success
                sessionStorage.setItem('activeClassesPriority', JSON.stringify({
                  purposeDashboardActive: true,
                  nebulaPurposeMasterActive: true
                  
                }));
                window.location.href = ADMIN_URL + "Nebula_mapper";
              } else {
                sType = getStatusText(r.status);
                sText = r.message;
                Custom.myNotification(sType, sText);
              }

            },
            complete: function() {
              removeOverlay();
            },
            error: function(xhr, status, error) {
              console.log(xhr.rText);
            }
          });
        });
    });

// Saurabh:- Priority form submit added to session to update data in table without refresh
  $(document).ready(function() {
    // Check if there are stored classes in sessionStorage
      let activeClassesPriority = sessionStorage.getItem('activeClassesPriority');
      if (activeClassesPriority) {
        activeClassesPriority = JSON.parse(activeClassesPriority);

        // If the classes were saved, add them again to the elements
        if (activeClassesPriority.purposeDashboardActive) {
          $('.nebula_dashboard_chart_a  ').addClass('active show');
          $('.purpose_dashboard_a ').removeClass('active show');
        }
        if (activeClassesPriority.nebulaPurposeMasterActive) {
          $('.nebula_dashboard_chart ').addClass('active show');
          $('#nebula_purpose_master').removeClass('active show');
        }
        sessionStorage.removeItem('activeClassesPriority');
      }
  });
  // End priority form submit



// saurabh submit without reload purpose master
  $(document).ready(function() {
  $('#btn-submit-purpose').click(function() {

    $('#purpose_form').on('submit', function(e) {
      e.preventDefault();
      var purpose = $('#purpose_setting').val();
      var formData = new FormData(this);
      formData.append("action", "insert");
      addOverlay();

      $.ajax({
        url: ADMIN_URL + 'Nebula_mapper/purpose_submit',
        method: 'POST',
        data: formData,
        dataType: "json",
        processData: false,
        contentType: false,
        success: function(r) {
          $('#purpose_setting').val('');
          if (r.status == 200) {
            sType = getStatusText(r.status);
            sText = r.message;
            Custom.myNotification(sType, sText);

            // Store the active classes in sessionStorage after success
            sessionStorage.setItem('activeClasses', JSON.stringify({
              purposeDashboardActive: true,
              nebulaPurposeMasterActive: true
              
            }));

            // Redirect to another page or reload
            window.location.href = ADMIN_URL + "Nebula_mapper"; // Redirect after submission
           
          } else {
            sType = getStatusText(r.status);
            sText = r.message;
            Custom.myNotification(sType, sText);
          }
        },
        complete: function() {
          removeOverlay();
        },
        error: function(xhr, status, error) {
          console.log(xhr.responseText);
        }
      });
    });

    // Add classes temporarily
     
    $('.purpose_dashboard_a ').addClass('active show');
    $('#nebula_purpose_master').addClass('active show');
    $('.nebula_dashboard_chart_a').removeClass('active show');
  });
});
//end

// Saurabh:- purpose_form submit added to session to update data in table without refresh
$(document).ready(function() {
  // Check if there are stored classes in sessionStorage
  let activeClasses = sessionStorage.getItem('activeClasses');
  
  if (activeClasses) {
    activeClasses = JSON.parse(activeClasses);

    // If the classes were saved, add them again to the elements
    if (activeClasses.purposeDashboardActive) {
      $('.purpose_dashboard_a ').addClass('active show');
      $('#prtTab').removeClass('active show');
      $('.nebula_dashboard_chart ').removeClass('active show');
    }
    
    if (activeClasses.nebulaPurposeMasterActive) {
      $('#nebula_purpose_master').addClass('active show');
      $('#nebula_priority_master').removeClass('active show');

    }
    sessionStorage.removeItem('activeClasses');
  }
});
//end purpose_form

// Saurabh edit and show data without reload functionality
  $('.edit-button').click(function() {
    var id = $(this).data('id');
    var oldPriority = $(this).data('priority');
    var newPriority = prompt("Update priority:", oldPriority);

    if (newPriority != null && newPriority !== "") {
      var formData = {
        id: id,
        newPriority: newPriority
      };

      $.ajax({
        url: ADMIN_URL + 'Nebula_mapper/priority_edit', 
        method: 'POST',
        data: formData,
        dataType: "json",
        success: function(r) {
          if (r.status == 200) {
            // Save the updated priority to localStorage
            localStorage.setItem('priority_' + id, newPriority);

            // Find the row containing the button and update the priority cell
            var row = $('button[data-id="' + id + '"]').closest('tr');
            var priorityCell = row.find('.priority-cell');

            // Update the priority cell text
            priorityCell.text(newPriority);

            // Optionally, update the button's data-priority attribute
            $('button[data-id="' + id + '"]').data('priority', newPriority);

            // Notify the user of the successful update
            Custom.myNotification('success', r.message);
          } else {
            Custom.myNotification('error', r.message);
          }
        },
        error: function(xhr, status, error) {
          console.log(xhr.responseText);
          Custom.myNotification('error', 'An error occurred while editing the priority.');
        }
      });
    } else {
      Custom.myNotification('error', 'Priority was not changed.');
    }
  });

    // On page load, check if there is any saved priority in localStorage and apply it
    $(document).ready(function() {
      // Loop through each row and check if the priority exists in localStorage
      $('button.edit-button').each(function() {
        var id = $(this).data('id');
        var savedPriority = localStorage.getItem('priority_' + id);

        if (savedPriority !== null) {
          // Find the row containing this button and update the priority cell
          var row = $(this).closest('tr');
          var priorityCell = row.find('.priority-cell');

          // Update the priority cell text with the saved value
          priorityCell.text(savedPriority);
        }
      });
    });
// End Saurabh edit and show data without reload functionality


    $('.delete-button').click(function() {
      var priority = $(this).data('priority');
      var id = $(this).data('id');
      if (confirm("Are you sure you want to delete this priority?")) {
        var formData = {
          id: id
        };
        $.ajax({
          url: ADMIN_URL + 'Nebula_mapper/priority_delete',
          method: 'POST',
          data: formData,
          dataType: "json",
          success: function(r) {
            if (r.status == 200) {
              $('button[data-id="' + id + '"]').closest('tr').remove();
              Custom.myNotification('success', r.message);
            } else {
              Custom.myNotification('error', r.message);
            }

          },
          error: function(xhr, status, error) {
            console.log(xhr.responseText);
            Custom.myNotification('error', 'An error occurred while deleting.');
          }
        });
      }
    });
    // Naman end for the edit and delete fun.

    //Delete Purpose Data
    $('.delete-button-purpose').click(function() {
      var purpose = $(this).data('purpose');
      var id = $(this).data('id');
      if (confirm("Are you sure you want to delete this purpose?")) {
        var formData = {
          action: 'delete',
          id: id,
          purpose: purpose
        };
        $.ajax({
          url: ADMIN_URL + 'Nebula_mapper/purpose_submit',
          method: 'POST',
          data: formData,
          dataType: "json",
          success: function(r) {
            if (r.status == 200) {
              $('button[data-purpose="' + purpose + '"]').closest('tr').remove();
              Custom.myNotification('success', r.message);
            } else {
              Custom.myNotification('error', r.message);
            }
          },
          error: function(xhr, status, error) {
            console.log(xhr.responseText);
            Custom.myNotification('error', 'An error occurred while deleting.');
          }
        });
      }
    });

    //Edit Purpose Data
    $('body').on('click','#edit_modal_purpose',function(){  
      var id = $("#modal_purpose #modal_purpose_text").data('id');
      var oldPurpose = $("#modal_purpose #modal_purpose_text").data('purpose');
      var newPurpose = $("#modal_purpose #modal_purpose_text").val();

      var backgroundColor = $("#modal_purpose #modal_background_color").val().trim();
      var fontColor = $("#modal_purpose #modal_font_color").val().trim();
      var borderColor = $("#modal_purpose #modal_border_color").val().trim();

      if (newPurpose != null && newPurpose !== "") {
        var formData = {
          action: 'edit',
          id: id,
          old_purpose: oldPurpose,
          new_purpose: newPurpose,
          background_color: backgroundColor,
          font_color: fontColor,
          border_color: borderColor,
        };

        $.ajax({
          url: ADMIN_URL + 'Nebula_mapper/purpose_submit',
          method: 'POST',
          data: formData,
          dataType: "json",
          success: function(r) {
            if (r.status == 200) {
              $('button[data-purpose="' + oldPurpose + '"]').closest('tr').find('.purpose-cell').text(newPurpose);
              Custom.myNotification('success', r.message);
              $("#modal_purpose").modal('hide');

              sessionStorage.setItem('activeClassesEdit', JSON.stringify({
              purposeDashboardActive: true,
              nebulaPurposeMasterActive: true
              
            }));

 
              window.location.href = ADMIN_URL + "Nebula_mapper";
            } else {
              Custom.myNotification('error', r.message);
            }
          },
          error: function(xhr, status, error) {
            Custom.myNotification('error', 'An error occurred while editing the purpose.');
          }
        });
      } else {
        Custom.myNotification('error', 'Purpose was not changed.');
      }
    });


// Saurabh:- edit_modal_purpose added to sessionStorage for update data without refresh
    $(document).ready(function() {
      // Check if there are stored classes in sessionStorage
      let activeClasses = sessionStorage.getItem('activeClassesEdit');
      
      if (activeClasses) {
        activeClasses = JSON.parse(activeClasses);

        // If the classes were saved, add them again to the elements
        if (activeClasses.purposeDashboardActive) {
          $('.purpose_dashboard_a ').addClass('active show');
          $('#prtTab').removeClass('active show');
          $('.nebula_dashboard_chart ').removeClass('active show');
        }
        
        if (activeClasses.nebulaPurposeMasterActive) {
          $('#nebula_purpose_master').addClass('active show');
          $('#nebula_priority_master').removeClass('active show');

        }
        sessionStorage.removeItem('activeClassesEdit');
      }
    });
  // End edit_modal_purpose




    // selected body for without reload edit
    // $(".edit-purpose-btn").click(function () {
      $("body").on("click",".edit-purpose-btn",function(){
        var closestRow = $(this).closest('tr');
        var getPurposeId = $(this).data('id');
        var getPurposeVal = $(this).data('purpose');
        $("#modal_purpose_text").data("id", getPurposeId);
        $("#modal_purpose_text").data("purpose", getPurposeVal);
        $("#modal_purpose_text").val(getPurposeVal);

        var backgroundColor = closestRow.find('td.pur-back-color').text().trim();
        var fontColor = closestRow.find('td.pur-font-color').text().trim();
        var borderColor = closestRow.find('td.pur-border-color').text().trim();

        $("#modal_background_color").val(backgroundColor);
        $("#modal_background_color").closest('.color-picker-component').find('.input-group-text').css('background-color', backgroundColor);

        $("#modal_font_color").val(fontColor);
        $("#modal_font_color").closest('.color-picker-component').find('.input-group-text').css('background-color', fontColor);

        $("#modal_border_color").val(borderColor);
        $("#modal_border_color").closest('.color-picker-component').find('.input-group-text').css('background-color', borderColor);

        $("#modal_purpose").modal("show");
    });

    $('#modal_purpose').on('hidden.bs.modal', function () {
      $(this).find('input[type="text"]').val('');
      $("#modal_purpose_text").removeAttr("data-id");
      $("#modal_purpose_text").removeAttr("data-purpose");

      $("#modal_background_color").closest('.color-picker-component').find('.input-group-text').css('background-color', '');
      $("#modal_font_color").closest('.color-picker-component').find('.input-group-text').css('background-color', '');
      $("#modal_border_color").closest('.color-picker-component').find('.input-group-text').css('background-color', '');
    });

    $(document).ready(function () {
        $('.color-picker-component').colorpicker({
            customClass: 'custom-size',
            sliders: {
                saturation: {
                    maxLeft: 250,
                    maxTop: 250
                },
                hue: {
                    maxTop: 250
                },
                alpha: {
                    maxTop: 250
                }
            }
        }).on('colorpickerChange', function (event) {
            $(this).find('.input-group-text').css('background-color', event.color.toString());
        });

        $('.color-text-cls').on('input', function () {
            if ($(this).val() === '') {
              $(this).closest('.color-picker-component').find('.input-group-text').css('background-color', '');
            }
        });
    });

  
    //Saurabh: This code used for solving tab issue, Whenever any modification on tab after that tab dispaly using session 
    $(document).ready(function() {
      // Retrieve the active tab from sessionStorage (it will be empty after page reload or close)
        var activeTab = sessionStorage.getItem('activeTab');
        
        // Check if there's an active tab saved in sessionStorage
        if (activeTab) {
          $("#" + activeTab).addClass('active');
          $("#" + activeTab).attr('aria-selected', 'true');
          // Show the corresponding content
          var activeContent = $("#" + activeTab).attr('href');
          $(activeContent).addClass('show active');
          
        } else {
          // If there's no active tab, set the default tab to active
          $('#timezone-tab').addClass('active show');
          $('#timezone').addClass('active');

        }

        
      // When a tab is clicked, update sessionStorage and apply the active class
          $(".nb").click(function () {
              $(".nb").removeClass('active');
              $(".nb").attr('aria-selected', 'false');
              $(".tab-pane").removeClass('show active');
              $('.purpose_dashboard_a ').removeClass('active show');

              // Add active class to clicked tab
              $(this).addClass('active');
              $(this).attr('aria-selected', 'true');

              // Show the corresponding content
              var targetContent = $(this).attr('href');
              $(targetContent).addClass('show active');

              // Save the active tab in sessionStorage
              sessionStorage.setItem('activeTab', $(this).attr('id'));
              // console.log(targetContent);
              if(targetContent == '#module-priority'){
                    $('#prtTab').addClass('active show')
                    $('.nebula_dashboard_chart').addClass('active show')
              }
           });
    });
    //Saurabh: End tab issue, Whenever any modification on tab after that tab dispaly using session 

  
  </script>

  <?= get_script_tag('nebula_mapper.js'); ?>

  <style>
    #priority-table-container, .purpose-table-container, .btn-small {
      padding: 5px 10px;
    }

    .modu_priority_tbl th {
      text-align: center;
    }

    .modu_priority_tbl td,
    .modu_priority_tbl th {
      padding: 10px;
    }

    .modu_priority_tbl {
      width: 40rem;
    }

    .table-data {
      width: 1000px;
      /* text-size-adjust: 25px; */
      font-size: medium;
      border: 2px solid black;
    }

    .nebula-holiday-settings-table .datatable-scroll-wrap {
      max-height: 445px;
      overflow: auto;
    }

    .nebula-footer {
      background-color: #f7f8fa;
      padding: 10px 20px;
      position: fixed;
      bottom: 0;
      width: 100%;
      border-top: 1px solid #ddd;
    }

    .switch {
      position: relative;
      display: inline-block;
      width: 34px;
      height: 20px;
    }

    .switch input {
      display: none;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: 0.4s;
      border-radius: 34px;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 14px;
      width: 14px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: 0.4s;
      border-radius: 50%;
    }

    input:checked+.slider {
      background-color: #007bff;
    }

    input:checked+.slider:before {
      transform: translateX(14px);
    }

    span.Zebra_DatePicker_Icon_Wrapper {
      display: block !important;
      width: 100% !important;
      position: relative !important;
    }
  </style>

  <style>
    .timezone-acco .card-header {
      background-color: #f1f1f1 !important;
      border-bottom: 1px solid #ddd !important;
      padding: 0 !important;
    }

    .timezone-acco .card-header a {
      color: #000;
      width: 100%;
      display: inline-block;
      padding: 8px 14px !important;
    }

    .timezone-acco .card-header a {
      position: relative;
    }

    .timezone-acco .card-header a:after {
      content: "\f0de";
      font: normal normal normal 18px / 1 FontAwesome;
      position: absolute;
      right: 15px;
      top: 13px;
    }

    .timezone-acco .card-header a.collapsed:after {
      content: "\f0dd";
      top: 5px;
    }
    /**Color Picker Start */
    /* .custom-size .colorpicker-saturation {
        width: 250px;
        height: 250px;
    }
    .custom-size .colorpicker-hue, .custom-size .colorpicker-alpha {
        width: 40px;
        height: 250px;
    }
    .custom-size .colorpicker-color,.custom-size .colorpicker-color div {
        height: 40px;
    } */
    /**Color Picker End */
  </style>