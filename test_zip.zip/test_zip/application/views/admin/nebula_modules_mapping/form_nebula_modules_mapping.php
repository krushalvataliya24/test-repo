   <!-- /page header -->

   <div class="page-header page-header-light">
    <div class="page-header-content header-elements-md-inline">
       <div class="page-title d-flex">
          <h4><?php echo $headTitle; ?></h4>
       </div>
    </div>
  <div class="bradcrumb-sec"><?php echo $bradcrumb; ?> </div>
 </div>
 
 
 <div class="content">
 
     <!-- Horizontal form options -->
                
     <div class="row">
 
         <div class="col-md-12">

 
                 <form class="form-horizontal" name="frmNebulaModulesMapping" id="frmNebulaModulesMapping" method="post" enctype="multipart/form-data" >
                         <input type="hidden" name="id" value="<?php echo $mapping_data['id']; ?>" />
 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="department"><?php echo $this->lang->line('lbl_department') ?><?php echo MEND_SIGN; ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select department select2" name="department" id="department" required>
                                    <option value>Select Department</option>
                                    <?php if(count($department) > 0){ ?>
                                    <?php foreach ($department as $ckey => $cvalue) { ?>

                                        <option data-id="<?php echo $cvalue; ?>" value="<?php echo $cvalue; ?>" <?php if ($cvalue == $mapping_data['department']) echo 'selected'; ?> ><?php echo $cvalue; ?></option>
                                    <?php } ?>
                                    <?php } ?>
                                </select>
                            </div>
                         </div>


 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="modules"><?php echo $this->lang->line('lbl_module') ?><?php echo MEND_SIGN; ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select modules select2" name="modules" id="modules" required>
                                    <option value>Select Modules</option>
                                    <?php if(count($module) > 0){ ?>
                                    <?php foreach ($module as $ckey => $cvalue) { ?>
                                        
                                        <option data-id="<?php echo $cvalue; ?>" value="<?php echo $cvalue; ?>" <?php if ($cvalue == $mapping_data['modulecode']) echo 'selected'; ?> ><?php echo $cvalue; ?></option>
                                    <?php } ?>
                                    <?php } ?>
                                </select>
                            </div>
                         </div>
 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="software_tl"><?php echo $this->lang->line('lbl_software_tl_name') ?><?php echo MEND_SIGN; ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select software_tl select2" name="software_tl" id="software_tl" required>
                                    <option value>Select Software TL</option>
                                    <?php if(count($software_tl) > 0){ ?>
                                    <?php foreach ($software_tl as $ckey => $cvalue) { ?>

                                        <option data-id="<?php echo $cvalue['id']; ?>" value="<?php echo $cvalue['id']; ?>" <?php if ($cvalue['id'] == $mapping_data['sw_tl_id']) echo 'selected'; ?> ><?php echo $cvalue['name']; ?></option>
                                    <?php } ?>
                                    <?php } ?>
                                </select>
                            </div>
                         </div>
 
                         <div class="form-group row">
 
                             <label class="col-md-2 control-label" for="trainer"><?php echo $this->lang->line('lbl_trainer_name') ?> : </label>
 
                             <div class="form-group col-lg-4">
                                <select class="custom-select trainer select2" name="trainer" id="trainer">
                                    <option value>Select Trainer</option>
                                    <?php if(count($software_tl) > 0){ ?>
                                    <?php foreach ($software_tl as $ckey => $cvalue) { ?>

                                        <option data-id="<?php echo $cvalue['id']; ?>" value="<?php echo $cvalue['id']; ?>" <?php if ($cvalue['id'] == $mapping_data['trainer_id']) echo 'selected'; ?> ><?php echo $cvalue['name']; ?></option>
                                    <?php } ?>
                                    <?php } ?>
                                </select>
                            </div>
                         </div>

                         <div class="form-actions">
 
                             <div class="row">
 
                                 <div class="col-lg-6 text-right">
 
                                     <button type="submit" class="btn btn-primary" id="btn-submit-dev"><?php echo $this->lang->line('lbl_submit'); ?></button>
 
                                     <a href="javascript:back_portlet()" class="btn btn-danger btn-edit"><?php echo $this->lang->line('lbl_cancel'); ?></a>
 
                                 </div>
 
                             </div>
 
                         </div>
 
 
 
                     </form>
 
 
             <!-- /basic layout -->
 
         </div>
 
     </div>
 
     <!-- /vertical form options -->
 
 </div>
<script>
    $(document).ready(function () {
        $(".select2").select2();
    });
 </script>