<!-- Page header -->
<section class="portlet-toggler">
    <!-- /page header -->

   <div class="page-header page-header-light">
      <div class="page-header-content header-elements-md-inline">
         <div class="page-title d-flex">
            <h4><?php echo $headTitle; ?></h4>
         </div>
      </div>
    <div class="bradcrumb-sec"><?php echo $bradcrumb; ?> </div>
   </div>
   
   
    <div class="content">
      <!-- Horizontal form options -->
      <div class="card">
         <div class="card-body">
            <!-- Basic layout-->
            <div class="row">
               <div class="col-lg-6">
                  
               </div> 
   
               <div class="col-lg-6">
               <div class="header-elements">
                 <div class="actions">
                 <?php //if (is_access_module()["create"]()) { ?>
                   <a href="javascript:void(0);" data-id="0" title="Add Nebula Mapping Module " class="btn btn-rounded btnEdit btn-primary" data-type="form" data-url="<?php echo base_url($this->ADM_URL . strtolower($class)); ?>" >
                       <i class="fa fa-plus"></i>
                       <span class="hidden-480 "><?php echo $this->lang->line('lbl_nebula_modules_mapping'); ?> </span>
                   </a>

                   <?php //if( getCurrentLoggedInUserType() == "SW_ADMIN") {  ?>
                        <!-- <button type="button" class="btn btn-primary mx-2 float-right btn-small" onclick="window.location.href='<?php echo base_url(); ?>Nebula_modules_mapping';" style="text-align: right; display: block;">
                                Modules Mapping</button> -->
                    <?php //}  ?>
                   <?php //} ?>
               </div>
           </div>  
           </div>   
   
   
   <div class="col-lg-12">
       <table class="table admin-list-table" id="listNebulaModulesMapping" width="100%">
           <thead>
               <tr>       
                   <th><?php echo $this->lang->line('lbl_sr_no') ?></th>
                   <th><?php echo $this->lang->line('lbl_department') ?></th>
                   <th><?php echo $this->lang->line('lbl_module') ?></th>
                   <th><?php echo $this->lang->line('lbl_software_tl_name') ?></th>
                   <th><?php echo $this->lang->line('lbl_trainer_name') ?></th>
                   <th width="1%" style="width:auto !important; max-width: 1%;"><?php echo $this->lang->line('lbl_operation') ?></th>
               </tr>
           </thead>
           <tbody></tbody>
       </table>
       </div>
       <div class="clearfix"></div>
   
   </div>
   <!-- /basic layout -->
   </div>
   </div>
   <!-- /vertical form options -->
   </div>
   </section>
   
   <div class=" panel panel-body portlet-toggler pageform" style="display:none;">
   </div>
   
   <div id="ajax_popup">
   </div>
   <?=get_css_tag('font-awesome.min.css');?>
   <link href="<?php echo base_url(ADM_CSS . 'glyphicon.css'); ?>" rel="stylesheet">
   <?=get_script_tag('nebula_modules_mapping.js');?>