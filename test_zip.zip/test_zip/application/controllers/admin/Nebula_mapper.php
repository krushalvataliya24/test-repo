<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Nebula_mapper extends Admin_Controller { 
    
    public $data = array();

    function __construct(){
        parent::__construct();
        $this->load->model('admin/Nebula_mapper_model', 'nebula_mapper');
        // set_module_code($this,get_nebula_modules_mapping_keyword());
        $this->load->model('admin/Nebula_dashboard_model', 'nebula_dashboard_model');
         // $this->load->model('admin/Nebula_modules_mapping_model', 'nebula_modules_mapping_model');
        $this->table = $this->nebula_mapper->_table;

        set_module_code($this,get_nebula_settings_form_keyword());
    }

    public function index(){
       
        $table_name = $this->nebula_mapper->_table;
       
        $this->load->model('admin/Common_admin_model', 'common_admin');
        $type = $this->input->post('type');
        
        $id = (int) $this->input->post('id');
        $module = [];

        // if (!empty($id)) {
        //     $this->data['mapping_data'] = $this->nebula_modules_mapping->getSingleRecordById($id, $table_name, 'id');
        //     $module = $this->nebula_modules_mapping->get_sub_modules_by_department_type($this->data['mapping_data']['department']);
        // }
        
        if ($type == 'submit_nebula_mapper') {
            $content = array();
            $content['status'] = 404;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            $post = $this->input->post();
            // pre($post);

           
            $check = $this->nebula_mapper->submit_nebula_mapper($post);

            if($check['status'] == 200){
                $content = $check;
            }
            echo json_encode($content);
            exit;
        }else if ($type == 'submit_nebula_mapper_working_hrs') {
            $content = array();
            $content['status'] = 404;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            $post = $this->input->post();
            // pre($post);
            
            $check = $this->nebula_mapper->submit_nebula_mapper_working_hrs($post);

            if($check['status'] == 200){
                $content = $check;
            }
            echo json_encode($content);
            exit;
        }else if($type == "submit_nebula_user_rights"){
            $content = array();
            $content['status'] = 404;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            $post = $this->input->post();
           
            $check = $this->nebula_mapper->submit_nebula_mapper_user_rights($post);

            if($check['status'] == 200){
                $content = $check;
            }
            echo json_encode($content);
            exit;
        } 
        else {
            $this->data['headTitle'] = $this->lang->line("lbl_nebula_settings");
            $this->data['module'] = "nebula_mapper/nebula_mapper";
            $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, $this->data['headTitle'] => ""));

            $this->data['getTimezoneDateTime'] = $this->nebula_mapper->getTimezoneDateTime();
            // pre($this->data['getTimezoneDateTime']);
            $this->data['getTimezones'] = $this->nebula_mapper->getTimezones();
            $this->data['getDateFormat'] = $this->nebula_mapper->getDateFormat();
            $this->data['getTimeFormat'] = $this->nebula_mapper->getTimeFormat();
            

            // $this->data['working_hrs_html'] = $this->nebula_mapper->getWorkingHrsHtml();
            // var_dump($this->data['getTimeFormat']);

            $this->data['working_hrs_data'] = $this->nebula_mapper->getWorkingHoursData();
            // pre($this->data['working_hrs_data']);
            
            $expected_array = [];
            if(!empty($this->data['working_hrs_data'])){
                foreach ($this->data['working_hrs_data'] as $value) {
                    $weekday = $value['weekday']; // Use weekday as the key
                    $expected_array[$weekday] = $value; // Assign the whole item to that key
                }
            }
            $this->data['working_hrs_data'] = $expected_array;
            // pre($this->data['working_hrs_data']);
           
            $this->data['todays_ticket_count'] = $this->nebula_dashboard_model->getTodaysStatusCounts();
            //Naman Start
            $this->data['get_all_priorities'] = $this->nebula_mapper->get_all_priorities();
           //Naman End
           $this->data['get_all_purpose'] = $this->nebula_mapper->get_all_purpose();
           $this->data['get_all_purpose_property'] = $this->nebula_mapper->getAllPurposeProperties();
           $this->data['nebual_user_right_list'] = $this->nebula_dashboard_model->getUserListNebulaRight();


           $software_tl = $this->db->select('tbl_users.id,tbl_users.name')
           ->from('tbl_users')
           ->where('type', 'SW_ADMIN')
           ->where('status', 'active')
           ->get()->result_array();

            $this->data['software_tl'] = $software_tl;
         
           $content['html'] = $this->load->view('admin/mainpage', $this->data);
            echo json_encode($content);
            
        }
       
    }
    public function lists() {
     
        $search_field=$this->input->get('search_fields');
        if ($this->input->is_ajax_request()) {
            $filters = $this->getDTFilters($this->input->get());
            $result = $this->nebula_mapper->getNebulaModulesMappingList($filters,$search_field);
            echo json_encode($result);
        } else {
            base_url(ADM_URL);
        }
    }

    public function listNebulaUsersRights(){
        
        $search_field=$this->input->get('search_fields');
        if ($this->input->is_ajax_request()) {
            $filters = $this->getDTFilters($this->input->get());
            $result = $this->nebula_dashboard_model->getOrionUsersList($filters,$search_field);
            echo json_encode($result);
        } else {
            base_url(ADM_URL);
        }
    }

    public function get_nebula_orion_user_data(){
        
        if ($this->input->is_ajax_request()) {
            $user_id = $this->input->post();
            
            // $result = $this->nebula_dashboard_model->get_nebula_user_rights($user_id['user_id']);
            $result = $this->nebula_mapper->get_nebula_user_rights($user_id['user_id']);
            
            echo json_encode($result);
        }else {
            base_url(ADM_URL);
        }
    }

    public function holiday_configuration_submit(){
        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];
        $post = $this->input->post();
        $last_insert_id = $this->nebula_mapper->holiday_configuration_submit($post);
        if($last_insert_id["status"]){
            $content['status'] = 200;
            $content['message'] = "Save successfully";
        }else if(!$last_insert_id["status"]){
            $content['message'] = $last_insert_id["message"];
        }
        echo json_encode($content);
        exit;
    }

    public function lists_holiday_mapper(){
        $search_field=$this->input->get('search_fields');
        $data['tab_id'] = $this->input->get('tab_id');
        if ($this->input->is_ajax_request()) {

            $data['holiday_filter_val'] = $this->input->get('holiday_filter_val');
            $filters = $this->getDTFilters($this->input->get());
            $result = $this->nebula_mapper->getListsHolidayMapper($filters,$search_field, $data);
            echo json_encode($result);
        } else {
            base_url(ADM_URL);
        }
    }

    public function priority_submit(){
       
        $post = $this->input->post();
        $result = $this->nebula_mapper->priority_submit($post);

        if ($result['status'] == 200) {
            $content = $result;
        }
        if ($result['status'] == 404) {
            $content['status'] = $result['status'];
            $content['message'] = $result['message'];
        }

        echo json_encode($content);
        exit;
        
    }

    // Naman start for the edit and delete fun.
    public function priority_delete(){
        $post = $this->input->post();
        $result = $this->nebula_mapper->priority_delete($post);

        if ($result['status'] == 200) {
            $content = $result;
        }
        if ($result['status'] == 404) {
            $content['status'] = $result['status'];
            $content['message'] = $result['message'];
        }

        echo json_encode($content);
        exit;

    }

    public function priority_edit(){
        $post = $this->input->post();
        $result = $this->nebula_mapper->priority_edit($post);

        if ($result['status'] == 200) {
            $content = $result;
        }
        if ($result['status'] == 404) {
            $content['status'] = $result['status'];
            $content['message'] = $result['message'];
        }

        echo json_encode($content);
        exit;

    }
    // Naman start for the edit and delete fun.

    /**
     * MY: Purpose Master Opeartion
     * Insert, Update, Delete Operation
     */
    public function purpose_submit()
    {
        $post = $this->input->post();
        $result = $this->nebula_mapper->purpose_submit($post);

        if ($result['status'] == 200) {
            $content = $result;
        }
        if ($result['status'] == 404) {
            $content['status'] = $result['status'];
            $content['message'] = $result['message'];
        }
        echo json_encode($content);
        exit;
    }

}
?>