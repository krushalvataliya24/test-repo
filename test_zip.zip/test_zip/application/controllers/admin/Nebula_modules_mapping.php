<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Nebula_modules_mapping extends Admin_Controller { 
    
    public $data = array();

    function __construct(){
        parent::__construct();
        $this->load->model('admin/Nebula_modules_mapping_model', 'nebula_modules_mapping');
        set_module_code($this,get_nebula_modules_mapping_keyword());
         
        $this->table = $this->nebula_modules_mapping->_table;
    }

    public function index(){
        
        $table_name = $this->nebula_modules_mapping->_table;
       
        $this->load->model('admin/Common_admin_model', 'common_admin');
        $type = $this->input->post('type');
        
        $id = (int) $this->input->post('id');
        $module = [];

        if (!empty($id)) {
            $this->data['mapping_data'] = $this->nebula_modules_mapping->getSingleRecordById($id, $table_name, 'id');
            $module = $this->nebula_modules_mapping->get_sub_modules_by_department_type($this->data['mapping_data']['department']);
        }
        
        if ($type == "form") {
            
            $content = array();
            $content['status'] = 200;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            
            $this->data['headTitle'] = ($id > 0 ? $this->lang->line("lbl_edit") : $this->lang->line("lbl_add") . ' ' . $this->lang->line("lbl_new")) . " " . $this->lang->line('lbl_nebula_modules_mapping');

            $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, $this->lang->line('lbl_nebula_modules_mapping') => "javascript:back_portlet();", $this->data['headTitle'] => ""));

            $departments = $this->db->select('tbl_users.type')
                                ->from('tbl_users')
                                ->distinct('type')
                                ->not_like('type', '_tl')
                                ->where('status', 'active')
                                ->get()->result_array();
            
            $this->data['department'] = multidimensional_to_single_array($departments);

            $software_tl = $this->db->select('tbl_users.id,tbl_users.name')
                            ->from('tbl_users')
                            ->where('type', 'SW_ADMIN')
                            ->where('status', 'active')
                            ->get()->result_array();

            $this->data['software_tl'] = $software_tl;
            
            $this->data['module'] = $module;
            
            $content['html'] = $this->load->view('admin/nebula_modules_mapping/form_nebula_modules_mapping', $this->data, true);
            
            echo json_encode($content);
            exit;       
        } else if ($type == 'submit_nebula_modules_mapping') {
            
            $content = array();
            $content['status'] = 404;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            $post = $this->input->post();

            $this->form_validation->set_rules('department',"Department" ,'trim|required');
            $this->form_validation->set_rules('modules',"Modules" ,'trim|required');
            $this->form_validation->set_rules('software_tl',"Software TL" ,'trim|required');
           
            if ($this->form_validation->run() == FALSE) {
                $content['message'] = validation_errors();
            } else {
                
                $check = $this->nebula_modules_mapping->submit_nebula_modules_mapping($post);

                if($check['status'] == 200){
                    $content = $check;
                }
            }
            echo json_encode($content);
            exit;
        } else if ($this->data['action'] == "delete"){
            $content = array();
            $content['status'] = 404;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            $id = $this->input->post('id');
            $check = $this->nebula_modules_mapping->softDeleteSingle($id, $table_name, 'id');
            if ($check['status'] == 200) {
                $content = $check;
            }
            echo json_encode($content);
            exit;
        } else {
            $this->data['headTitle'] = $this->lang->line("lbl_nebula_modules_mapping");
            $this->data['module'] = "nebula_modules_mapping/list_nebula_modules_mapping";
            $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, $this->lang->line("lbl_nebula_mapper") => base_url() . ADM_URL."Nebula_mapper", $this->data['headTitle'] => ""));
            
            // $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, $this->lang->line("lbl_nebula_mapper") => base_url() . ADM_URL."Nebula_mapper", $this->data['headTitle'] => ""));
            
            $this->load->view('admin/mainpage', $this->data);
        }
       
    }
    public function lists() {
     
        $search_field=$this->input->get('search_fields');
        if ($this->input->is_ajax_request()) {
            $filters = $this->getDTFilters($this->input->get());
            $result = $this->nebula_modules_mapping->getNebulaModulesMappingList($filters,$search_field);
            echo json_encode($result);
        } else {
            base_url(ADM_URL);
        }
    }

    public function getSubModulesByDepartmentType(){

        $content = array();
        $content['status'] = 404;
        $content['message'] = $this->data['language']['err_something_went_wrong'];
        $content['module'] = [];

        $department = $this->input->post('department');
        
        $module = $this->nebula_modules_mapping->get_sub_modules_by_department_type($department);

        if(!empty($module)){
            
            $content['status'] = 200;
            $content['message'] = $this->data['language']['succ'];
            $content['module'] = $module;
        }

        echo json_encode($content);
        exit;
    }
}
?>