<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

require DOC_ROOT . 'application/third_party/phpspreadsheet_excel/vendor/autoload.php';

class Nebula_dashboard extends Admin_Controller { 
    
    public $data = array();

    function __construct(){
        parent::__construct();
        $this->load->model('admin/Nebula_dashboard_model', 'nebula_dashboard_model');
        $this->load->helper("nebula_helper");
        set_module_code($this,get_nebula_form_keyword());
        $this->table = $this->nebula_dashboard_model->_table;
        $this->second_db = $this->load->database('second_default', TRUE);

    }

    public function index(){

        

        $table_name = $this->nebula_dashboard_model->_table;
       
        $this->load->model('admin/Common_admin_model', 'common_admin');
        $type = $this->input->post('type');
        
        $id = (int) $this->input->post('id');

        // if (!empty($id)) {
        //     $this->data['nebula_form_data'] = $this->nebula_dashboard_model->getSingleRecordById($id, $table_name, 'id');
        // }

        if ($type == "view"){
            
            $content = array();
            $content['status'] = 200;
            $content['message'] = $this->data['language']['err_something_went_wrong'];
            $this->data['view_id'] = $this->input->post('id');
            $this->data['ticket_details'] = $this->nebula_dashboard_model->getTicketDetails($this->data['view_id']);

            $this->data['priorityOptions'] = priorityOptions();
            $this->data['nebula_priority_colorcode'] = nebula_priority_colorcode();
           

            $this->data['headTitle'] = "Nebula View";
            $this->data['module'] = "nebula_dashboard/nebula_view_page";
            $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, "Nebula Dashboard" => base_url() . ADM_URL."Nebula_dashboard", "View - {$this->data['ticket_details']['request_type']} - {$this->data['view_id']} " => ""));

            $this->data['CurrentLoggedInUserType'] = getCurrentLoggedInUserType();
            
            $this->data['todays_ticket_count'] = $this->nebula_dashboard_model->getTodaysStatusCounts();

            $content['html']= $this->load->view('admin/nebula_dashboard/nebula_view_page', $this->data, true);
            echo json_encode($content);
            exit;  

        }
         else {

            // START - Previous Working 
            // if (in_array(getCurrentLoggedInUserType(), ['SW_ADMIN', 'SW_QA', 'SW_DEV'])) {
            //     $this->data['headTitle'] = $this->lang->line("nebula_dashboard_header_title");
            //     $this->data['module'] = "nebula_dashboard/nebula_dashboard_list";
            //     $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, "Nebula Dashboard" => ""));

            //     $this->data['orion_users'] = $this->nebula_dashboard_model->get_orion_users();
            //     // pre($this->data['orion_users']);

            //     $this->data['table_heading'] = $this->nebula_dashboard_model->getTableHeadings(getCurrentLoggedInUserType(), false);
               
            //     $this->data['status_count'] = $this->nebula_dashboard_model->getStatusCount(false, false);

            // }else{
            //     $this->data['headTitle'] = $this->lang->line("nebula_dashboard_header_title");
            //     $this->data['module'] = "show_list";
            //     $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, "Nebula Dashboard" => ""));

            //     // $this->data['team_users'] = $this->nebula_dashboard_model->get_tl_team_users(getCurrentLoggedInUserType());

            //     $this->data['table_heading'] = $this->nebula_dashboard_model->getTableHeadings(getCurrentLoggedInUserType(), false);
            //     $this->data['status_count'] = $this->nebula_dashboard_model->getStatusCount(false, getCurrentLoggedInUserID());
                
            // }
            // END - Previous Working

            $this->data['headTitle'] = $this->lang->line("nebula_dashboard_header_title");

            $this->data['module'] = "nebula_dashboard/nebula_dashboard_list_new";
            $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, "Nebula Dashboard" => ""));

            $this->data['orion_users'] = $this->nebula_dashboard_model->get_orion_users();
            $this->data['table_heading'] = $this->nebula_dashboard_model->getTableHeadings(getCurrentLoggedInUserType(), false);

            // $this->data['status_count'] = $this->nebula_dashboard_model->getStatusCount(false, false);

            $this->data['header_data_recent'] = $this->nebula_dashboard_model->getTableHeadingsRecent();
            
            $this->data['departments'] = $this->nebula_dashboard_model->get_departments();

            $this->data['get_all_status_types'] = $this->nebula_dashboard_model->getStatusTypes();

            $this->data['nebula_dashboard_data'] = $this->nebula_dashboard_model->nebula_dashboard_stats();

            $filter_status['status_stat_filter'] = 'this_month';
            $this->data['nebula_dashboard_filter_data'] = $this->nebula_dashboard_model->nebula_dashboard_status_stats_filters($filter_status);

            $filter_status['dept_stat_filter'] = 'this_month';
            $this->data['nebula_dept_dashboard_filter_data'] = $this->nebula_dashboard_model->nebula_dashboard_dept_stats_filters($filter_status);
            
            $UserName = $this->session->userdata()['UserName'];
            $UserID = $this->session->userdata()['UserID'];
            $UserType = $this->session->userdata()['UserType'];
            $this->data['check_user'] = array(
                'user_id' => $UserID,
                'user_type' => $UserType,
                'user_name' => $UserName
            );
            
            
            $this->data['CurrentLoggedInUserType'] = getCurrentLoggedInUserType();

            $this->data['nebula_data'] = $this->nebula_dashboard_model->get_departments();

            $this->data['todays_ticket_count'] = $this->nebula_dashboard_model->getTodaysStatusCounts();

            // $this->data['status_count'] = $this->nebula_dashboard_model->getStatusCount(false);

            // $this->data['table_heading'] = $this->nebula_dashboard_model->getTableHeadings();

            if(in_array(nebula_export_excel_filter_string(), checkUserPermission(getCurrentLoggedInUserID())["export_option"])){ 
                $this->data['is_export_excel'] = '1';
            }else{
                $this->data['is_export_excel'] = '';
            }

            $this->load->view('admin/mainpage', $this->data);
        }

    }

    public function lists() {
     
        $search_field=$this->input->get('search_fields');
        if ($this->input->is_ajax_request()) {
            $filters = $this->getDTFilters($this->input->get());
            $result = $this->import_task_excel->getImportTaskExcelList($filters,$search_field);
            echo json_encode($result);
        } else {
            base_url(ADM_URL);
        }
    }

    public function show_list() {

        $this->data['headTitle'] = "Show List";
        // $this->data['module'] = "show_list";
        $this->data['module'] = "nebula_dashboard/nebula_dashboard_list_new";
        $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, "Show List" => "", $this->data['headTitle'] => ""));
        $this->load->view('admin/mainpage', $this->data);
    }
 
    public function show_list_ajax() 
    {   
        $UserID = $this->session->userdata()['UserID'];
        $UserType = $this->session->userdata()['UserType'];
        $UserName = $this->session->userdata()['UserName'];
        $data['check_user'] = array(
            'user_id' => $UserID,
            'user_type' => $UserType,
            'user_name' => $UserName
        );

        $data['tab_id'] = $this->input->get('tab_id');
        
        if ($this->input->is_ajax_request()) {
            $data['filter_global'] = $this->input->get('filter_type');
            $data['orion_user'] = $this->input->get('selectedOrionUser');

            $filters = $this->getDTFilters($this->input->get());

            $result = $this->nebula_dashboard_model->show_requistion_list($filters, $data);

            $result['status'] = 200;
            $result['message'] = "Success";
            
            echo json_encode($result);
        } else {
            redirect(base_url(ADM_URL)); 
        }
    }

    public function nebula_dashboard_status_stats_filters(){
        $param['status_stat_filter'] = $this->input->post('status_stat_filter');
        $param['dept_stat_filter'] = $this->input->post('dept_stat_filter');

        if($this->input->is_ajax_request()){
            $data = $this->nebula_dashboard_model->nebula_dashboard_status_stats_filters($param);
        }else {
            redirect(base_url(ADM_URL)); 
        }

        if($data['status'] == 200){
            $content = $data;
        }
        if ($data['status'] == 404) {
            $content['status'] = $data['status'];
            $content['message'] = $data['message'];
        }
        
        echo json_encode($content);

    }

    public function nebula_dashboard_dept_stats_filters(){
        
        if ($this->input->is_ajax_request()) {
            $param['dept_stat_filter'] = $this->input->post('dept_stat_filter');
            $data = $this->nebula_dashboard_model->nebula_dashboard_dept_stats_filters($param);
        }else {
            redirect(base_url(ADM_URL)); 
        }

        if($data['status'] == 200){
            $content = $data;
        }
        if ($data['status'] == 404) {
            $content['status'] = $data['status'];
            $content['message'] = $data['message'];
        }
        
        echo json_encode($content);

    }
    
    public function updateViewPageChanges(){
        $content = array();

        $param = $this->input->post();
        // pre($param);
        $data = $this->nebula_dashboard_model->updateViewPageChanges($param);

        if ($data['status'] == 200) {
            $content = $data;
        }
        if ($data['status'] == 404) {
            $content['status'] = $data['status'];
            $content['message'] = $data['message'];
        }
        // pre($content);

        echo json_encode($content);
        exit;

    }

    public function getSubModulesByDepartmentType(){
        $department_type = $this->input->post('department_type'); 
        $sub_module = $this->nebula_dashboard_model->getSubModulesByDepartmentType($department_type);

        echo json_encode($sub_module);
    }
//Naman Start
    public function get_departments(){
        $result['departments'] = $this->nebula_dashboard_model->get_departments();
        $result['priority'] = $this->nebula_mapper_model->get_all_priorities();
        echo json_encode($result);
    }
//Naman End

    public function getDepartmentTL(){
        $department_type = $this->input->post('department_type');
        $department_tl = $this->nebula_dashboard_model->getDepartmentTL($department_type);

        echo json_encode($department_tl);
    }

    public function getSoftwareTL(){
        $sub_module = $this->input->post('sub_module'); 
        $software_tl = $this->nebula_dashboard_model->getSoftwareTL($sub_module);

        echo json_encode($software_tl);
    }

    public function getTrainer(){
        $sub_module = $this->input->post('sub_module'); 
        $trainer = $this->nebula_dashboard_model->getTrainer($sub_module);

        echo json_encode(['name' => $trainer['name'], 'trainer_id' => $trainer['trainer_id']]);
    }

    public function updateTrainer(){
        
        $content = array();

        // pre($this->input->post());
        $param['ticket_id'] = $this->input->post('ticket_id');
        $param['assign_to_ids'] = $this->input->post('assign_to_ids');
        $check = $this->nebula_dashboard_model->updateTrainer($param);

        if ($check['status'] == 200) {
            $content = $check;
        }
        if ($check['status'] == 404) {
            $content['status'] = $check['status'];
            $content['message'] = $check['message'];
        }

        echo json_encode($content);
        exit;
    }

    public function updateStatus(){
        $content = array();
        $param['ticket_id'] = $this->input->post('ticket_id');
        $param['status_stage'] = $this->input->post('status_stage');

        $check = $this->nebula_dashboard_model->updateStatus($param);

        if ($check['status'] == 200) {
            $content = $check;
        }
        if ($check['status'] == 404) {
            $content['status'] = $check['status'];
            $content['message'] = $check['message'];
        }

        echo json_encode($content);
        exit;

    }

    public function updateListPageDropdown(){
        $content = array();
        $param['ticket_id'] = $this->input->post('ticket_id');
        // $param['ticket_purpose'] = $this->input->post('ticket_purpose');
        // $param['ticket_priority'] = $this->input->post('ticket_priority');
        // $param['removed_tag'] = $this->input->post('removed_tag');
        
        $param = $this->input->post();
        // pre($param);

        $check = $this->nebula_dashboard_model->updateListPageDropdown($param);

        if ($check['status'] == 200) {
            $content = $check;
        }
        if ($check['status'] == 404) {
            $content['status'] = $check['status'];
            $content['message'] = $check['message'];
        }

        echo json_encode($content);
        exit;
    }

    public function updateViewPageComments(){
        $content = array();
        // $param['ticket_id'] = $this->input->post('ticket_id');
        $param = $this->input->post();

        $check = $this->nebula_dashboard_model->updateViewPageComments($param);

        if ($check['status'] == 200) {
            $content = $check;
        }
        if ($check['status'] == 404) {
            $content['status'] = $check['status'];
            $content['message'] = $check['message'];
        }

        echo json_encode($content);
        exit;
        
    }

    public function get_nebula_form_data(){

        if ($this->input->is_ajax_request()) {
            $edit_id = $this->input->get('edit_id');
            $result_data = $this->nebula_dashboard_model->get_nebula_form_data($edit_id);
              
            if($result_data['status'] == 200){
                $content = $result_data;
            }
            if($result_data['status'] == 400){
                $content['status'] = $result_data['status'];
                $content['message'] = $result_data['message'];
            }
            echo json_encode($content);
        } else {
            redirect(base_url(ADM_URL)); 
        }
    }

    public function submitNebula(){
        
        $postdata = $this->input->post();
        $check = $this->nebula_dashboard_model->submitNebula($postdata);

        if ($check['status'] == 200) {
            $content = $check;
        }
        if ($check['status'] == 404) {
            $content['status'] = $check['status'];
            $content['message'] = $check['message'];
        }

        echo json_encode($content);
        exit;

    }
    //Naman Start

    public function open_ticket($view_id=""){
        $content = array();
        $content['status'] = 200;
        $content['message'] = $this->data['language']['err_something_went_wrong'];
        $this->data['view_id'] = $view_id;
        $this->data['ticket_details'] = $this->nebula_dashboard_model->getTicketDetails($view_id);
        
       
        $this->data['priorityOptions'] = priorityOptions();
        $this->data['nebula_priority_colorcode'] = nebula_priority_colorcode();
       

        $this->data['headTitle'] = "Nebula View";
        $this->data['module'] = "nebula_dashboard/nebula_view_page";
        $this->data['bradcrumb'] = breadcrumb(array($this->lang->line("lbl_admin_home") => base_url() . ADM_URL, "Nebula Dashboard" => base_url() . ADM_URL."Nebula_dashboard", "View - {$this->data['ticket_details']['request_type']} - {$view_id} " => ""));

        $this->data['CurrentLoggedInUserType'] = getCurrentLoggedInUserType();
        
        $this->data['todays_ticket_count'] = $this->nebula_dashboard_model->getTodaysStatusCounts();

        $this->data['module'] = "nebula_dashboard/nebula_view_page";
        $this->load->view('admin/mainpage', $this->data);

        // $content['html']= $this->load->view('admin/nebula_dashboard/nebula_view_page', $this->data, true);
        // echo json_encode($content);
        // exit;  

    }
    //Naman End


    public function getPriorityData(){
        $priority_option = priorityOptions();
       
        echo json_encode($priority_option);
    }

    public function getPurposeData(){
        $purposeTypes = purposeTypes();
        $taskValue = $purposeTypes['task_assign'];
        if ($purposeTypes) {
            unset($purposeTypes['task_assign']);
        }
        if(in_array(getCurrentLoggedInUserType(), ['SW_ADMIN', 'SW_QA']) || in_array(getCurrentLoggedInUserName(), nebula_functionality_access())) {
            $purposeTypes['task_assign'] = $taskValue;
        }
        echo json_encode($purposeTypes);
    }

}
?>