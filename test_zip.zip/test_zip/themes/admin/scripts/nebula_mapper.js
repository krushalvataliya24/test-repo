$(document).ready(function () {

    

    $('.switch input').change(function () {
        // Find the row that the switch belongs to
        const row = $(this).closest('.row');
        
        // Get the day of the week from the row's data attribute
        const day = row.data('day');
        
        // Get the status text element and the time input fields
        const statusText = row.find('.status-text');
        const startTimeInput = row.find(`#${day}_start_time`);
        const endTimeInput = row.find(`#${day}_end_time`);
        
        // If the switch is checked (Open)
        if ($(this).is(':checked')) {
            statusText.text('Open'); // Update status to Open
            statusText.removeClass('text-muted').addClass('text-primary'); // Update status text style
            startTimeInput.prop('disabled', false); // Enable start time input
            endTimeInput.prop('disabled', false); // Enable end time input
        } else {
            statusText.text('Closed'); // Update status to Closed
            statusText.removeClass('text-primary').addClass('text-muted'); // Update status text style
            startTimeInput.prop('disabled', true); // Disable start time input
            endTimeInput.prop('disabled', true); // Disable end time input
        }
    });

    // Handle form submission
    $('#frmNebulaMapperWorkingHrs').submit(function (e) {
        e.preventDefault(); // Prevent default form submission

        var formData = new FormData(this); // Create FormData object from the form

        // Initialize an object to store weekdays data
        var weekdaysData = {};

        // Loop through each weekday and get the status and time values
        $('.weekday-time').each(function () {
            var day = $(this).data('day'); // Get the day name (monday, tuesday, etc.)
            var checkboxStatus = $(this).find('input[type="checkbox"]').is(':checked') ? 'Open' : 'Closed';
            var startTime = $(this).find('input[id="' + day + '_start_time"]').val();
            var endTime = $(this).find('input[id="' + day + '_end_time"]').val();

            // Create an object for each day with status, start time, and end time
            weekdaysData[day] = {
                status: checkboxStatus,
                start_time: startTime,
                end_time: endTime
            };
        });

        // Log the weekdaysData to verify the structure
        console.log(weekdaysData);

        // Add the weekdaysData to the formData as a JSON string
        formData.append("weekdays_data", JSON.stringify(weekdaysData));

        formData.append("type", 'submit_nebula_mapper_working_hrs');
        
        // Optionally, you can log the FormData object to see the appended values
        formData.forEach(function(value, key) {
            console.log("data is : " + key + ": " + value);
        });

        // Show overlay before sending the request
        addOverlay();

        // Send the form data via AJAX
        $.ajax({
            type: 'POST',
            url: ADMIN_URL + "Nebula_mapper",
            data: formData,
            async: false,
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            success: function (r) {
                removeOverlay(); // Remove overlay on success or failure
                var sTitle = '';
                var sType = getStatusText(r.status);
                var sText = r.message;
                var sAddClass = r.addclass;
                Custom.myNotification(sType, sText);
                window.location.href = ADMIN_URL+"Nebula_mapper";
                
                // Optional: Redirect after success
                if (r.status == 200) {
                    // window.location.href = ADMIN_URL + "Nebula_modules_mapping";
                }
            },
            error: function () {
                removeOverlay(); // Remove overlay in case of error
                // Optionally, show an error notification
                Custom.myNotification('error', 'An error occurred. Please try again.');
            }
        });
    });

});


$(document).on('submit', '#frmNebulaMapperTimezoneDateTime', function (e) {
    e.preventDefault();
    
        var data = new FormData($('#frmNebulaMapperTimezoneDateTime')[0]);
        data.append("type",'submit_nebula_mapper');
        // console.log("data is : " + JSON.parse(data));return;
        
        addOverlay();
        $.ajax({
            type: 'post',
            data: data,
            async:false,
            dataType: "json",
            url: ADMIN_URL+"Nebula_mapper",
            cache: false,
            contentType: false,
            processData: false,
            success: function (r) {
                if (r.status == 200) {
                    sTitle='';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType,sText);
                    window.location.href = ADMIN_URL+"Nebula_mapper";
                    return false;
                } else {
                    sTitle='';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType,sText);
                }
            }
            // complete: removeOverlay
        });
        removeOverlay();
});

$(document).on('submit', '#frmNebulaUserRights', function (e) {
    e.preventDefault();
    
        var data = new FormData($('#frmNebulaUserRights')[0]);
        data.append("type",'submit_nebula_user_rights');
        // console.log("data is : " + JSON.parse(data));return;


        var tabOptions = [];
        $("input[name='tab_option[]']:checked").each(function () {
            tabOptions.push($(this).val());
        });
        data.append("tab_option", tabOptions); 
    
        var ticketOptions = [];
        $("input[name='ticket_option[]']:checked").each(function () {
            ticketOptions.push($(this).val());
        });
        data.append("ticket_option", ticketOptions); 

        var filterOptions = [];
        $("input[name='filter_option[]']:checked").each(function () {
            filterOptions.push($(this).val());
        });
        data.append("filter_option", filterOptions); 

        var exportOption = [];
        $("input[name='export_option[]']:checked").each(function () {
            exportOption.push($(this).val());
        });
        data.append("export_option", exportOption); 

        var ticketConversionsOption = [];
        $("input[name='ticket_conversions_option[]']:checked").each(function () {
            ticketConversionsOption.push($(this).val());
        });
        data.append("ticket_conversions_option", ticketConversionsOption); 

        var postOptions = [];
        $("input[name='post_option[]']:checked").each(function () {
            postOptions.push($(this).val());
        });
        data.append("post_option", postOptions); 
        
        addOverlay();
        $.ajax({
            type: 'post',
            data: data,
            async:false,
            dataType: "json",
            url: ADMIN_URL+"Nebula_mapper",
            cache: false,
            contentType: false,
            processData: false,
            success: function (r) {
                if (r.status == 200) {
                    sTitle='';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType,sText);
                    window.location.href = ADMIN_URL+"Nebula_mapper";
                    // $('#module-userright-tab').tab('show');
                    
                    // window.location.href = ADMIN_URL + "Nebula_mapper#module-userright-tab";
                    return false;
                } else {
                    sTitle='';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType,sText);
                }
            }
            // complete: removeOverlay
        });
        removeOverlay();
});



$(document).ready(function () {

    $(".select2").select2();

    oTable = $('#listNebulaUsers').DataTable({
        responsive: false,
        "processing": true,
        "serverSide": true,
        "order": [],
        "iDisplayLength": 10,
            "order": [
                [0, "DESC"]
            ],
        "ajax": {
            "url": ADMIN_URL+"Nebula_mapper/listNebulaUsersRights/",
        },
        "columns": [
            {"data": "id", searchable: false, sortable: false},
            {"data": "name",searchable: true, sortable: false},
            {"data": "email", searchable: true, sortable: false},
            {"data": "username", searchable: true, sortable: false},
            {"data": "role", searchable: true, sortable: false},
            {"data": "action", searchble: false, sortable: false,"width": "20%"},
        ],
        "columnDefs": [{
            "defaultContent": "-",
            "targets": "_all"
        }],
        drawCallback: function (oSettings) {
            
        }
    });
});



$(document).on("click",".nebula_user_rights_edit",function() {
    var userId = $(this).data('id'); 
    // alert(userId);

    $.ajax({
        url: 'Nebula_mapper/get_nebula_orion_user_data',
        method: 'post',
        async: true,
        data: { user_id: userId }, 
        success: function (response) {
            var getUserData = response;
            getUserData = JSON.parse(getUserData);
            // console.log("Response is: ", getUserData);

            if (getUserData) {

                var tabOptions = (getUserData.tab_option || '').split(',').map(function(item) { return item.trim(); });
                var ticketOptions = (getUserData.ticket_show_hide || '').split(',').map(function(item) { return item.trim(); });
                // var postOptions = (getUserData.post_option || '').split(',').map(function(item) { return item.trim(); });
                var filterOptions = (getUserData.filter_options || '').split(',').map(function(item) { return item.trim(); });
                var ticketConversionsOption = (getUserData.ticket_conversions_option || '').split(',').map(function(item) { return item.trim(); });
                
                var exportOption = (getUserData.export_option || '').split(',').map(function(item) { return item.trim(); });

                // Set the user_id for the "Select User" dropdown
                // $('#nebula_selected_user').val(getUserData.user_id);

                $('#nebula_selected_user').select2();  // Initialize Select2
                $('#nebula_selected_user').val(getUserData.user_id).trigger('change');  // Set the value and trigger change event

                // Handle Tab Options (checkboxes)
                $('#every_tab').prop('checked', tabOptions.includes('every_tab'));
                $('#all_tab').prop('checked', tabOptions.includes('all_tab'));

                // Handle Ticket Options (checkboxes)
                $('#own_ticket').prop('checked', ticketOptions.includes('own_ticket'));
                $('#own_department_ticket').prop('checked', ticketOptions.includes('own_department_ticket'));
                $('#all_department_ticket').prop('checked', ticketOptions.includes('all_department_ticket'));

                // Handle Filter Options (checkboxes)
                $('#nebula_dept_filter').prop('checked', filterOptions.includes('nebula_dept_filter'));
                $('#nebula_ticket_type_filter').prop('checked', filterOptions.includes('nebula_ticket_type_filter'));nebula_created_updated_filter
                $('#nebula_status_filter').prop('checked', filterOptions.includes('nebula_status_filter'));
                $('#nebula_created_updated_filter').prop('checked', filterOptions.includes('nebula_created_updated_filter'));
                $('#nebula_datewise_filter').prop('checked', filterOptions.includes('nebula_datewise_filter'));

                // Handle Ticket Conversion Options (checkboxes)
                $('#ticket_conversions_type_filter').prop('checked', ticketConversionsOption.includes('ticket_conversions_type_filter'));
                $('#ticket_conversions_priority_filter').prop('checked', ticketConversionsOption.includes('ticket_conversions_priority_filter'));
                $('#ticket_conversions_assign_to_filter').prop('checked', ticketConversionsOption.includes('ticket_conversions_assign_to_filter'));
                $('#ticket_conversions_status_filter').prop('checked', ticketConversionsOption.includes('ticket_conversions_status_filter'));

                // Handle Export Options (checkboxes)
                $('#nebula_export_excel_filter').prop('checked', exportOption.includes('nebula_export_excel_filter'));

                // Handle Post Options (checkboxes)
                // $('#bug_post').prop('checked', postOptions.includes('bug'));
                // $('#training_post').prop('checked', postOptions.includes('training'));
                // $('#feature_post').prop('checked', postOptions.includes('feature'));
                
            } else {
                console.error("No valid data received.");
            }

        },
        error: function (xhr, status, error) {
            console.error("Error fetching Users", error);
            
        }
    });
});


$('#nebula_user_rights_ticket #own_department_ticket, #all_department_ticket').on('change', function() {
    if ($('#own_department_ticket').prop('checked') || $('#all_department_ticket').prop('checked')) {
        $('#all_tab').prop('checked', true); // Check 'All Tab' if either checkbox is checked
    } else {
        $('#all_tab').prop('checked', false); // Uncheck 'All Tab' if both are unchecked
    }
});



