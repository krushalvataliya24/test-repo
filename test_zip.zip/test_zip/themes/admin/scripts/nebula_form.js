var neweditorInstance;

    var userType = "<?php echo addslashes(json_encode(getCurrentLoggedInUserType())); ?>";
    
    var currentPageURL = '';
    var selectedDepartmentType = '';

    // Naman Start
    $(document).on('click', '.requi_btn', function (e) {

        e.stopImmediatePropagation();
    
        selectedDepartmentType = $('#orion_department').val();

        fetchPriorityData();

        fetchPurposeData();

        if (selectedDepartmentType) {
            fetchSubModules(selectedDepartmentType);
           
        }

        currentPageURL = window.location.href;
        
        var dept = $(this).data('department');
        
        $.ajax({
            url: ADMIN_URL + 'Nebula_dashboard/get_departments',
            dataType: "json",  
            method: 'post',
            data: { department_type: dept },
            success: function (response) {;
                var depts = response.departments;
                var priorities = response.priority;
                // console.log("priorities dfgj: " + priorities);
                
    
                
                var deptDropdown = $('#orion_department');
                deptDropdown.empty();
                
                var currentLoggedInDepartmet = $('.requi_btn').data('department');
                
                if (depts && depts.length > 0) {
                    depts.forEach(function (dept) {
                        var isSelected = dept.type === currentLoggedInDepartmet ? ' selected' : '';
                        deptDropdown.append('<option value="' + dept.type + '"'+ isSelected + '>' + dept.type + '</option>');
                    });
                } else {
                    deptDropdown.append('<option value="">No Department available</option>');
                }



            },
            error: function (xhr, status, error) {
                console.error("Error fetching Departments:", error);
                alert('There was an error fetching Departments. Please try again.');
            }
        });

        if($(".nebula-form .ck-editor").length==0){
            neweditorInstance=  nebula_ckeditor("notes");
        }
            
        $("#nebulaForm .ck-editor").css("display","block");
    });
    $(document).on('change', '#orion_department', function(){
       
        selectedDepartmentType = $(this).val();
        if (selectedDepartmentType) {
            fetchSubModules(selectedDepartmentType);
        }
    });

// Naman End

function disableInputs(container) {
    const inputs = container.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.disabled = true;
        input.required = false;
    });
}

function enableInputs(container) {
    const inputs = container.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.disabled = false;
        input.required = true;
    });
}


// function handleFiles(files) {
//     for (var i = 0; i < files.length; i++) {
//         var file = files[i];

//         var $fileBox = $("<div>").addClass("fileBox");

//         if ($selDiv.find(".fileName:contains('" + file.name + "')").length > 0) {
//             continue;
//         }

//         var $fileName = $("<div>").addClass("fileName").text(file.name);
//         $fileBox.append($fileName);

//         var $removeButton = $("<button>").addClass("badge bg-warning removeButton").text("X");
//         $fileBox.append($removeButton);

//         $selDiv.append($fileBox);
//     }
// }

var uploadedFiles = []; // This array will store all the uploaded files

var $selDiv = $(".uploaded-files-list");
var $modal = $("#fileModal");
var $modalContent = $("#modalContent");

var $dropArea = $("#drop-area");


$(document).ready(function () {

   

    $dropArea.on('dragover', function (e) {
        e.preventDefault();
        e.stopPropagation();
        $dropArea.addClass('dragging');
    });


    $dropArea.on('dragleave', function (e) {
        e.preventDefault();
        e.stopPropagation();
        $dropArea.removeClass('dragging');
    });

    $dropArea.on('drop', function (e) {
        e.preventDefault();
        e.stopPropagation();
        $dropArea.removeClass('dragging');
        var files = e.originalEvent.dataTransfer.files;
        handleFiles(files);
    });

    $('#upload_file').on('change', function (e) {
        var files = e.target.files;
        // console.log("in upload_file : " + files.length);
        handleFiles(files);
    });

    // $selDiv.on('click', '.removeButton', function () {
    //     $(this).closest('.fileBox').remove();
    // });
    
    // Remove file button functionality
    $selDiv.on('click', '.removeButton', function () {
        var fileName = $(this).closest('.fileBox').find('span').text();
        uploadedFiles = uploadedFiles.filter(file => file.name !== fileName); // Remove the file from the array
        $(this).closest('.fileBox').remove(); // Remove the file box from the UI
    });

    // // Close button click event (reset uploadedFiles on modal close)
    // $('.btn-danger').on('click', function () {
    //     uploadedFiles = []; // Clear the uploaded files list when modal is closed
    //     updateFileList(); // Clear UI as well
    // });

});

$(".close").click(function () {
    $modal.hide();
});

$(window).click(function (event) {
    if (event.target == $modal[0]) {
        $modal.hide();
    }
});


function fetchPriorityData() {
    $.ajax({
        url: 'Nebula_dashboard/getPriorityData',
        method: 'post',
        async: true,
        // data: {},
        success: function (response) {
            var getPriorityData = response;
            try {
                getPriorityData = JSON.parse(getPriorityData); // Parse the response into an object
            } catch (e) {
                console.error("Error parsing JSON:", e);
                return;
            }
            
            // Convert object to an array of objects with `value` and `text` properties
            var priorityArray = Object.keys(getPriorityData).map(function(key) {
                return { value: key, text: getPriorityData[key] };
            });

            // console.log("Priority Array:", priorityArray);

            var priority = $('#priority');
            priority.empty();

            if (priorityArray.length > 0) {
                priorityArray.forEach(function (priorityObj) {
                    // Check if priorityObj is valid
                    if (priorityObj && priorityObj.value && priorityObj.text) {
                        // Check if the current priority is 'normal' and set it as selected
                        if (priorityObj.value === 'normal') {
                            priority.append('<option value="' + priorityObj.value + '" selected>' + priorityObj.text + '</option>');
                        } else {
                            priority.append('<option value="' + priorityObj.value + '">' + priorityObj.text + '</option>');
                        }
                    } else {
                        console.error("Invalid priority object:", priorityObj);
                    }
                });
            } else {
                priority.append('<option value="">No priorities available</option>');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error fetching sub-modules:", error);
            
        }
    });
}

function fetchPurposeData() {
    $.ajax({
        url: 'Nebula_dashboard/getPurposeData',
        method: 'post',
        async: true,
        success: function (response) {
            var getPurposeData = response;
            try {
                getPurposeData = JSON.parse(getPurposeData);
            } catch (e) {
                console.error("Error parsing JSON:", e);
                return;
            }
            
            // Convert object to an array of objects with `value` and `text` properties
            var purposeArray = Object.keys(getPurposeData).map(function(key) {
                return { value: key, text: getPurposeData[key] };
            });
            var purpose = $('#purpose');
            purpose.empty();

            if (purposeArray.length > 0) {
                purposeArray.forEach(function (purposeObj) {
                    if (purposeObj && purposeObj.value && purposeObj.text) {
                        if (purposeObj.value === 'bug_report') {
                            purpose.append('<option value="' + purposeObj.value + '" selected>' + purposeObj.text + '</option>');
                        } else {
                            purpose.append('<option value="' + purposeObj.value + '">' + purposeObj.text + '</option>');
                        }
                    } else {
                        console.error("Invalid purpose object:", purposeObj);
                    }
                });
            } else {
                purpose.append('<option value="">No purpose available</option>');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error fetching sub-modules:", error);
        }
    });
}

function fetchSubModules(departmentType) {
    $.ajax({
        url: 'Nebula_dashboard/getSubModulesByDepartmentType',
        method: 'post',
        async: true,
        // dataType: "json",
        data: { department_type: departmentType },
        // processData: false,
        // contentType: false,
        success: function (response) {
            var subModules = response;
            subModules = JSON.parse(subModules);

            var subModuleDropdown = $('#orion_sub_modules');
            subModuleDropdown.empty();

            subModuleDropdown.append('<option value="">Select Category</option>');

            if (subModules && subModules.length > 0) {
                subModules.forEach(function (subModule) {
                    subModule_txt = subModule.replaceAll('_', ' ')

                    subModuleDropdown.append('<option value="' + subModule + '">' + subModule_txt + '</option>');
                });
            } else {
                subModuleDropdown.append('<option value="">No sub-modules available</option>');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error fetching sub-modules:", error);
            alert('There was an error fetching sub-modules. Please try again.');
        }
    });
}

var departmentTL = [];
var softwareTL = [];
function fetchDepartmentTL(departmentType) {
    $.ajax({
        url: 'Nebula_dashboard/getDepartmentTL',
        async: true,
        method: 'POST',
        data: { department_type: departmentType },
        success: function (response) {
            departmentTL = response;
            departmentTL = JSON.parse(departmentTL);

            $('#department_tl').empty();

            var departmentIDs = [];

            if (departmentTL && departmentTL.length > 0) {
                departmentTL.forEach(function (department) {
                    departmentIDs.push(department.id);

                    var departmentBox = $('<div></div>')
                        .text(department.name)
                        .css({
                            'border': '1px solid #ccc',
                            'padding': '5px',
                            'margin-bottom': '5px',
                            'border-radius': '5px',
                            'background-color': '#f9f9f9',
                            'font-size': '13px',
                            'display': 'inline-block',
                            'margin-right': '3px'
                        });
                    $('#department_tl').append(departmentBox);
                });
            } else {
                $('#department_tl').append('<p>No Department TL available</p>');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error fetching Department TL:", error);
            alert('There was an error fetching Department TL. Please try again.');
        }
    });
}

$('#orion_sub_modules').change(function () {
    var selectedSubModule = $(this).val();
    if (selectedSubModule) {
        //fetchSoftwareTL(selectedSubModule);
        //fetchTrainer(selectedSubModule);
    }
});


function handleFiles(files) {
    console.log("in function " + files.length);
    for (var i = 0; i < files.length; i++) {
        var file = files[i];

        var escapedFileName = CSS.escape(file.name);

        // Check if the file is already added by its full name (title attribute)
        if ($selDiv.find(".fileName[title='" + escapedFileName + "']").length > 0) {
            continue;
        }

        // Add the new file to the uploadedFiles array
        uploadedFiles.push(file);

        var $fileBox = $("<div>").addClass("fileBox");
        var maxLength = 60;
        var fileNameParts = file.name.split(".");
        var extension = fileNameParts.pop();
        var baseName = fileNameParts.join(".");

        var displayName = baseName.length > maxLength
            ? baseName.substring(0, maxLength) + "..."
            : baseName;

        displayName += "." + extension;

        var $fileName = $("<div>")
            .addClass("fileName")
            .text(displayName)
            .attr("title", file.name);
        $fileBox.append($fileName);

        var $removeButton = $("<button>")
            .addClass("badge bg-warning removeButton")
            .text("X");
        $fileBox.append($removeButton);

        $selDiv.append($fileBox);
    }
}

function fetchSoftwareTL(subModule) {
    $.ajax({
        url: 'Nebula_dashboard/getSoftwareTL',
        method: 'post',
        data: { sub_module: subModule },
        success: function (response) {
            softwareTL = response;
            softwareTL = JSON.parse(softwareTL);

            $('#software_tl').empty();

            var softwareTLIDs = [];

            if (softwareTL && softwareTL.length > 0) {
                softwareTL.forEach(function (software) {
                    softwareTLIDs.push(software.sw_tl_id);

                    var softwareTLBox = $('<div></div>')
                        .text(software.name)
                        .css({
                            'border': '1px solid #ccc',
                            'padding': '5px',
                            'margin-bottom': '5px',
                            'border-radius': '5px',
                            'background-color': '#f9f9f9',
                            'font-size': '13px',
                            'display': 'inline-block',
                            'margin-right': '3px'
                        });
                    $('#software_tl').append(softwareTLBox);
                });

            } else {
                $('#software_tl').append('<p>No Software TL available</p>');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error fetching software TL:", error);
            alert('There was an error fetching the Software TL. Please try again.');
        }
    });
}

function fetchTrainer(subModule) {
    $.ajax({
        url: 'Nebula_dashboard/getTrainer',
        method: 'post',
        data: { sub_module: subModule },
        success: function (response) {
            var trainer = response;
            trainer = JSON.parse(trainer);

            var trainerNameInput = $('#trainer');
            var trainerIdInput = $('#trainer_id');

            if (trainer && trainer.name && trainer.trainer_id) {
                trainerNameInput.val(trainer.name);
                trainerIdInput.val(trainer.trainer_id);
            } else {
                trainerNameInput.val('No Trainer Available');
            }
        },
        error: function (xhr, status, error) {
            console.error("Error fetching software TL:", error);
            alert('There was an error fetching the Software TL. Please try again.');
        }
    });
}

$('#nebulaForm').submit(function (e) {
    e.preventDefault();
    e.stopImmediatePropagation()

    $('#orion_department').prop('disabled', false);

    var isValid = true;
    $('#nebulaForm input, #nebulaForm select').each(function () {
        var $field = $(this);

        // if (!$field.prop('disabled') && $field.prop('required')) {
        //     if (!$field.val()) {
        //         isValid = false;
        //         $field.addClass('is-invalid');
        //     } else {
        //         $field.removeClass('is-invalid');
        //     }
        // }
        if (!$field.prop('disabled') && $field.prop('required')) {
            if (!$field.val()) {
                isValid = false;
                $field.addClass('is-invalid');
                console.log('Field is empty:', $field.attr('name'));  // Only log empty fields
            } else {
                $field.removeClass('is-invalid');
            }
        }
    });

    if (!isValid) {
        alert('Form validation failed. Please check required fields.');
        return;
    }

    var formData = new FormData($(this)[0]);

    // Disable orion_department to avoid submitting it if it's still being processed
    $('#orion_department').prop('disabled', false);

    var orion_department = $('#orion_department').val();
    var purpose = $('#purpose').val();

    var notes = neweditorInstance.getData();
    //var plainText = neweditorInstance.getData().replace(/<\/?[^>]+(>|$)/g, "");  // Remove HTML tags for plain text
    //formData.append("notes", plainText);
    formData.append("notes", notes);
    // alert(plainText);

    // var notes = $('#notes').val();
    // alert(notes);
    // var plainText = $('<div>').html(notes).text();
    // alert(plainText);

    // Append extra fields to formData
    formData.append("orion_department", orion_department);

    // formData.append("notes", notes);

    // // var uploaded_files = $('#upload-file-container input[type="file"]')[0].files;
    // for (var i = 0; i < uploaded_files.length; i++) {
    //     formData.append("uploaded_files[]", uploaded_files[i]);
    // }

    // Append all uploaded files from the uploadedFiles array
    for (var i = 0; i < uploadedFiles.length; i++) {
        formData.append("uploaded_files[]", uploadedFiles[i]);
    }

    $('#orion_department').prop('disabled', true);

    // var departmentIDs = [];
    // departmentTL.forEach(function (department) {
    //     departmentIDs.push(department.id);
    // });
    // formData.append('department_ids', JSON.stringify(departmentIDs));

    // var softwareIDs = [];
    // softwareTL.forEach(function (software) {
    //     softwareIDs.push(software.sw_tl_id);
    // });
    // formData.append('software_ids', JSON.stringify(softwareIDs));

    var edit_id = $(".nebula-form .submit_form").attr("data-ticket_id");

    formData.append('edit_id', edit_id);
    formData.append('currentPageURL', currentPageURL);

    addOverlay();

    $.ajax({
        url: 'Nebula_dashboard/submitNebula',
        method: 'POST',
        dataType: "json",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            var sType, sText;

            if (response.status === 200) {
                sType = getStatusText(response.status);
                sText = response.message;
                Custom.myNotification(sType, sText);

                $('#nebulaForm')[0].reset();
                $('#nebulaForm .is-invalid').removeClass('is-invalid');

                window.location.reload();
                // $('#exampleModal').modal('hide');
            } else {
                sType = getStatusText(response.status);
                sText = response.message;
                Custom.myNotification(sType, sText);
            }

            removeOverlay();
        },
        error: function (xhr, status, error) {
            console.error("Error submitting form:", error);

            removeOverlay();
        }
    });
});



        

function nebula_ckeditor(id = "", currentDescription = "") {
 
    //let neweditorInstance;  // Declare neweditorInstance outside the function
    const maxChars = 6000;
    const charCountElement = document.getElementById('charCount');
  
    const editorElement = document.querySelector('#' + id);
    
    // If the editor is initially hidden, wait for it to be visible
    if (editorElement.style.display === 'none') {
        // You can use MutationObserver or a simple interval to wait for it to be visible
        const interval = setInterval(() => {
            if (editorElement.style.display !== 'none') {
                clearInterval(interval); // Stop the interval when the element is visible
                initializeEditor(); // Initialize the CKEditor
            }
        }, 100); // Check every 100ms
    } else {
        initializeEditor(); // Initialize immediately if the element is already visible
    }

    function initializeEditor() {
       
        ClassicEditor
            .create(editorElement, {
                toolbar: ['bold', 'italic', 'link', 'undo', 'redo', 'blockQuote'],
                height: '180px'
            })
            .then(editor => {
                neweditorInstance = editor;

                neweditorInstance.model.document.on('change:data', () => {
                    const currentLength = neweditorInstance.getData().length;  
                    const remainingChars = maxChars - currentLength; 

                    charCountElement.innerHTML = `Characters: ${remainingChars}/6000`;

                    if (remainingChars < 0) {
                        charCountElement.style.color = 'red';
                    } else {
                        charCountElement.style.color = '';
                    }
                });

                neweditorInstance.setData(currentDescription); 
            })
            .catch(error => {
                console.error(error);
            });

           
    }
    return neweditorInstance;
}

$(document).ready(function () {
    
    var departmentaaaa = $('.nebula_dashboard_img').data('department');
    if(departmentaaaa == 'accounting') {
        $('.nebula_dashboard_img .ne_dash_icon').css({
            'position': 'absolute',
            'right': '450px',
            'top': '-19px'
        });

       
        $('.extract_btn_div .extract_tbl_headerbtn').css({
            "position":' absolute',
            "right":' 499px',
            "top": '-19px',
        });
    


    } else {
        
        $('.nebula_dashboard_img .ne_dash_icon,.extract_btn_div .extract_tbl_headerbtn').css({
            'height': '38px'
        });
    
    }


});