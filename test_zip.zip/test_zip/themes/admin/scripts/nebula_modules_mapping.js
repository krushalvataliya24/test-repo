$(document).ready(function () {

    $(".select2").select2();

    oTable = $('#listNebulaModulesMapping').DataTable({
        responsive: false,
        "processing": true,
        "serverSide": true,
        "order": [],
        "iDisplayLength": 50,
            "order": [
                [0, "DESC"]
            ],
        "ajax": {
            "url":ADMIN_URL+"Nebula_modules_mapping/lists/",
        },
        "columns": [
            {"data": "id", searchable: false, sortable: false},
            {"data": "department",searchable: true, sortable: false},
            {"data": "module", searchable: true, sortable: false},
            {"data": "software_tl_name", searchable: true, sortable: false},
            {"data": "trainer_name", searchable: true, sortable: false},
            {"data": "action", searchble: false, sortable: false,"width": "20%"},
        ],
        "columnDefs": [{
            "defaultContent": "-",
            "targets": "_all"
        }],
        drawCallback: function (oSettings) {
            var response = oSettings.json;
            if(response.list){$('#select-sys-default-door-caping').html(response.list);}
            $('.status-switch').bootstrapSwitch();
            $('.status-switch').bootstrapSwitch('setOnClass', 'success');
            $('.status-switch').bootstrapSwitch('setOffClass', 'danger');
        }
    });
});
// listReportFlowData

$(document).on('change', '#department', function (e) {

    var selectedDepartmentType = $(this).val(); 
    if (selectedDepartmentType) {
        fetchSubModules(selectedDepartmentType);
    }
});

    function fetchSubModules(departmentType) {

        $.ajax({
            url: 'Nebula_modules_mapping/getSubModulesByDepartmentType', 
            type: 'post', 
            data: { department: departmentType }, 
            success: function(response) {
                var resp = response;
                resp = JSON.parse(resp);
                if (resp.status == 200) {
                    var subModuleDropdown = $('#modules');
                    subModuleDropdown.empty(); 
                    
                    subModuleDropdown.append('<option value="">Select Module</option>');
                    var subModules = resp.module;
                    if (subModules && subModules.length > 0) {
                        //  console.log(subModules);
                        subModules.forEach(function(subModule) {
                            subModule_txt = subModule.replaceAll('_', ' ')
                            
                            subModuleDropdown.append('<option value="' + subModule + '">' + subModule_txt + '</option>');
                        });
                    }

                } else {
                    subModuleDropdown.append('<option value="">No modules available</option>');
                }
            },
            error: function(xhr, status, error) {
                console.error("Error fetching sub-modules:", error);
                alert('There was an error fetching sub-modules. Please try again.');
            }
        });
    }

$(document).on('submit', '#frmNebulaModulesMapping', function (e) {
    e.preventDefault();
    
        var data = new FormData($('#frmNebulaModulesMapping')[0]);
        data.append("type",'submit_nebula_modules_mapping');
        
        addOverlay();
        $.ajax({
            type: 'post',
            data: data,
            async:false,
            dataType: "json",
            url: ADMIN_URL+"Nebula_modules_mapping",
            cache: false,
            contentType: false,
            processData: false,
            success: function (r) {
                if (r.status == 200) {
                    sTitle='';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType,sText);
                    window.location.href = ADMIN_URL+"Nebula_modules_mapping";
                    return false;
                } else {
                    sTitle='';
                    sType = getStatusText(r.status);
                    sText = r.message;
                    sAddClass = r.addclass;
                    Custom.myNotification(sType,sText);
                }
            }
            // complete: removeOverlay
        });
        removeOverlay();

});